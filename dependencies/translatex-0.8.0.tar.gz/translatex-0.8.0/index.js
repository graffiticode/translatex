import * as translatex from './src/core.js';
export const TransLaTeX = translatex.Core;
