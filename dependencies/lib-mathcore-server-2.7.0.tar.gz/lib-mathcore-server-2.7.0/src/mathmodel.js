/*
 * Copyright 2016 Learnosity Ltd. All Rights Reserved.
 *
 */
import {Assert, assert, message} from "./assert.js";
import {Ast, Parser} from "@artcompiler/parselatex";
import {TransLaTeX} from "@artcompiler/translatex";
import Decimal from "decimal.js";
import https from 'https';
import http from 'http';
import fs from 'fs';
// This module has no exports. It is executed to define Parser.fn plugins.
export const init = function () {
  const ast = Parser.prototype;
  function texToSympy(options, tex, resume) {
    let errs = [];
    if (tex && tex.op !== Parser.NONE) {
      try {
        const sympyRules = options.sympyRules;
        assert(sympyRules);
        TransLaTeX.translate(sympyRules, tex, function (err, val) {
          // val = "(expr, expr)" => "(simplify(expr), simplify(expr))"
          // val = "(TRIG expr, LOG expr)" => "(trig_simp(expr), log_simp(expr))"
          // var ast = filbert.parse(val);
          // console.log("texToSympy() ast=" + JSON.stringify(ast, null, 2));
          if (errs && errs.length) {
            errs = errs.concat(err);
            val = null;
          }
          resume(errs, val);
        });
      } catch (e) {
        errs = errs.concat(e.message);
        resume(errs, "");
      }
    } else {
      resume([], "");
    }
  }
  const messages = Assert.messages;

  // Add messages here.
  Assert.reserveCodeRange(2000, 2999, "mathmodel");
  messages[2000] = "Internal error. %1";
  messages[2001] = "Factoring of multi-variate polynomials with all terms of degree greater than one is not supported";
  messages[2002] = "Expression not supported.";
  messages[2003] = "Factoring non-polynomials is not supported.";
  messages[2004] = "Compound units not supported with tolerances.";
  messages[2005] = "Non-numeric expressions cannot be compared with equivValue.";
  messages[2006] = "More that two equals symbols in equation.";
  messages[2007] = "Tolerances are not supported in lists.";
  messages[2008] = "deprecated";
  messages[2009] = "Undefined value in 'equivValue'";
  messages[2010] = "Invalid option name %1.";
  messages[2011] = "Invalid option value %2 for option %1.";
  messages[2012] = "Expressions with comparison or equality operators cannot be compared with equivValue.";
  messages[2013] = "Incompatible values with matrix arithmetic";
  messages[2014] = "Incomplete expression found.";
  messages[2015] = "Invalid format name '%1'.";
  messages[2016] = "Exponents should be wrapped in braces.";
  messages[2017] = "Units with different base units not allowed in a single expression. Found: %1";
  messages[2018] = "Tolerances are not supported with infinite values";
  messages[2019] = "Lower limit must be less than upper limit";
  messages[2020] = "%1 is outside of the tolerance range";
  messages[2021] = "Rounding to a given number of decimal places and significant figures is not supported";

  const bigZero = new Decimal("0");
  const bigOne = new Decimal("1");
  const bigTwo = new Decimal("2");
  const bigThree = new Decimal("3");
  const bigFour = new Decimal("4");
  const bigFive = new Decimal("5");
  const bigMinusOne = new Decimal("-1");
  const options = {};  // Default empty options.
  const nodeZero = numberNode(options, "0");
  const nodeOne = numberNode(options, "1");
  const nodeTwo = numberNode(options, "2");
  const nodeThree = numberNode(options, "3");
  const nodeMinusOne = numberNode(options, "-1");
  const nodePositiveInfinity = numberNode(options, "Infinity");
  const nodeNegativeInfinity = numberNode(options, "-Infinity");
  const nodeOneHalf = binaryNode(Parser.POW, [nodeTwo, nodeMinusOne]);
  const nodeOneThird = binaryNode(Parser.POW, [nodeThree, nodeMinusOne]);
  const nodeImaginary = variableNode("i");
  const nodeE = variableNode("e");
  const nodePI = variableNode("\\pi");

  // NOTE for debugging only
  function stripNids(node) {
    if (!node.op) {
      return node;
    }
    Object.keys(node).forEach(function (k) {
      if (k.indexOf("Nid") > 0) {
        delete node[k];
      }
    });
    if (node.args) {
      node.args.forEach(function (n) {
        stripNids(n);
      });
    }
    return node;
  }
  function stripMetadata(node) {
    // Strip metadata such as nids.
    if (!node.op) {
      return node;
    }
    Object.keys(node).forEach(function (k) {
      if (k !== "op" &&
          k !== "args") {
        delete node[k];
      }
    });
    if (node.args) {
      node.args.forEach(function (n) {
        stripMetadata(n);
      });
    }
    return node;
  }

  function hashCode(str) {
    let hash = 0, i, chr, len;
    if (str.length == 0) return hash;
    for (i = 0, len = str.length; i < len; i++) {
      chr   = str.charCodeAt(i);
      hash  = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }
    return hash;
  }

  function isChemCore() {
    // Has chem symbols so in chem mode
    return !!Parser.env["Au"];
  }

  function undefinedNode(node) {
    if (isUndefined(node)) {
      return node;
    }
    node = numberNode(options, JSON.stringify(node));
    node.isUndefined = true;
    return node;
  }

  function isUndefined(node) {
    // If node or any of its children are undefined, then return true.
    if (node.op === Parser.NUM) {
      return !!node.isUndefined;
    } else if (node.args) {
      return node.args.some(function (n) {
        return isUndefined(n);
      });
    }
    return false;
  }

  function isImaginary(node) {
    if (node.op) {
      return ast.intern(nodeImaginary) === ast.intern(node);
    }
    return false;
  }

  function isAdditive(node) {
    return node.op === Parser.ADD ||
      node.op === Parser.SUB ||
      node.op === Parser.PM ||
      node.op === Parser.BACKSLASH;
  }

  function isMultiplicative(node) {
    return (
      node.op === Parser.MUL ||
      node.op === Parser.CDOT ||
      node.op === Parser.TIMES ||
      node.op === Parser.COEFF ||
      node.op === Parser.DIV
    );
  }

  function newNode(op, args) {
    return {
      op: op,
      args: args
    };
  }

  function binaryNode(op, args, flatten) {
    assert(args.length > 0, "2000: Invalid node shape.");
    if (args.length < 2) {
      return args[0];
    }
    let aa = [];
    args.forEach(function(n) {
      if (flatten && n.op === op &&
          n.args.length > 1 &&   // Don't flatten unary nodes.
          (op === Parser.MUL || op === Parser.TIMES || op === Parser.CDOT || op === Parser.ADD || op === Parser.COEFF)) {
        aa = aa.concat(n.args);
      } else {
        aa.push(n);
      }
    });
    return newNode(op, aa);
  }

  function abs(n) {
    if (n === null) {
      return null;
    } else if (n instanceof Decimal) {  // assume d is too
      if (n === null) {
        return null;
      }
      n = toNumber(n);
    } else if (n.op) {
      n = mathValue(options, n, true);
      if (n === null) {
        return null;
      }
    } else {
      if (isNaN(n)) {
        return null;
      }
    }
    return toDecimal(Math.abs(n));
  }

  function isNeg(options, n) {
    let mv;
    if (n === null) {
      return false;
    }
    if (n.op) {
      if (n.op === Parser.POW || isAdditive(n)) {
        n = n.args[0]; // If base is neg or is additive and leading term is negative, then assume expression is negative.
      }
      const cp = constantPart(options, n);
      mv = mathValue(options, cp, true);
      if (!mv) {
        if (n.op === Parser.MUL && isMinusOne(n.args[0]) ||
            n.op === Parser.NUM && n.args[0] === "-Infinity") {
          return true;
        }
        return false;
      }
    } else if (!(n instanceof Decimal)) {
      return false;
    } else {
      mv = n;
    }
    return mv.cmp(bigZero) < 0;
  }

  function numberNode(options, val, doScale, roundOnly, isRepeating) {
    assert(!(val instanceof Array), "2000: Expecting a scalar");
    // doScale - scale n if true
    // roundOnly - only scale if rounding
    let mv, node, minusOne;
    if (doScale) {
      const scale = +option(options, "decimalPlaces");
      if (isRepeating) {
         // FIXME expand repeating decimal past size of scale
      }
      mv = toDecimal(val);
      if (isNeg(options, mv) && !isMinusOne(mv)) {
        minusOne = bigMinusOne.toDecimalPlaces(scale, Decimal.ROUND_HALF_UP);
        mv = bigMinusOne.times(mv);
      }
      if (mv !== null && (!roundOnly || mv.scale() > scale)) {
        mv = mv.toDecimalPlaces(scale, Decimal.ROUND_HALF_UP);
      }
    } else {
      mv = toDecimal(val);
      if (isNeg(options, mv) && !isMinusOne(mv)) {
        minusOne = bigMinusOne;
        mv = bigMinusOne.times(mv);
      }
    }
    const numberFormat = isInteger(mv) && "integer" || "decimal";
    if (minusOne) {
      node = multiplyNode([newNode(Parser.NUM, [String(minusOne)]), newNode(Parser.NUM, [String(mv)])]);
      node.args[0].numberFormat = "integer";
      node.args[1].numberFormat = numberFormat;
    } else if (mv) {
      node = newNode(Parser.NUM, [String(mv)]);
      node.numberFormat = numberFormat;
    } else {
      // Infinity and friends
      node = newNode(Parser.NUM, [String(val)]);
    }
    return node;
  }

  function multiplyNode(args, flatten) {
    if (args.length === 0) {
      // We have simplified away all factors.
      args = [nodeOne];
    }
    return binaryNode(Parser.MUL, args, flatten);
  }

  function addNode(args, flatten) {
    if (args.length === 0) {
      // We have simplified away all factors.
      args = [nodeOne];
    }
    return binaryNode(Parser.ADD, args, flatten);
  }

  function fractionNode(n, d) {
    return multiplyNode([n, binaryNode(Parser.POW, [d, nodeMinusOne])], true);
  }

  function unaryNode(op, args) {
    if (op === Parser.ADD) {
       return args[0];
     } else {
       return newNode(op, args);
     }
  }

  function variableNode(name, flag) {
    assert(typeof name === "string", "2000: Expecting a string");
    const node = newNode(Parser.VAR, [name]);
    node.flag = flag;
    return node;
  }

  function negateFactors(args) {
    // Handle leading coefficients
    if (args.length === 0) {
      args.unshift(nodeMinusOne);
    } else if (isMinusOne(args[0])) {
      args.shift();
    } else {
      let didNegate = false;
      const argsNew = [];
      args.forEach(arg => {
        if (isMinusOne(arg)) {
          // Skip it.
          didNegate = !didNegate;
        } else if (arg.op === Parser.POW && arg.args[0].op === Parser.MUL && isMinusOne(arg.args[0].args[0]) && isMinusOne(arg.args[1])) {
          argsNew.push(negate(arg));
          didNegate = !didNegate;
        } else {
          argsNew.push(arg);
        }
      });
      args = argsNew;
      if (!didNegate) {
        args.unshift(nodeMinusOne);
      }
    }
    return args;
  }

  function leadingCoeff(node) {
    let tt, cp;
    switch (node.op) {
    case Parser.ADD:
      cp = constantPart(options, node.args[0]);
      break;
    default:
      cp = constantPart(options, node);
      break;
    }
    return cp;
  }

  function negate(n, isNormalizing) {
    let node;
    if (typeof n === "number") {
      assert(false);
      return -n;
    } else if (n.op === Parser.MUL || n.op === Parser.COEFF || n.op === Parser.TIMES) {
      // Handle leading coefficients
      var args = n.args.slice(0); // copy
      args = negateFactors(args);
      node = binaryNode(n.op, args, true);
    } else if (n.op === Parser.ADD && !isNormalizing) {
      if (isNeg(options, leadingCoeff(n))) {
        // If has a negative leading coefficient, then negate each term.
        var args = [];
        n.args.forEach(function (arg) {
          args.push(negate(arg));
        });
        node = binaryNode(n.op, args, true);
      } else {
        node = multiplyNode([nodeMinusOne, n]);
      }
    } else if (n.op === Parser.NUM) {
      if (n.args[0] === "1") {
        node = nodeMinusOne;
      } else if (n.args[0] === "-1") {
        return nodeOne;
      } else if (n.args[0] === "Infinity") {
        node = nodeNegativeInfinity;
      } else if (n.args[0] === "-Infinity") {
        return nodePositiveInfinity;
      } else if (n.args[0].charAt(0) === "-") {
        node = numberNode(options, n.args[0].slice(1));
      } else {
        node = numberNode(options, "-" + n.args[0]);
      }
    } else if (n.op === Parser.POW && isMinusOne(n.args[1])) {
      if (isZero(n.args[0])) {
        node = nodeNegativeInfinity;
      } else {
        node = binaryNode(Parser.POW, [negate(n.args[0]), nodeMinusOne]);
      }
    } else if (n.op === Parser.INTEGRAL && n.args.length === 3) {
      // We have a definite integral, so swap limits.
      node = newNode(Parser.INTEGRAL, [n.args[1], n.args[0], n.args[2]]);
    } else {
      node = multiplyNode([nodeMinusOne, n], true);
    }
    return node;
  }

  function isPositiveInfinity(n) {
    if (n === Number.POSITIVE_INFINITY ||
        n.op === Parser.NUM && n.args[0] === "Infinity") {
      return true;
    }
    return false;
  }

  function isNegativeInfinity(n) {
    if (n === Number.NEGATIVE_INFINITY ||
        n.op === Parser.NUM && n.args[0] === "-Infinity" ||
        n.op === Parser.SUB && n.args[0].op === Parser.NUM &&
        n.args[0].args[0] === "Infinity") {
      return true;
    }
    return false;
  }

  function isInfinity(n) {
    if (n === Number.POSITIVE_INFINITY ||
        n === Number.NEGATIVE_INFINITY ||
        n.op === Parser.NUM &&
        (n.args[0] === "Infinity" ||
        n.args[0] === "-Infinity") ||
        n.op === Parser.SUB &&
        n.args[0].op === Parser.NUM &&
        n.args[0].args[0] === "Infinity") {
      return true;
    }
    return false;
  }

  function isE(n) {
    if (n === null) {
      return false;
    } else if (n instanceof Decimal) {
      return !bigE.cmp(n);
    } else if (typeof n === "number") {
      return n === Math.E;
    } else if (n.op === Parser.NUM && +n.args[0] === Math.E) {
      return true;
    } else if (n.op === Parser.VAR && n.args[0] === "e") {
      return true;
    } else {
      return false;
    }
  }

  function isZero(n) {
    if (n === null) {
      return false;
    } else if (n instanceof Decimal) {
      return !bigZero.cmp(n);
    } else if (typeof n === "number") {
      return n === 0;
    } else if (n.op === Parser.NUM && +n.args[0] === 0) {
      return true;
    } else {
      return false;
    }
  }

  function isOne(n) {
    var mv;
    if (n === null) {
      return false;
    } else if (n instanceof Decimal) {
      return !bigOne.cmp(n);
    } else if (typeof n === "number") {
      return n === 1;
    } else if (n.op === Parser.NUM) {
      if (n.args[0] === '1') {
        return true;
      }
      var mv = mathValue(options, n);
      if (mv) {
        return !bigOne.cmp(mv);
      }
      return false;
    }
  }

  function isMinusOne(n) {
    if (n === null || n === undefined || typeof n === "string") {
      return false;
    } else if (typeof n === "number") {
      return n === -1;
    } else if (n instanceof Decimal) {
      return bigMinusOne.cmp(n) === 0;
    } else if (n.op) {
      if (n.args[0] === '-1' ||
          n.op === Parser.SUB && n.args.length === 1 && isOne(n.args[0])) {
        return true;
      }
      const mv = mathValue(options, n, true);
      if (mv) {
        return bigMinusOne.cmp(mathValue(options, n, true)) === 0;
      } else {
        return false;
      }
    }
    assert(false, "2000: Unable to compare with zero. typeof n= " + typeof n);
  }

  function isInteger(node) {
    let mv;
    if (!node) {
      return false;
    }
    if (node.op === Parser.NUM &&
        (mv = mathValue(options, node, true)) !== null &&
        isInteger(mv)) {
      return true;
    } else if (node instanceof Decimal) {
      return node.modulo(bigOne).cmp(bigZero) === 0;
    }
    return false;
  }

  function isDecimal(node) {
    let mv;
    if (!node) {
      return false;
    }
    if (node.op === Parser.NUM &&
        (mv = mathValue(options, node, true)) !== null &&
        !isInteger(mv)) {
      return true;
    } else if (node instanceof Decimal &&
               !isInteger(node)) {
      return true;
    }
    return false;
  }

  function isEven(node) {
    let mv;
    if (!node) {
      return false;
    }
    if (node.op === Parser.NUM &&
        (mv = mathValue(options, node, true)) !== null &&
        isEven(mv)) {
      return true;
    } else if (node instanceof Decimal) {
      return node.modulo(bigTwo).cmp(bigZero) === 0;
    }
    return false;
  }

  function isOdd(node) {
    const mv = mathValue(options, node, true);
    return isInteger(mv) && !isEven(mv);
  }

  function isOddFraction(node) {
    // Both numerator and denominator are odd integers. We consider odd integers
    // to be degenerate positive cases.
    const ff = factors(options, node, {}, true, true);
    const nn = [nodeOne], dd = [nodeOne];
    ff.forEach(function (f) {
      if (f.op !== Parser.POW || !isNeg(options, mathValue(options, f.args[1], true))) {
        // Is a numerator.
        if (!isMinusOne(f)) {
          // Erase -1.
          nn.push(f);
        }
      } else {
        if (!isMinusOne(f)) {
          // Erase -1.
          dd.push(f.args[0]);
        }
      }
    });
    const n = multiplyNode(nn);
    const d = multiplyNode(dd);
    return isOdd(n) && isOdd(d);
  }

  function isPolynomial(node) {
    const n0 = JSON.parse(JSON.stringify(node));  // Make copy.
    const tt = terms(options, expand(options, n0));
    let a = bigZero, b = bigZero, c = bigZero, notPolynomial = false;
    const cc = [];
    tt.forEach(function (v) {
      const d = degree(options, v, true);
      if (isImaginary(v) ||
          d === Number.POSITIVE_INFINITY ||
          d < 0 ||
          d !== Math.floor(d) ||   // Non-positive integer power.
          d > 10 ||
          !isNumeric(constantPart(options, v))) {
        notPolynomial = true;
        return;
      }
      if (cc[d] === undefined) {
        let i = d;
        // Zero out undefined coefficients from here to the last coefficient.
        while (i >= 0 && cc[i] === undefined) {
          cc[i] = 0;
          i--;
        }
      }
      cc[d] = cc[d] + toNumber(mathValue(options, constantPart(options, v), true));
    });
    if (notPolynomial || variables(options, node).length > 1) {
      return null;
    }
    return cc;
  }

  function toNumber(n) {
    let str;
    if (n === null) {
      return Number.NaN;
    } else if (typeof n === "number") {
      return n;
    } else if (n instanceof Decimal) {
      str = n.toString();
    } else if (n.op === Parser.NUM) {
      str = n.args[0];
    } else {
      return Number.NaN;
    }
    return parseFloat(str);
  }

  function toDecimal(val) {
    let str;
    if (val === null || val === undefined ||
        val.op === undefined && isNaN(val) ||
        isInfinity(val) ||
        isImaginary(val) ||
        typeof val === "string" && val.indexOf("Infinity") >= 0) {
      return null;
    } else if (val instanceof Decimal) {
      return val;
    } else if (val.isScientific) {
      assert(isMultiplicative(val));
      const n = val.args[0];
      const e = val.args[1].args[1];
      const nStr =
            n.op === Parser.SUB && '-' + n.args[0].args[0] ||
            n.op === Parser.ADD && n.args[0].args[0] ||
            n.args[0];
      const eStr =
            e.op === Parser.SUB && '-' + e.args[0].args[0] ||
            e.op === Parser.ADD && e.args[0].args[0] ||
            e.args[0];
      str = nStr + 'e' + eStr;
    } else if (val.op === Parser.SUB && val.args[0].op === Parser.NUM) {
      str = '-' + val.args[0].args[0];
    } else if (val.op === Parser.ADD && val.args[0].op === Parser.NUM) {
      str = val.args[0].args[0];
    } else if (val.op === Parser.NUM) {
      str = val.args[0];
      assert(!isNaN(str));
    } else if (typeof val === 'number' && Number.isFinite(val)) {
      str = val.toString();
    } else if (typeof val === 'string' && !isNaN(val)) {
      str = val;
    } else {
      return null;
    }
    return new Decimal(str);
  }

  function toRadians(node) {
    // Convert node to radians
    assert(node && node.op, "2000: Invalid node");
    let val = bigOne, uu;
    const args = [];
    if (node.op === Parser.MUL) {
      node.args.forEach(function (n) {
        if (n.op === Parser.VAR) {
          switch (n.args[0]) {
          case "\\degree":
            args.push(numberNode(options, new Decimal("" + Math.PI).dividedBy(new Decimal("180"))));
            break;
          case "\\radians":
            // Do nothing.
            break;
          default:
            args.push(toRadians(n));
            break;
          }
        } else {
          args.push(n);
        }
      });
      node = multiplyNode(args);
    }
    return node;
  }

  function logBase(b, v) {
    const n = Math.log(toNumber(v)) / Math.log(toNumber(b));
    if (!isNaN(n)) {
      return new Decimal(String(n));
    }
    return null;
  }

  function factorial(n) {
    let i = 2;
    let result = bigOne;
    for (; i <= n; i++) {
      Assert.checkTimeout();
      result = result.times(new Decimal(i.toString()));
    }
    return result;
  }

  let varMap = {};
  let varNames = [];
  function reset() {
    varMap = {};
    varNames = [];
  }

  function hint(val, node, str) {
    // If val is false, then annotate the node.
    if (!val) {
      if (!node.hints) {
        node.hints = [];
      }
      node.hints.push(str);
    }
  }

  function sqrtNode(node, e) {
    const eNode = e && numberNode(options, e) || nodeTwo;
    return binaryNode(Parser.POW, [
      node, binaryNode(Parser.POW, [numberNode(options, eNode), nodeMinusOne])
    ]);
  }

  function squareRoot(options, node, nodeE) {
    if (!(nodeE.op === Parser.POW &&
          isNeg(options, nodeE.args[1]) &&
          isInteger(nodeE.args[0]))) {
      return newNode(Parser.POW, [node, nodeE]);
    }
    const e = +nodeE.args[0].args[0];
    let args;
    if (!option(options, "dontExpandPowers") && node.op === Parser.NUM) {
      args = factors(options, node, {}, false, true);
    } else if (node.op === Parser.MUL) {
      args = node.args;
    } else {
      // FIXME handle other cases (e.g. Polynomials)
      return sqrtNode(node, e);
    }
    const hash = {};
    let vp, vpnid, list;
    args.forEach(function (n) {
      // (x+3)(x+3) (xy^2)
      vpnid = ast.intern(n);
      list = hash[vpnid] ? hash[vpnid] : (hash[vpnid] = []);
      list.push(n);
    });
    let inList = [], outList = [];
    Object.keys(hash).forEach(function (k) {
      list = hash[k];
      if (list.length >= e) {
        while (list.length >= e) {
          outList.push(list[0]);
          list = list.slice(e);
        }
        inList = inList.concat(list);
      } else {
        inList = inList.concat(list);
      }
    });
    if (inList.length > 0) {
      outList = outList.concat(sqrtNode(simplify(options, multiplyNode(inList)), e));
    }
    return multiplyNode(outList);
  }

  function flattenNestedNodes(node, doSimplify) {
    let args = [];
    if (node.op === Parser.NUM || node.op === Parser.VAR) {
      return node;
    }
    node.args.forEach(function (n) {
      if (doSimplify) {
        n = simplify(options, n);
      }
      // Normalize to get the correct shape node.
      n = normalize(options, n);
      if (n.op === node.op) {
        args = args.concat(n.args);
      } else {
        args.push(n);
      }
    });
    const isMixedNumber = node.isMixedNumber;
    node = binaryNode(node.op, args);
    node.isMixedNumber = isMixedNumber;
    return node;
  }

  const normalNumber = numberNode(options, "298230487121230434902874");
  normalNumber.is_normal = true;

  // The outer Visitor function provides a global scope for all visitors,
  // as well as dispatching to methods within a visitor.
  function Visitor(ast) {
    function visit(options, node, visit, resume) {
      assert(node && node.op && node.args, "2000: Visitor.visit() op=" + node.op + " args = " + JSON.stringify(node.args));
      switch (node.op) {
      case Parser.NUM:
        node = visit.numeric(node, resume);
        break;
      case Parser.ADD:
      case Parser.SUB:
      case Parser.PM:
      case Parser.BACKSLASH: // set operator
        if (node.args.length === 1) {
          node = visit.unary(node, resume);
        } else {
          node = visit.additive(node, resume);
        }
        break;
      case Parser.MUL:
      case Parser.TIMES:
      case Parser.COEFF:
      case Parser.DIV:
      case Parser.FRAC:
      case Parser.CDOT:
        node = visit.multiplicative(node, resume);
        break;
      case Parser.POW:
      case Parser.LOG:
        node = visit.exponential(node, resume);
        break;
      case Parser.VAR:
      case Parser.SUBSCRIPT:
        node = visit.variable(node, resume);
        break;
      case Parser.SQRT:
      case Parser.SIN:
      case Parser.COS:
      case Parser.TAN:
      case Parser.ARCSIN:
      case Parser.ARCCOS:
      case Parser.ARCTAN:
      case Parser.ARCSEC:
      case Parser.ARCCSC:
      case Parser.ARCCOT:
      case Parser.SEC:
      case Parser.CSC:
      case Parser.COT:
      case Parser.SINH:
      case Parser.COSH:
      case Parser.TANH:
      case Parser.ARCSINH:
      case Parser.ARCCOSH:
      case Parser.ARCTANH:
      case Parser.ARCSECH:
      case Parser.ARCCSCH:
      case Parser.ARCCOTH:
      case Parser.SECH:
      case Parser.CSCH:
      case Parser.COTH:
      case Parser.PERCENT:
      case Parser.M:
      case Parser.ABS:
      case Parser.FACT:
      case Parser.FORALL:
      case Parser.EXISTS:
      case Parser.IN:
      case Parser.SUM:
      case Parser.LIM:
      case Parser.EXP:
      case Parser.TO:
      case Parser.RIGHTARROW:
      case Parser.DERIV:
      case Parser.INTEGRAL:
      case Parser.PROD:
      case Parser.CUP:
      case Parser.BIGCUP:
      case Parser.CAP:
      case Parser.BIGCAP:
      case Parser.PIPE:
      case Parser.ION:
      case Parser.POW:
      case Parser.OVERLINE:
      case Parser.OVERSET:
      case Parser.UNDERSET:
      case Parser.MATHBF:
      case Parser.TEXT:
      case Parser.NONE:
      case Parser.DEGREE:
      case Parser.DOT:
      case Parser.MATHFIELD:
      case Parser.NOT:
      case Parser.PAREN:
      case Parser.BRACKET:
      case Parser.BRACE:
      case Parser.OPERATORNAME:
        node = visit.unary(node, resume);
        break;
      case Parser.COMMA:
      case Parser.MATRIX:
      case Parser.VEC:
      case Parser.ROW:
      case Parser.COL:
      case Parser.INTERVAL:
      case Parser.INTERVALOPEN:
      case Parser.INTERVALLEFTOPEN:
      case Parser.INTERVALRIGHTOPEN:
      case Parser.LIST:
      case Parser.SET:
      case Parser.ANGLEBRACKET:
        node = visit.comma(node, resume);
        break;
      case Parser.EQL:
      case Parser.LT:
      case Parser.LE:
      case Parser.GT:
      case Parser.GE:
      case Parser.NE:
      case Parser.NGTR:
      case Parser.NLESS:
      case Parser.NI:
      case Parser.SUBSETEQ:
      case Parser.SUPSETEQ:
      case Parser.SUBSET:
      case Parser.SUPSET:
      case Parser.NNI:
      case Parser.NSUBSETEQ:
      case Parser.NSUPSETEQ:
      case Parser.NSUBSET:
      case Parser.NSUPSET:
      case Parser.APPROX:
      case Parser.IMPLIES:
      case Parser.PERP:
      case Parser.PROPTO:
      case Parser.PARALLEL:
      case Parser.NPARALLEL:
      case Parser.SIM:
      case Parser.CONG:
      case Parser.CAPRIGHTARROW:
      case Parser.RIGHTARROW:
      case Parser.LEFTARROW:
      case Parser.LONGRIGHTARROW:
      case Parser.LONGLEFTARROW:
      case Parser.OVERRIGHTARROW:
      case Parser.OVERLEFTARROW:
      case Parser.CAPLEFTRIGHTARROW:
      case Parser.LEFTRIGHTARROW:
      case Parser.LONGLEFTRIGHTARROW:
      case Parser.OVERLEFTRIGHTARROW:
      case Parser.COLON:
      case Parser.RIGHTARROW:
        node = visit.equals(node, resume);
        break;
      case Parser.FORMAT:
        // Only supported by normalizeSyntax
        node = visit.format(node);
        break;
      default:
        assert(false, "2000: Should not get here. Unhandled node operator: " + node.op);
        if (visit.name !== "normalizeLiteral" &&
            visit.name !== "sort") {
          assert(false, "2000: Should not get here. Unhandled node operator: " + node.op);
          console.trace(JSON.stringify(node, null, 2));
        }
        break;
      }
      return node;
    }

    // Compute the degree (Number value) of the right most term of an equation.
    // If name is provided then return the degree of the part with that variable
    // name.
    function degree(root, notAbsolute) {
      assert(root && root.args, "2000: Invalid node");
      return visit(options, root, {
        name: "degree",
        exponential: function (node) {
          const args = node.args;
          let d;
          if (node.op === Parser.POW) {
            const expo = mathValue(options, args[1], true);
            if (expo) {
              if (notAbsolute) {
                // Return the raw degree, not the absolute value of the degree
                d = degree(args[0], notAbsolute) * toNumber(expo);
              } else {
                d = degree(args[0], notAbsolute) * Math.abs(toNumber(expo));
              }
            } else {
              if (!isNeg(options, args[1])) {
                d = Number.POSITIVE_INFINITY;   // degree of variable power
              } else {
                d = Number.NEGATIVE_INFINITY;
              }
            }
          } else if (node.op === Parser.LOG) {
            // In, ln x, the degree isn't known so we call it infinity
            d = Number.POSITIVE_INFINITY;
          }
          return d;
        },
        multiplicative: function (node) {
          const args = node.args;
          let d = 0;
          args.forEach(function (n) {
            d += degree(n, notAbsolute);
          });
          return d;
        },
        additive: function (node) {
          // Return the degree of the highest degree term.
          const args = node.args;
          let d = 0;
          let t;
          args.forEach(function (n) {
            t = degree(n, notAbsolute);
            if (t > d) {
              d = t;
            }
          });
          return d;
        },
        numeric: function(node) {
          return 0;
        },
        unary: function(node) {
          const args = node.args;
          const d = degree(args[0], notAbsolute);
          switch (node.op) {
          case Parser.ADD:
          case Parser.SUB:
          case Parser.PM:
          case Parser.PERCENT:
          case Parser.M:
          case Parser.ABS:
            return d;
          case Parser.SIN:
          case Parser.COS:
          case Parser.TAN:
          case Parser.ARCSIN:
          case Parser.ARCCOS:
          case Parser.ARCTAN:
          case Parser.ARCSEC:
          case Parser.ARCCSC:
          case Parser.ARCCOT:
          case Parser.SEC:
          case Parser.CSC:
          case Parser.COT:
          case Parser.SINH:
          case Parser.COSH:
          case Parser.TANH:
          case Parser.ARCSINH:
          case Parser.ARCCOSH:
          case Parser.ARCTANH:
          case Parser.ARCSECH:
          case Parser.ARCCSCH:
          case Parser.ARCCOTH:
          case Parser.SECH:
          case Parser.CSCH:
          case Parser.COTH:
            // Degree of a function is 1.
            return 1;
          case Parser.SQRT:
//            assert(args.length === 1, message(2003));
            return Number.POSITIVE_INFINITY;
          case Parser.FACT:
            if (d !==  0) {
              return nodePositiveInfinity;
            }
            return 0;
          case Parser.INTEGRAL:
            return Number.POSITIVE_INFINITY;
          case Parser.DEGREE:
          case Parser.NONE:
          default:
            return 0;
          }
        },
        variable: function(node) {
          return 1;
        },
        comma: function(node) {
          return [];
        },
        equals: function(node) {
          // Return the degree of the highest degree term.
          const args = node.args;
          let d = 0;
          let t;
          args.forEach(function (n) {
            t = degree(n, notAbsolute);
            if (t > d) {
              d = t;
            }
          });
          return d;
        }
      });
    }

    // Compute the constant part of an expression. The result of 'constantPart'
    // and 'variablePart' are complements. Their product are equivSymbolic with
    // the original expression.
    function constantPart(root) {
      // console.trace("constantPart() root=" + JSON.stringify(root, null, 2));
      const env = Parser.env;
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "constantPart",
        exponential: function (node) {
          if (variablePart(node) === null) {
            // No variable part, so it's all constant part.
            // console.trace("constantPart() exponential node=" + JSON.stringify(node, null, 2));
            return node;
          }
          return nodeOne;
        },
        multiplicative: function (node) {
          const args = [];
          let isNeg = false;
          node.args.forEach(function (n) {
            const cp = constantPart(n);
            if (!isOne(cp)) {
              // No vars so we have a constant.
              const mv = mathValue(options, cp, env, true);
              if (isOne(mv)) {
                // Got one, skip it.
              } else if (isMinusOne(mv)) {
                isNeg = !isNeg;
              } else if (isZero(mv)) {
                args.shift(nodeZero);
              } else {
                args.push(n);
              }
            } // Otherwise it's a variable part. Skip it.
          });
          // console.trace("constantPart() multiplicative isNeg=" + isNeg + " args=" + JSON.stringify(args, null, 2));
          if (args.length === 0) {
            return isNeg && nodeMinusOne || nodeOne;
          } else if (args.length === 1) {
            return isNeg && negate(args[0]) || args[0];
          }
          return isNeg && negate(multiplyNode(args)) || multiplyNode(args);
        },
        additive: function (node) {
          // (x + 2)(x - 1)
          const result = node.args.some(function (n) {
            // If some part has a variable part, the whole is not a constant part.
            return variablePart(n) !== null;
          });
          if (!result) {
            return node;
          }
          return nodeOne;
        },
        unary: function(node) {
          const result = node.args.some(function (n) {
            // If some part has a variable part, the whole is not a constant part.
            return variablePart(n) !== null;
          });
          if (!result) {
            return node;
          }
          return nodeOne;
        },
        numeric: function(node) {
          return node;
        },
        variable: function(node) {
          if (variablePart(node) === null) {
            // It's not a variable part, so it must be a constant part.
            return node;
          }
          return nodeOne;
        },
        comma: function(node) {
          if (variablePart(node) === null) {
            // It's not a variable part, so it must be a constant part.
            return node;
          }
          return nodeOne;
        },
        equals: function(node) {
          if (variablePart(node) === null) {
            // It's not a variable part, so it must be a constant part.
            return node;
          }
          return nodeOne;
        }
      });
    }

    // Compute the unique variables of an expression.
    function variables(root) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "variables",
        exponential: function (node) {
          const args = node.args;
          const val = [];
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        },
        multiplicative: function (node) {
          const args = node.args;
          const val = [];
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        },
        additive: function (node) {
          const args = node.args;
          const val = [];
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        },
        unary: function(node) {
          if (node.op === Parser.OPERATORNAME) {
            // Skip the operator name.
            return variables(node.args[1]);
          }
          if (node.op === Parser.TEXT ||
              node.op === Parser.MATHBF ||
              node.op === Parser.NONE) {
            return [];
          }
          const args = node.args;
          const val = [];
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        },
        numeric: function(node) {
          return [];
        },
        variable: function(node) {
          if (node.args[0] === "0") {
            // Is synthetic.
            return [];
          }
          const v = unpack(node);
          return [v];
          function unpack(node) {
            let v = "";
            node.args.forEach(function (n) {
              if (v === "") {
                if (n.op) {
                  v = unpack(n);
                } else {
                  v = n;
                }
              } else {
                v += "_" + unpack(n);
              }
            });
            return v;
          }
        },
        comma: function(node) {
          const args = node.args;
          const val = [];
          // FIXME should this be a list of strings or a list of arrays of
          // strings?
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        },
        equals: function(node) {
          const args = node.args;
          const val = [];
          args.forEach(function (n) {
            const vars = variables(n);
            vars.forEach(function (v) {
              if (val.indexOf(v) < 0) {
                val.push(v);
              }
            });
          });
          return val;
        }
      });
    }

    function hint(root) {
      // Collect all of the hints attached to this node.
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "hints",
        exponential: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          if (!node.args[1].lbrk) {
            hints.push(message(2016));
          }
          return hints;
        },
        multiplicative: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          return hints;
        },
        additive: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          return hints;
        },
        unary: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          return hints;
        },
        numeric: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          return hints;
        },
        variable: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          return hints;
        },
        comma: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          return hints;
        },
        equals: function(node) {
          let hints = [];
          if (node.hints instanceof Array) {
              hints = hints.concat(node.hints);
          }
          node.args.forEach(function (n) {
            hints = hints.concat(hint(n));
          });
          return hints;
        }
      });
    }

    // Compute the variable part of the expression. The result of 'coeff' and
    // 'variablePart' are complements. Their product are equivSymbolic with the
    // original expression.
    function variablePart(root) {
      const env = Parser.env;
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "variablePart",
        exponential: function (node) {
          if (variablePart(node.args[0]) ||
              variablePart(node.args[1])) {
            // Either base or exponent has a variable part, so the whole is a variable part.
            return node;
          }
          return null;
        },
        multiplicative: function (node) {
          // 3x^2y^3
          const args = [];
          node.args.forEach(function (n) {
            const v = variablePart(n);
            if (v !== null) {
              args.push(v);
            }
          });
          if (args.length === 0) {
            return null;
          } else if (args.length === 1) {
            return args[0];
          }
          return multiplyNode(args);
        },
        additive: function (node) {
          // (x + 2)(x - 1)
          const result = node.args.some(function (n) {
            // If some part has a variable part, the whole is a variable part.
            return variablePart(n) !== null;
          });
          if (result) {
            return node;
          }
          return null;
        },
        unary: function(node) {
          const vp = variablePart(node.args[0]);
          if (vp !== null) {
            return node;
          }
          return null;
        },
        numeric: function(node) {
          return null;
        },
        variable: function(node) {
          let val;
          if (!isNumeric(node)) {
            // If it doesn't have a math value and is not 'i'.
            return node;
          }
          return null;
        },
        comma: function(node) {
          let vars = [];
          node.args.forEach(function (n) {
            vars = vars.concat(variables(n, env));
          });
          if (vars.length !== 0) {
            return node;
          }
          return null;
        },
        equals: function(node) {
          let vars = [];
          node.args.forEach(function (n) {
            vars = vars.concat(variables(n, env));
          });
          if (vars.length !== 0) {
            return node;
          }
          return null;
        }
      });
    }

    // Get the terms of an expression
    function terms(root) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "terms",
        exponential: function (node) {
          return [node];
        },
        multiplicative: function (node) {
          return [node];
        },
        additive: function (node) {
          let vals = [];
          node.args.forEach(function (n) {
            vals = vals.concat(terms(n));
          });
          return vals;
        },
        unary: function(node) {
          return [node];
        },
        numeric: function(node) {
          return [node];
        },
        variable: function(node) {
          return [node];
        },
        comma: function(node) {
          let vals = [];
          node.args.forEach(function (n) {
            vals = vals.concat(terms(n));
          });
          return vals;
        },
        equals: function(node) {
          let vals = [];
          node.args.forEach(function (n) {
            vals = vals.concat(terms(n));
          });
          return vals;
        }
      });
    }

    function isNumeric(root) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "terms",
        exponential: function (node) {
          let val = true;
          node.args.forEach(function (n) {
            val = val && isNumeric(n);
          });
          return val;
        },
        multiplicative: function (node) {
          let val = true;
          node.args.forEach(function (n) {
            val = val && isNumeric(n);
          });
          return val;
        },
        additive: function (node) {
          let val = true;
          node.args.forEach(function (n) {
            val = val && isNumeric(n);
          });
          return val;
        },
        unary: function(node) {
          let val = true;
          node.args.forEach(function (n) {
            val = val && isNumeric(n);
          });
          return val;
        },
        numeric: function(node) {
          return true;
        },
        variable: function(node) {
          const numericSyms = ['\\pi', 'e', 'i', '\\degree'];
          const arg = node.args[0];
          if (numericSyms.includes(arg)) {
            return true;
          }
          return false;
        },
        comma: function(node) {
          return false;
        },
        equals: function(node) {
          return false;
        }
      });
    }

    function subexprs(root) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "terms",
        exponential: function (node) {
          let exprs = [];
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        },
        multiplicative: function (node) {
          let exprs = [];
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        },
        additive: function (node) {
          let exprs = [];
          if (node.isRepeating) {
            return [node];
          }
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        },
        unary: function(node) {
          let exprs = [];
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        },
        numeric: function(node) {
          return [node];
        },
        variable: function(node) {
          return [node];
        },
        comma: function(node) {
          let exprs = [];
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        },
        equals: function(node) {
          let exprs = [];
          node.args.forEach(function (n) {
            exprs = exprs.concat(subexprs(n));
          });
          return exprs;
        }
      });
    }

    function normalizeFormatObject(fmt) {
      // Normalize the fmt object to a dict
      let pattern = {};
      switch (fmt.op) {
      case Parser.VAR:
        pattern["type"] = fmt.args[0];
        break;
      case Parser.MUL:
        fmt.args.forEach(function (f) {
          if (f.op === Parser.VAR) {
            pattern["type"] = f.args[0];
          } else if (f.op === Parser.COLON) {
            pattern[f.args[0].args[0]] = f.args[1].args[0];
          } else if (f.op === Parser.COMMA) {
            Object.assign(pattern, normalizeFormatObject(multiplyNode(f.args)));
          }
        });
        break;
      default:
        assert(false);
        break;
      }
      return pattern;
    }

    function checkNumberFormat(fmt, node) {
      const fmtDict = normalizeFormatObject(fmt);
      const type = fmtDict["type"];
      const sf = +fmtDict["\\sf"];
      const dp = +fmtDict["\\dp"];
      switch (type) {
      case "\\integer":
        if (node.numberFormat === "integer") {
          if (isNaN(sf) ||
              toDecimal(node).toPrecision(sf) === toDecimal(node).toFixed()) {
            return true;
          }
        }
        break;
      case "\\decimal":
        if (node.numberFormat === "decimal" && node.isRepeating) {
          if (isNaN(sf) && isNaN(dp)) {
            return true;
          }
        } else if (node.numberFormat === "decimal") {
          assert(isNaN(sf) || isNaN(dp), message(2021));
          var decimal = node.args[0];
          var digits = decimal.substring(decimal.indexOf(".") + 1).length;
          if (isNaN(sf) && isNaN(dp) ||
              !isNaN(sf) && toDecimal(node).toPrecision(sf) === toDecimal(node).toFixed(digits) ||
              !isNaN(dp) && toDecimal(node).toFixed(dp) === toDecimal(node).toFixed(digits)) {
            return true;
          }
        }
        break;
      case "\\scientific":
        if (node.isScientific) {
          var coeff = node.args[0].op === Parser.NUM ?
                node.args[0].args[0] : node.args[0].args[0].args[0];
          var digits = coeff.indexOf(".") === -1 ?
                0 : coeff.slice(coeff.indexOf(".") + 1).length;
          if (isNaN(sf) ||
              toDecimal(node).toExponential(sf-1) === toDecimal(node).toExponential(digits)) {
            return true;
          }
        }
        break;
      case "\\fraction":
        if (node.isFraction ||
            node.isMixedNumber) {
          return true;
        }
        break;
      case "\\mixedNumber":
        if (node.isMixedNumber) {
          return true;
        }
        break;
      case "\\improperFraction":
        if (node.isFraction) {
          var numer = node.args[1].args[0];
          var denom = node.args[0].args[0];
          if (toDecimal(numer).abs().lte(toDecimal(denom).abs())) {
          return true;
          }
        }
        break;
      case "\\numeric":
        var formats = ["\\integer", "\\decimal", "\\scientific", "\\fraction"];
        return formats.some(function (n) {
          if (fmt.op === Parser.VAR) {
            fmt.args[0] = n;
          } else if (fmt.op === Parser.MUL) {
            fmt.args[0].args[0] = n;
          }
          return checkNumberFormat(fmt, node) === true;
        });
      default:
        assert(false, message(2015, [type]));
        break;
      }
    }

    function toMixedNumber(options, node) {
      const mv = mathValue(options, normalize(options, node), true);
      if (!mv) {
        return null;
      }
      let s, n, d, nmv, dmv;
      const numNode = node.op === Parser.SUB && node.args.length === 1 && node.args[0] || node;
      switch (numNode.op) {
      case Parser.FRAC:
        s = node.op === Parser.SUB && node.args.length === 1 && -1 || 1;
        n = numNode.args[0];
        d = numNode.args[1];
        nmv = mathValue(options, n);
        dmv = mathValue(options, d);
        if (isLessThan(nmv, dmv)) {
          return node;
        } else {
          // I+(N-I*D)/D
          var ip = mv.abs().toFixed(0, Decimal.ROUND_DOWN);
          var np = nmv.sub(dmv.mul(ip));
          var dp = dmv;
          node = binaryNode(Parser.MUL, [
            numberNode(options, ip), binaryNode(Parser.FRAC, [numberNode(options, np), numberNode(options, dp)])
          ]);
          node.isMixedNumber = true;
        }
        break;
      default:
        s = mv.s;
        var fixed = mv.toFixed().split(".");
        var ip = s * fixed[0] || 0;
        var np = fixed[1] || 0;
        var dp = toDecimal(10).pow(String(np).length);
        var fp = simplify(options, expand(options, fractionNode(numberNode(options, np), numberNode(options, dp))));
        if (fp.op === Parser.NUM) {
          if (isZero(mathValue(options, fp))) {
            node = numberNode(options, ip);
          } else if (isZero(ip)) {
            node = fp;
          } else {
            node = simplify(options, expand(options, addNode([numberNode(options, ip), fp])));
          }
        } else {
          if (fp.op === Parser.POW) {
            assert(fp.args[0].op === Parser.NUM && // dp
                   fp.args[1].op === Parser.NUM &&
                   fp.args[1].args[0] === "-1");
            np = nodeOne;
            dp = fp.args[0];
          } else {
            assert(fp.op === Parser.MUL &&
                   fp.args[0].op === Parser.NUM &&  // np
                   fp.args[1].op === Parser.POW &&
                   fp.args[1].args[0].op === Parser.NUM && // dp
                   fp.args[1].args[1].op === Parser.NUM &&
                   fp.args[1].args[1].args[0] === "-1");
            np = fp.args[0];
            dp = fp.args[1].args[0];
          }
          if (+ip === 0) {
            node = binaryNode(Parser.FRAC, [np, dp]);
          } else {
            node = binaryNode(Parser.MUL, [numberNode(options, ip), binaryNode(Parser.FRAC, [np, dp])]);
            node.isMixedNumber = true;
          }
        }
      }
      return s < 0 && unaryNode(Parser.SUB, [node]) || node;
    }
    function decimalToInteger(node) {
      let n;
      const arg = node.args[0];
      if (node.op === Parser.NUM && (n = arg.indexOf(".")) > 0) {
        assert(+arg.slice(n + 1) === 0, arg);
        return numberNode(arg.slice(0, n));
      }
      return node;
    }
    function toFraction(options, node) {
      const mv = mathValue(options, normalize(options, node), true);
      if (!mv) {
        return null;
      }
      let n, d, nmv, dmv;
      const frac = mv.toFraction();
      const sign = mv.s;
      let np = sign < 0 && -1 * frac[0] || frac[0];
      let dp = frac[1];
      const fp = simplify(options, expand(options, fractionNode(numberNode(options, np), numberNode(options, dp))));
      if (fp.op === Parser.NUM) {
        node = decimalToInteger(fp);
      } else {
        if (fp.op === Parser.POW) {
          assert(fp.args[0].op === Parser.NUM && // dp
                 fp.args[1].op === Parser.NUM &&
                 fp.args[1].args[0] === "-1", JSON.stringify(fp));
          np = nodeOne;
          dp = fp.args[0];
        } else {
          assert(fp.op === Parser.MUL &&
                 fp.args[0].op === Parser.NUM &&  // np
                 fp.args[1].op === Parser.POW &&
                 fp.args[1].args[0].op === Parser.NUM && // dp
                 fp.args[1].args[1].op === Parser.NUM &&
                 fp.args[1].args[1].args[0] === "-1", JSON.stringify(fp));
          np = fp.args[0];
          dp = fp.args[1].args[0];
        }
        node = binaryNode(Parser.FRAC, [np, dp]);
        node.isFraction = true;
      }
      return sign < 0 && unaryNode(Parser.SUB, [node]) || node;
    }
    
    function formatExpression(fmt, node) {
      if (fmt === undefined) {
        return node;
      }
      const fmtDict = normalizeFormatObject(fmt);
      const type = fmtDict.type;
      const length = fmtDict.length;
      const numberNode = node.op === Parser.SUB && node.args.length === 1 && node.args[0] || node;
      switch (type) {
      case "\\integer":
        if (numberNode.numberFormat === "integer") {
          if (length === undefined || length === node.args[0].length) {
            // If there is no size or if the size matches the value...
            return true;
          }
        }
        break;
      case "\\decimal":
      case "\\scientific":
      case "\\number":
        if (numberNode.numberFormat === "decimal" &&
            numberNode.isRepeating) {
          if (length === undefined) {
            return node;
          } else {
            // Repeating is infinite.
            return node;  // FIXME round?
          }
        }
        return formatNumber(options, fmtDict, node);
      case "\\fraction":
        if (numberNode.isFraction ||
            numberNode.isMixedNumber) {
          return node;
        }
        return toFraction(options, node);
      case "\\simpleFraction":
      case "\\nonMixedFraction": // Deprecated
        if (numberNode.isFraction) {
          return node;
        }
        assert(false, "FIXME missing conversion to fraction");
        break;
      case "\\mixedFraction":
      case "\\mixedNumber":
        if (numberNode.isMixedNumber) {
          return node;
        }
        return toMixedNumber(options, node);
      case "\\fractionOrDecimal":
        if (numberNode.isFraction ||
            numberNode.isMixedNumber ||
            numberNode.numberFormat === "decimal") {
          return node;
        }
        assert(false, "FIXME missing conversion to fraction or decimal");
        break;
      default:
        assert(false, message(2015, [type]));
        break;
      }
    }
    function formatNumber(options, fmt, node) {
      let str;
      // TODO rewrite to remove Decimal dependency, which is incomplete
      const mv = mathValue(options, normalize(options, node), true);
      if (!mv) {
        return "";
      }
      switch (fmt.type) {
      case "\\decimal":
        str = mv.toFixed();
        break;
      case "\\scientific":
      case "\\engineering":
        // var ip = mant.slice(0, 1);
        // var fp = removeTrailingZeros(mant.slice(1));
        // var m = fp.length && [ip, fp.join("")].join(".") || ip;
        // var n = exp + mant.length - 1;
        // var str = m + "\\times10^{" + n + "}";
        // return mv.ind < 0 && "-" + str || str;
        str = mv.toExponential();
        str = str.indexOf("e+") > 0 && str.replace("e+", "\\times10^{") + "}" || str;
        str = str.indexOf("e-") > 0 && str.replace("e", "\\times10^{") + "}" || str;
        break;
      default:
        // Use defaults.
        break;
      }
      return str;
    }

    function formatMath(options, root, ref) {
      assert(options);
      options = options || {};
      if (!ref || !ref.args) {
        // If not ref, then the structure of nodes is different, so just return original root.
        ref = {args:[]};
      }
      assert(root && root.args, "2000: Internal error.");
      const nid = ast.intern(root);
      const node = Parser.create(options, visit(options, root, {
        name: "formatMath",
        numeric: function (node) {
          if (ref && ref.op === Parser.SUB &&
              ref.args.length === 1 &&
              ref.args[0].op === Parser.FORMAT) {
            // We have unary minus. Strip minus.
            ref = ref.args[0];
          }
          return formatExpression(ref.args[0], node);
        },
        additive: function (node) {
          const args = [];
          if (ref && ref.op === Parser.FORMAT) {
            return formatExpression(ref.args[0], node);
          }
          node.args.forEach(function (n, i) {
            n = formatMath(options, n, ref.args[i]);
            args.push(n);
          });
          return binaryNode(node.op, args);
        },
        multiplicative: function(node) {
          ref = flattenNestedMultiplyNodes(ref);
          node = flattenNestedMultiplyNodes(node);
          const args = [];
          if (ref && ref.op === Parser.FORMAT) {
            return formatExpression(ref.args[0], node);
          }
          node.args.forEach(function (n, i) {
            n = formatMath(options, n, ref.args[i]);
            args.push(n);
          });
          return multiplyNode(args);
        },
        unary: function(node) {
          const arg0 = formatMath(options, node.args[0], ref);
          switch (node.op) {
          case Parser.PERCENT:
            node = unaryNode(node.op, [arg0]);  // Percent compares only to other percent forms
            break;
          case Parser.SUB:
            if (ref && ref.op === Parser.FORMAT) {
              return formatExpression(ref.args[0], node);
            }
            node = negate(arg0, true);
            break;
          default:
            node = unaryNode(node.op, [arg0]);
            break;
          }
          return node;
        },
        variable: function(node) {
          return node;
        },
        exponential: function(node) {
          const args = [];
          if (ref && ref.op === Parser.FORMAT) {
            return formatExpression(ref.args[0], node);
          }
          node.args.forEach(function (n, i) {
            n = formatMath(options, n, ref.args[i]);
            args.push(n);
          });
          return binaryNode(node.op, args);
        },
        comma: function(node) {
          let vals = [];
          node.args.forEach(function (n, i) {
            vals = vals.concat(formatMath(options, n, ref.args[i]));
          });
          var node = newNode(node.op, vals);
          return node;
        },
        equals: function(node) {
          const args = [];
          node.args.forEach(function (n, i) {
            n = formatMath(options, n, ref.args[i]);
            args.push(n);
          });
          return binaryNode(node.op, args);
        }
      }), root.location);
      return node;
    }

    function checkVariableFormat(fmt, id) {
      const fmtDict = normalizeFormatObject(fmt);
      const type = fmtDict.type;
      let name;
      switch (type) {
      case "\\variable":
        if (fmtDict["\\id"] === undefined) {
          // If id is undefined, then accept any variable.
          name = "_";
        } else if (!(name = varMap[id])) {
          // If not in the map then add it.
          // But only if the synthetic name is not already taken.
          if (varNames.indexOf("_" + fmtDict["\\id"]) < 0) {
            varMap[id] = name = "_" + fmtDict["\\id"];
            varNames.push(name);
          } else {
            name = id; // No match, so use the original name.
          }
        }
        break;
      case "\\integer":
      case "\\decimal":
      case "\\scientific":
      case "\\fraction":
      case "\\mixedNumber":
      case "\\improperFraction":
      case "\\numeric":
        name = id;  // Do nothing.
        break;
      default:
        assert(false, message(2015, [type]));
        break;
      }
      return name;
    }

    function isSyntheticEmptyNode(node) {
      return node.op === Parser.VAR && node.args[0] === "0";
    }

    function flattenNestedMultiplyNodes(node) {
      let args = [];
      if (node.op !== Parser.MUL || node.isScientific) {
        // Scientific notation is a special case that needs to keep its shape.
        return node;
      }
      node.args.forEach(function (n) {
        if (n.op === Parser.MUL) {
          n.args.forEach(function (n) {
            args = args.concat(flattenNestedMultiplyNodes(n));
          });
        } else {
          args.push(n);
        }
      });
      return multiplyNode(args, true);
    }

    function normalizeSyntax(options, root, ref) {
      // TODO determine normalization for advanced pattern matching
      assert(options);
      options = options || {};
      if (!ref || !ref.args) {
        // If not ref, then the structure of nodes is different, so just return original root.
        ref = {args:[]};
      }
      assert(root && root.args, "2000: Internal error.");
      const nid = ast.intern(root);
      const node = Parser.create(options, visit(options, root, {
        name: "normalizeSyntax",
        format: function(node) {
          const fmtDict = normalizeFormatObject(node.args[0]);
          if (fmtDict["type"] === "\\variable") {
            let id;
            if (fmtDict["\\id"] === undefined) {
              id = "_";
            } else {
              id = "_" + fmtDict["\\id"];
            }
            return variableNode(id);
          }
          return normalNumber;
        },
        numeric: function (node) {
          if (ref && ref.op === Parser.FORMAT &&
              checkNumberFormat(ref.args[0], node)) {
            return normalNumber;
          }
          return node;
        },
        additive: function (node) {
          const args = [];
          if (ref && ref.op === Parser.FORMAT &&
              checkNumberFormat(ref.args[0], node)) {
            // Found a mixed number.
            return normalNumber;
          }
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);
        },
        multiplicative: function(node) {
          const args = [];
          if (ref && ref.op === Parser.FORMAT &&
              checkNumberFormat(ref.args[0], node)) {
            // Found a fraction or number in scientific notation.
            return normalNumber;
          }
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);
        },
        unary: function(node) {
          const args = [];
          switch (node.op) {
            case Parser.ADD:
            case Parser.SUB:
              if (ref && ref.op === Parser.FORMAT &&
                checkNumberFormat(ref.args[0], node.args[0])) {
              return normalNumber;
              }
              break;
            }
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);;
        },
        variable: function(node) {
          const id = node.args[0];
          let name;
          if (ref && ref.op === Parser.FORMAT) {
            name = checkVariableFormat(ref.args[0], id);
          } else {
            name = id;
          }
          return variableNode(name);
        },
        exponential: function(node) {
          const args = [];
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);
        },
        comma: function(node) {
          const args = [];
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);
        },
        equals: function(node) {
          const args = [];
          node.args.forEach(function (n, i) {
            args.push(normalizeSyntax(options, n, ref.args[i]));
          });
          return newNode(node.op, args);
        }
      }), root.location);
      return node;
    }

    function cancelFactors(options, node) {
      if (node.op !== Parser.MUL) {
        return node;
      }
      let changed = false;
      const numers = {};
      const denoms = {};
      let hasMinusOne = false;
      node.args.forEach(function(n, i) {
        let f;
        const ff = factors(options, n, {}, false, true, true);
        ff.forEach(function (f) {
          const isDenom = f.op === Parser.POW && isNeg(options, f.args[1]);
          const k = isDenom && isMinusOne(f.args[1]) && f.args[0] ||  // Strip exponent.
              isDenom && newNode(Parser.POW, [f.args[0], negate(f.args[1])]) || // Invert exponent.
              f;
          const mv = mathValue(options, k, true);
          if (isOne(mv)) {
            // Skip 1s.
            return;
          }
          if (isMinusOne(f)) {
            hasMinusOne = !hasMinusOne;
            changed = true;
          } else {
            const key = mv !== null ? String(mv) : "nid$" + ast.intern(k);
            if (isDenom) {
              if (!denoms[key]) {
                denoms[key] = [];
              }
              denoms[key].push(f);
            } else {
              if (!numers[key]) {
                numers[key] = [];
              }
              numers[key].push(f);
            }
          }
        });
      });
      assert(!numers["1"] && !denoms["1"], "2000: Identity multiplication should be factored out by now.");
      assert(!numers["-1"] && !denoms["-1"], "2000: Negative multiplication should be factored out by now.");
      const nKeys = Object.keys(numers);
      const dKeys = Object.keys(denoms);
      if (nKeys.length === 0 || dKeys.length === 0 ||
          dKeys.length === 1 && dKeys[0] === "-1") {
        // One case is a sole synthetic -1 with no other denoms.
        return node;
      }
      // Now do the canceling.
      nKeys.forEach(function (k) {
        const nn = numers[k];
        const dd = denoms[k];
        if (dd) {
          const count = dd.length > nn.length ? nn.length : dd.length;
          numers[k] = k === "0" ? nn.slice(0, 1) : nn.slice(count); // Slice off count items.
          denoms[k] = k === "0" ? dd.slice(0, 1) : dd.slice(count); // Keep zeros.
          changed = true;
        }
      });
      if (!changed) {
        return node;
      }
      let nargs = [];
      let dargs = [];
      nKeys.forEach(function (k) {
        nargs = nargs.concat(numers[k]);  // Save survivors.
      });
      dKeys.forEach(function (k) {
        dargs = dargs.concat(denoms[k]);
      });

      if (hasMinusOne) {
        if (dargs.length > 0) {
          dargs.unshift(negate(dargs.shift()));
        } else {
          nargs.unshift(negate(nargs.shift()));
        }
      }
      let n, d;
      if (nargs.length) {
        n = multiplyNode(nargs, true);
      } else {
        n = null;
      }
      if (dargs.length > 0) {
        d = multiplyNode(dargs, true);
      } else {
        d = null;
      }
      if (!n && !d) {
        return nodeOne;
      } else if (!d) {
        return n;
      } else if (!n) {
        return d;
      } else {
        return multiplyNode([n, d], true);
      }
    }

    function cancelTerms(node, location) {
      // Cancel like terms of opposite sign.
      if (node.op !== Parser.ADD) {
        return node;
      }
      const pos = {};
      const neg = {};
      node.args.forEach(function(n, i) {
        let isNegative = false;
        let f;
        if (isNeg(options, constantPart(n))) {
          isNegative = true;
          f = negate(n);
        } else {
          f = n;
        }
        const mv = mathValue(options, f, true);
        const key = mv !== null ? String(mv) : "nid$" + ast.intern(f);
        if (isNegative) {
          if (!neg[key]) {
            neg[key] = [];
          }
          neg[key].push(n);
        } else {
          if (!pos[key]) {
            pos[key] = [];
          }
          pos[key].push(n);
        }
      });
      const pKeys = Object.keys(pos);
      const nKeys = Object.keys(neg);
      if (pKeys.length === 0 || nKeys.length === 0 ||
         nKeys.length === 1 && nKeys[0] === "-1") {
        // One case is a sole synthetic -1 with not other denoms.
        return node;
      }
      // Now do the canceling.
      let args = [];
      let changed = false;
      pKeys.forEach(function (k) {
        const nn = pos[k];
        const dd = neg[k];
        if (dd) {
          const count = dd.length > nn.length ? nn.length : dd.length;
          pos[k] = nn.slice(count);  // Slice off count items.
          neg[k] = dd.slice(count);
          changed = true;
        }
      });
      if (!changed) {
        return node;
      }
      pKeys.forEach(function (k) {
        args = args.concat(pos[k]);  // Save survivors.
      });
      nKeys.forEach(function (k) {
        args = args.concat(neg[k]);
      });
      if (args.length) {
        return addNode(args);
      } else {
        return nodeZero;
      }
    }

    function cancelEquals(node) {
      // Cancel like constants on both sides of a comparision.
      if (!isComparison(node.op) ||
          node.args.length != 2 ||
          isZero(node.args[0]) ||
          isZero(node.args[1])) {
        return node;
      }
      const lnode = node.args[0];
      const rnode = node.args[1];
      var largs, rargs;
      if (lnode.op === Parser.MUL) {
        largs = lnode.args;
      } else {
        largs = [lnode];
      }
      if (rnode.op === Parser.MUL) {
        rargs = rnode.args;
      } else {
        rargs = [rnode];
      }
      // We have multiplication on each side.
      const lhs = {};
      const rhs = {};
      largs.forEach(function(n) {
        const mv = mathValue(options, n, true);
        const key = mv !== null ? String(mv) : "lvars";
        if (!lhs[key]) {
          lhs[key] = [];
        }
        lhs[key].push(n);
      });
      rargs.forEach(function(n) {
        const mv = mathValue(options, n, true);
        const key = mv !== null ? String(mv) : "rvars";
        if (!rhs[key]) {
          rhs[key] = [];
        }
        rhs[key].push(n);
      });
      const lKeys = Object.keys(lhs);
      const rKeys = Object.keys(rhs);
      // Now do the canceling.
      const args = [];
      let changed = false;
      lKeys.forEach(function (k) {
        const ll = lhs[k];
        const rr = rhs[k];
        if (rr) {
          const count = rr.length > ll.length ? ll.length : rr.length;
          lhs[k] = ll.slice(count);  // Slice off count items from each set.
          rhs[k] = rr.slice(count);
          changed = true;
        }
      });
      if (!changed) {
        return node;
      }
      var largs = [];
      var rargs = [];
      lKeys.forEach(function (k) {
        largs = largs.concat(lhs[k]);  // Save survivors.
      });
      rKeys.forEach(function (k) {
        rargs = rargs.concat(rhs[k]);
      });
      let larg, rarg;
      if (largs.length === 0) {
        larg = nodeOne;
      } else {
        larg = multiplyNode(largs);
      }
      if (rargs.length === 0) {
        rarg = nodeOne;
      } else {
        rarg = multiplyNode(rargs);
      }
      let lmv, rmv;
      if ((lmv = mathValue(options, larg)) && (rmv = mathValue(options, rarg)) &&
          lmv.cmp(rmv) === 0) {
        larg = rarg = nodeZero;
      }
      return binaryNode(node.op, [larg, rarg]);
    }

    function factorQuadratic(node) {
      let coeffs, vars, roots;
      // If not, check to see if there are any integer solutions to the
      // quadratic equation.
      if ((coeffs = isPolynomial(node)) &&
          coeffs.length === 3 &&
          (vars = variables(node)).length === 1) {
        roots = solveQuadratic(options, coeffs[2], coeffs[1], coeffs[0]);
        if (roots) {
          node = multiplyNode([
            addNode([variableNode(vars[0]), negate(numberNode(options, roots[0]))]),
            addNode([variableNode(vars[0]), negate(numberNode(options, roots[1]))]),
          ]);
        }
      }
      return node;
    }
    function combineLikeFactors(ff) {
      if (!ff || ff.length === 0) {
        return [];
      }
      if (ff.length === 1) {
        return ff;
      }
      let base;
      let expo = bigZero;
      let baseNid = 0;
      ff.forEach(function (f) {
        let b, e;
        if (f.op === Parser.POW) {
          b = f.args[0];
          e = mathValue(options, f.args[1], true);
        } else {
          b = f;
          e = bigOne;
        }
        assert(e !== null);
        assert(baseNid === 0 || ast.intern(b) === baseNid);
        baseNid = ast.intern(b);
        base = b;
        expo = expo.plus(e);
      });
      return [newNode(Parser.POW, [base, numberNode(options, expo)])];
    }
    
    function crossMultiply(options, n1, n2) {
      // Get each expr as a single fraction.
      n1 = fractionize(options, together(options, n1));
      n2 = fractionize(options, together(options, n2));
      // Cross multiply.
      const n10n21 = multiplyNode([n1.args[0], n2.args[1]], true);
      const n11n20 = multiplyNode([n1.args[1], n2.args[0]], true);
      n10n21.flags = {"isAlgebraic": true};
      n11n20.flags = {"isAlgebraic": true};
      return [n10n21, n11n20];
    }

    function getFlags(node) {
      const flags = {};
      Object.keys(node).forEach(key => {
        if (key !== 'op' && key !== 'args') {
          flags[key] = node[key];
        }
      });
      return flags;
    }

    function setFlags(node, flags) {
      Object.keys(flags).forEach(key => {
        node[key] = flags[key];
      });
    }

    function radicalToPower(options, node) {
      const flags = getFlags(node);
      if (node.op === Parser.SQRT) {
        const base = node.args[0];
        const nthRoot = node.args[1];
        nthRoot.numberFormat = "integer";
        node = newNode(Parser.POW, [base, newNode(Parser.FRAC, [nodeOne, nthRoot])]);
      }
      const args = [];
      node.args.forEach(function (arg) {
        if (arg.op) {
          arg = radicalToPower(options, arg);
        }
        args.push(arg);
      });
      node = newNode(node.op, args);
      setFlags(node, flags);
      return node;
    }

    function together(options, node) {
      // Puts an algebraic expr together by denesting and combining fractional subexpressions.
      node = radicalToPower(options, node);
      if (node.op === Parser.DIV) {
        node = newNode(Parser.FRAC, [node.args[0], node.args[1]]);
      }
      if (node.op === Parser.POW) {
        let base = node.args[0];
        let expo = node.args[1];
        base = together(options, base);
        expo = together(options, expo);
        // (\frac{x}{y})^a => \frac{x^a}{y^a}
        if (base.op === Parser.FRAC) {
          node = newNode(Parser.FRAC, [
            newNode(Parser.POW, [base.args[0], expo]),
            newNode(Parser.POW, [base.args[1], expo])
          ]);
        }
        if (expo.op === Parser.FRAC) {
          var numer = expo.args[0];
          var denom = expo.args[1];
          // x^{\frac{-a}{b}} => x^{-\frac{a}{b}}
          if (numer.op === Parser.SUB && numer.args.length === 1) {
            expo = newNode(Parser.SUB, [newNode(Parser.FRAC, [numer.args[0], denom])]);
            node = newNode(Parser.POW, [base, expo]);
          }
        }
        // x^{-a} => \frac{1}{x^a}
        if (expo.op === Parser.SUB && expo.args.length === 1) {
          node = newNode(Parser.FRAC, [
            nodeOne,
            newNode(Parser.POW, [base, expo.args[0]])
          ]);
        }
      }
      if (node.op === Parser.FRAC) {
        var numer = node.args[0];
        var denom = node.args[1];
        numer = together(options, numer);
        denom = together(options, denom);
        if (denom.op === Parser.FRAC) {
          node = multiplyNode([
            numer,
            newNode(Parser.FRAC, [denom.args[1], denom.args[0]])
          ]);
        } else if (numer.op === Parser.FRAC) {
          node = multiplyNode([numer, newNode(Parser.FRAC, [nodeOne, denom])]);
        }
      }
      if (node.op === Parser.MUL || node.op === Parser.TIMES || node.op === Parser.CDOT) {
        var numers = [];
        var denoms = [];
        node.args.forEach(function (arg) {
          arg = together(options, arg);
          if (arg.op === Parser.FRAC) {
            numers.push(arg.args[0]);
            denoms.push(arg.args[1]);
          } else {
            numers.push(arg);
          }
        });
        if (denoms.length) {
          node = newNode(Parser.FRAC, [multiplyNode(numers), multiplyNode(denoms)]);
        }
      }
      if (node.op === Parser.SUB && node.args.length === 2) {
        let minuend = node.args[0];
        let subtrahend = node.args[1];
        minuend = together(options, minuend);
        subtrahend = together(options, subtrahend);
        if (subtrahend.op === Parser.FRAC) {
          node = addNode([
            minuend,
            newNode(Parser.FRAC, [
              newNode(Parser.SUB, [subtrahend.args[0]]),
              subtrahend.args[1]
            ])
          ]);
        } else {
          node = addNode([minuend, newNode(Parser.SUB, [subtrahend])]);
        }
      }
      if (node.op === Parser.SUB && node.args.length === 1) {
        node.args[0] = together(options, node.args[0]);
        if (node.args[0].op === Parser.FRAC) {
          var numer = node.args[0].args[0];
          var denom = node.args[0].args[1];
          node = newNode(Parser.FRAC, [newNode(Parser.SUB, [numer]), denom]);
        }
      }
      if (node.op === Parser.ADD && !node.isRepeating) {
        var numers = [];
        var denoms = [];
        let hasFraction;
        node.args.forEach(function (arg) {
          arg = together(options, arg);
          if (arg.op === Parser.FRAC) {
            numers.push(arg.args[0]);
            denoms.push(arg.args[1]);
            hasFraction = true;
          } else {
            numers.push(arg);
            denoms.push(nodeOne);
          }
        });
        if (hasFraction) {
          for (let i = 0; i < numers.length; i++) {
            const commonDenomFactor = denoms.slice(0, i).concat(denoms.slice(i + 1, denoms.length + 1));
            numers[i] = multiplyNode(commonDenomFactor.concat(numers[i]));
          }
          node = newNode(Parser.FRAC, [addNode(numers), multiplyNode(denoms)]);
        }
      }
      return node;
    }

    function fractionize(options, node) {
      if (node.op !== Parser.FRAC) {
        node = newNode(Parser.FRAC, [node, nodeOne]);
      }
      return node;
    }

    function normalizeMul(node) {
      if (node.op === Parser.DIV || node.op === Parser.FRAC) {
        if (node.args[1].op === Parser.POW) {
          // We have a denom with an exponent, so just invert it.
          const denom = node.args[1];
          const b = denom.args[0];
          const e = denom.args[1];
          node = multiplyNode([node.args[0], newNode(Parser.POW, [b, negate(e, true)])], true);
        } else {
          node = fractionNode(node.args[0], node.args[1]);
        }
      } else if (node.op === Parser.CDOT || node.op === Parser.TIMES || node.op === Parser.COEFF) {
        node = multiplyNode(node.args, true);
      }
      return node;
    }

    // normalize() replaces subtraction with addition and division with
    // multiplication. It does not perform expansion or simplification so that
    // the basic structure of the expression is preserved. Also, flattens binary
    // trees into N-ary nodes.
    const normalizedNodes = [];
    let normalizeLevel = 0;
    function normalize(options, root) {
      assert(options);
      assert(root && root.args, "2000: Internal error. root=" + JSON.stringify(root) + " options=" + JSON.stringify(options));
      let nid = ast.intern(root);
      if (root.normalizeNid === nid) {
        return root;
      }
      let cachedNode;
      if ((cachedNode = normalizedNodes[nid]) !== undefined) {
        return cachedNode;
      }
      const rootNid = nid;
      // if (normalizeLevel === 0) {
      //   console.log("normalize() node: " + JSON.stringify(stripMetadata(root), null, 2));
      // }
      normalizeLevel++;
      let node = Parser.create(options, visit(options, root, {
        name: "normalize",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          if (node.op === Parser.SUB) {
            assert(node.args.length === 2, "2000: Internal error.");
            node = addNode([node.args[0], negate(node.args[1], true)], true /*flatten*/);
          } else if (node.op === Parser.PM) {
            assert(node.args.length === 2, "2000: Operator \pm can only be used on binary nodes");
            node = addNode([
              node.args[0],
              unaryNode(Parser.PM, [node.args[1]])
            ]);
          } else if (node.args.some(function (arg) {
            return arg.op === Parser.INTEGRAL && arg.args.length === 3;
          })) {
            // Have at least one definite integral.
            return normalizeIntegralAddition(node);
          }
          if (node.op === Parser.MATRIX ||
              node.op === Parser.BACKSLASH) {
            // Don't flatten matrix nodes.
            return node;
          }
          if (isRepeating(node) && option(options, "convertRepeatingDecimalToFraction")) {
            node = repeatingDecimalToFraction(options, node);
            return node;
          }
          let mv = bigZero;
          let args = [];
          node.args.forEach(function (n) {
            if (n.op === Parser.NUM && isNumeric(n) &&
                !option(options, "doingSimplified")) {
              // The last condition is a secret handshake that says we are in
              // isSimplified so don't merge number.
              mv = mv.plus(mathValue(options, n, true));
            } else {
              args = args.concat(normalize(options, n));
            }
          });
          const isMixedNumber = node.isMixedNumber;
          const isRepeatingFlag = node.isRepeating;
          if (!isZero(mv) || args.length === 0) {
            // Have non-zero term or solo zero term.
            args.unshift(numberNode(options, mv));
          }
          node = newNode(node.op, args);
          if (isNumeric(node) && !option(options, "doingSimplified")) {
            // The last condition is a secret handshake that says we are in
            // isSimplified so don't merge number.
            node = commonDenom(node);
          }
          node.isMixedNumber = isMixedNumber;
          node = flattenNestedNodes(node);
          node.isMixedNumber = isMixedNumber;
          node.isRepeating = isRepeatingFlag;
          return sort(node);
        },
        multiplicative: function(node) {
          if (node.op === Parser.CDOT || node.op === Parser.DIV || node.op === Parser.FRAC || node.op === Parser.TIMES || Parser.COEFF) {
            node = normalizeMul(node);
          }
          let args = [];
          // Flatten nested multiplication.
          // FIXME can't use flattenNestedNode because of slight differences
          let hasPM;
          let hasMinusOne = false;
          node.args.forEach(function (n) {
            n = normalize(options, n);
            if (isOne(n)) {
              // If number node one, then erase it.
            } else if (isMinusOne(n)) {
              hasMinusOne = !hasMinusOne;
            } else {
              if (n.op === Parser.MUL) {
                // Flatten
                args = args.concat(n.args);
              } else if (n.op === Parser.PM) {
                hasPM = true;
                args.push(n.args[0]);
              } else {
                args.push(n);
              }
            }
          });
          const isRepeatingFlag = node.isRepeating;
          if (hasMinusOne) {
            if (args.length === 0) {
              args.unshift(nodeMinusOne);
            } else {
              args.unshift(negate(args.shift()));
            }
          }
          if (args.length === 0) {
            node = nodeOne;
          } else if (args.length === 1) {
            node = args[0];
          } else {
            node = sort(binaryNode(node.op, sortFactors(args), true));
          }
          if (hasPM) {
            node = unaryNode(Parser.PM, [node]);
          }
          node.isRepeating = isRepeatingFlag;
          return node;
        },
        unary: function(node) {
          if (isGrouping(options, node, normalizeLevel)) {
            return normalize(options, node.args[0]);
          }
          switch (node.op) {
          case Parser.SUBSCRIPT:
            if (node.args[0].op === Parser.EVALAT) {
              let n = node.args[1];
              let name;
              if (n.op === Parser.EQL) {
                assert(n.args[0].op === Parser.VAR);
                name = n.args[0].args[0];
                n = n.args[1];
              } else {
                const vv = variables(node.args[0]);
                name = vv[0];
              }
              Parser.env[name] = {
                type: "param",
                node: n,
              };
              node = node.args[0].args[0];
            }
            break;
          }
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalize(options, n));
          });
          node = newNode(node.op, args);
          switch (node.op) {
          case Parser.SUBSCRIPT:
          case Parser.SUB:
            if (node.args[0].op === Parser.POW && isNeg(options, node.args[0].args[1])) {
              node = negate(node.args[0]);
            } else {
              node = negate(node.args[0], true);
            }
            break;
          case Parser.PERCENT:
            if (args[0].op === Parser.NUM) {
              var mv = mathValue(options, args[0]);
              node = numberNode(options, divide(mv, 100));
            } else {
              node = multiplyNode([
                binaryNode(Parser.POW, [
                  numberNode(options, "100"),
                  nodeMinusOne
                ]), args[0]]);
            }
            break;
          case Parser.PM:
            if (isNeg(options, mathValue(options, args[0], true))) {
              const args = node.args.slice(0);
              node = newNode(node.op, [negate(args.shift(), true)].concat(args));
            }
            break;
          case Parser.FACT:
            var mv = mathValue(options, args[0]);
            if (mv) {
              node = numberNode(options, factorial(mv));
            } else {
              node = unaryNode(node.op, [args[0]]);
            }
            break;
          case Parser.SQRT:
            var base = node.args[0];
            var root = node.args[1];
            node = newNode(Parser.POW, [base, newNode(Parser.POW, [root, nodeMinusOne])]);
            break;
          case Parser.INT:
            node = normalizeIntegral(node);
            break;
          case Parser.SIN:
          case Parser.COS:
          case Parser.SINH:
          case Parser.COSH:
          case Parser.ARCSINH:
          case Parser.ARCCOSH:
            node = normalizeTrigIdent(node);
            break;
          case Parser.TAN:
          case Parser.TANH:
            {
              const arg0 = normalize(options, node.args[0]);
              // tan x = sin x / cos x
              const s = node.op === Parser.TAN ? Parser.SIN : Parser.SINH;
              const c = node.op === Parser.TAN ? Parser.COS : Parser.COSH;
              node = multiplyNode([
                newNode(s, [arg0]),
                binaryNode(Parser.POW, [
                  newNode(c, [arg0]),
                  nodeMinusOne
                ])
              ]);
            }
            break;
          case Parser.COT:
          case Parser.COTH:
            {
              const arg0 = normalize(options, node.args[0]);
              const s = node.op === Parser.COT ? Parser.SIN : Parser.SINH;
              const c = node.op === Parser.COT ? Parser.COS : Parser.COSH;
              node = multiplyNode([
                newNode(c, [arg0]),
                binaryNode(Parser.POW, [
                  newNode(s, [arg0]),
                  nodeMinusOne
                ])
              ]);
            }
            break;
          case Parser.SEC:
          case Parser.SECH:
            {
              const arg0 = normalize(options, node.args[0]);
              const c = node.op === Parser.SEC ? Parser.COS : Parser.COSH;
              node = multiplyNode([
                binaryNode(Parser.POW, [
                  newNode(c, [arg0]),
                  nodeMinusOne
                ])
              ]);
            }
            break;
          case Parser.CSC:
          case Parser.CSCH:
            {
              const arg0 = normalize(options, node.args[0]);
              const s = node.op === Parser.CSC ? Parser.SIN : Parser.SINH;
              node = multiplyNode([
                binaryNode(Parser.POW, [
                  newNode(s, [arg0]),
                  nodeMinusOne
                ])
              ]);
            }
            break;
          case Parser.ABS:
            node = normalizeAbs(node);
            break;
          default:
            // Do nothing.
            break;
          }
          return node;
        },
        variable: function(node) {
          let val;
          if (node.args[0] === "i" && !option(options, "dontSimplifyImaginary")) {
            node = nodeImaginary;
          } else if (node.args[0] === "\\infty") {
            node = nodePositiveInfinity;
          } else if (node.args[0] === "\\radian") {
            node = nodeOne; // Assume radians
          } else if (node.args[0] === "\\degree") {
            node = fractionNode(nodePI, numberNode(options, "180"));
          } else if (Parser.env[node.args[0]] &&
                    Parser.env[node.args[0]].type === "param") {
            node = Parser.env[node.args[0]].node;
          } else if (option(options, "treatLettersAsVariables") &&
                     Parser.env[node.args[0]] &&
                     Parser.env[node.args[0]].type === "unit") {
            const vv = [];
            node.args[0].split("").forEach(function (v) {
              vv.push(variableNode(v));
            });
            return multiplyNode(vv);
          } else if ((val = Parser.env[node.args[0]]) &&
                     val.type === "param") {
            node = val.value;
          }
          return node;
        },
        exponential: function(node) {
          const n0 = node;
          if (node.args.length === 2 &&
              node.args[0].op === Parser.VAR &&
              node.args[1].op === Parser.VAR &&
              node.args[1].args[0].indexOf("'") === 0) {
            // Merge primes. We use POW to encode primes.
            node = variableNode(node.args[0].args[0] + node.args[1].args[0]);
            return node;
          }
          let isUnit = false;
          var base = node.args[0];
          const expo = node.args[1];
          // TODO more identities here.
          if (node.op === Parser.POW && node.args.length === 2 && base.op === Parser.TANH &&
              expo.op === Parser.NUM && expo.args[0] === "2") {
            // tanh^2 = 1 - sech^2
            return addNode([
              nodeOne,
              negate(binaryNode(Parser.POW, [
                binaryNode(Parser.POW, [
                  newNode(Parser.COSH, base.args),
                  nodeTwo]),
                nodeMinusOne
              ]))
            ]);
          } else if (node.op === Parser.POW && node.args.length === 2 &&
                     base.op === Parser.SINH && ast.intern(expo) === ast.intern(nodeTwo)) {
            // sinh^2 = cosh^2 - 1
            return addNode([
              binaryNode(Parser.POW, [
                newNode(Parser.COSH, base.args),
                nodeTwo]),
              nodeMinusOne
            ]);
          } else if (node.op === Parser.POW && node.args.length === 2 && base.op === Parser.COTH &&
                     expo.op === Parser.NUM && expo.args[0] === "2") {
            // coth^2 = 1 + csch^2 = (1 + sin^2)/sin^2
            return addNode([
              nodeOne, binaryNode(Parser.POW, [
                binaryNode(Parser.POW, [
                  newNode(Parser.SINH, base.args),
                  nodeTwo]),
                nodeMinusOne
              ])
            ]);
          } else if (node.op === Parser.POW && node.args.length === 2 && base.op === Parser.SECH &&
                     expo.op === Parser.NUM && expo.args[0] === "2") {
            // sech^2 = 1/cosh^2
            return binaryNode(Parser.POW, [binaryNode(Parser.POW, [newNode(Parser.COSH, base.args), nodeTwo]), nodeMinusOne]);
          } else if (node.op === Parser.POW && node.args.length === 2 && base.op === Parser.CSCH &&
                     expo.op === Parser.NUM && expo.args[0] === "2") {
            // csch^2 = 1/sinh^2
            return binaryNode(Parser.POW, [binaryNode(Parser.POW, [newNode(Parser.SINH, base.args), nodeTwo]), nodeMinusOne]);
          } else if (option(options, "treatLettersAsVariables") &&
                     base.op === Parser.VAR &&
                     Parser.env[base.args[0]] &&
                     Parser.env[base.args[0]].type === "unit") {
            isUnit = true;
          }
          var args = [];
          const hasMinusOne = false;
          node.args.forEach(function (n) {
            args = args.concat(normalize(options, n));
          });
          node = newNode(node.op, args);
          var args = [];
          switch(node.op) {
          case Parser.LOG:
            // log_e has special meaning so don't normalize 'e' in that case.
            if (ast.intern(node.args[0]) === ast.intern(nodeE)) {
              args.push(nodeE);
            } else {
              args.push(normalize(options, node.args[0]));
            }
            if (node.args.length > 1) {
              args = args.concat(node.args.slice(1));
            }
            node = normalizeLogIdent(args[0], args[1]);
            break;
          case Parser.POW:
            if (isMinusOne(node.args[0]) && toNumber(mathValue(options, node.args[1], true)) === 0.5) {
              return nodeImaginary;
            } else if (isMinusOne(node.args[0]) && isMinusOne(node.args[1])) {
              return nodeMinusOne;
            } else if (node.args.length === 2 && node.args[1].op === Parser.LOG) {
              // y^{log{x}} => x^{log{y}}
              const n1 = node.args[0];
              const n2 = node.args[1].args[1];
              var base = node.args[1].args[0];
              var args = sort(multiplyNode([n1, n2])).args; // Synthetic node for sorting.
              return binaryNode(Parser.POW, [
                args[0],
                binaryNode(node.args[1].op, [base, args[1]])
              ]);
            } else if (option(options, "treatLettersAsVariables") && isUnit && node.args[0].op === Parser.MUL) {
              // Associate power to last variable of base.
              var base = node.args[0];
              const last = base.args.pop();
              base = base.args.length === 1 && base[0] || base;
              node = multiplyNode([base, binaryNode(Parser.POW, [last, node.args[1]])]);
            }
            break;
          default:
            break;
          }
          return node;
        },
        comma: function(node) {
          let vals = [];
          node.args.forEach(function (n) {
            vals = vals.concat(normalize(options, n));
          });
          var node = newNode(node.op, vals);
          return sort(node);
        },
        equals: function(node) {
          assert(node.args.length === 2, "2000: Internal error.");
          const args = [];
          node.args.forEach(function (n) {
            n = normalize(options, n);
            args.push(n);
          });
          node = binaryNode(node.op, args);
          if (node.op === Parser.GT || node.op === Parser.GE || node.op === Parser.NLESS) {
            // Normalize inequalities to LT and LE. (GE || NLESS) --> LE
            node.op = node.op === Parser.GT ? Parser.LT : Parser.LE;
            // Swap args.
            const t = node.args[0];
            node.args[0] = node.args[1];
            node.args[1] = t;
          } else if (node.op === Parser.NGTR) {
            // Normalize NGTR --> LE. Don't need to swap args.
            node.op = Parser.LE;
          }
          node = sort(node);   // Sort so that the lnodes after reconstruction compare
          // Doesn't seem to help, yet.
          // node = cancelEquals(node);
          // If the rhs is not already normalized to 0, then normalize it now.
          if (node.op !== Parser.COLON &&
              !isZero(mathValue(options, node.args[1], true))) {
            // a=b -> a-b=0
            node = binaryNode(node.op, [
              addNode([
                node.args[0],
                multiplyNode([nodeMinusOne, node.args[1]], true) // Flatten, don't use negate.
              ], true),
              nodeZero,
            ]);
          } else if (!isZero(mathValue(options, node.args[1], true)) && !isOne(mathValue(options, node.args[1], true))) {
            node = binaryNode(node.op, [
              multiplyNode([
                node.args[0],
                binaryNode(Parser.POW, [node.args[1], nodeMinusOne])
              ]),
              nodeOne,
            ]);
          }
          if (node.op === Parser.COLON) {
            // RHS is now 1 the ratio is expressed by the LHS.
            node = node.args[0];
          }
          return node;
        }
      }), root.location);
      normalizeLevel--;
      // If the node has changed, simplify again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        // console.log("normalize() nid=" + nid);
        // if (nid === 91 || nid === 94) {
        //   console.log("normalize() node=" + JSON.stringify(stripMetadata(JSON.parse(JSON.stringify(node))), null, 2))
        // }
        node = normalize(options, node);
      }
      node.normalizeNid = nid;
      normalizedNodes[rootNid] = node;
      return node;
    }

    function tagNode(node) {
      node.flags = Parser.flags;
      if (node.flags.hasSum || node.flags.hasIntegral ||
          node.flags.hasLim || node.flags.hasDeriv) {
        node.flags.hasCalculus = true;
      } else if (!node.flags.hasRel &&
                 !node.flags.hasVector &&
                 !node.flags.hasMatrix &&
                 !node.flags.hasUnit &&
                 !node.flags.hasComma &&
                 !node.flags.hasPlusMinus) {
        if (node.flags.hasDegree && !node.flags.hasTrig) {
          node.flags.hasUnit = true;
        } else if (isNumeric(node)) {
          node.flags.isNumeric = true;
        } else if (node.flags.hasTrig || node.flags.hasHyperTrig ||
                   node.flags.hasPower || node.flags.hasLog) {
          node.flags.isAlgebraic = false;
        } else {
          node.flags.isAlgebraic = true;
        }
      }
    }

    let normalizeSympyLevel = 0;
    function normalizeSympy(options, root) {
      assert(root && root.args, "2000: Internal error.");
      const nid = ast.intern(root);
      // if (normalizeSympyLevel === 0) {
      //   console.log("normalizeSympy() node: " + JSON.stringify(stripNids(root), null, 2));
      // }
      normalizeSympyLevel++;
      const node = Parser.create(options, visit(options, root, {
        name: "normalize",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          Parser.flags.hasPlusMinus =
            Parser.flags.hasPlusMinus ||
            node.op === Parser.PM;
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeSympy(options, n));
          });
          return Object.assign({}, node, newNode(node.op, args));
        },
        multiplicative: function(node) {
          Parser.flags.hasFrac =
            Parser.flags.hasFrac ||
            node.op === Parser.FRAC;
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeSympy(options, n));
          });
          return Object.assign({}, node, binaryNode(node.op, args, true));
        },
        unary: function(node) {
          if (node.op === Parser.NONE) {
            return node;
          }
          if (isGrouping(options, node, normalizeSympyLevel)) {
            return normalizeSympy(options, node.args[0]);
          }
          if (node.op === Parser.PAREN && node.args.length === 1 && node.args[0].op !== Parser.COMMA) {
            return normalizeSympy(options, node.args[0]);
          }
          Parser.flags.hasPlusMinus =
            Parser.flags.hasPlusMinus ||
            node.op === Parser.PM;
          Parser.flags.hasVector =
            Parser.flags.hasVector ||
            node.op === Parser.MATHBF;
          Parser.flags.hasUnit =
            Parser.flags.hasUnit ||
            node.op === Parser.TEXT;
          Parser.flags.hasAbs =
            Parser.flags.hasAbs ||
            node.op === Parser.ABS;
          Parser.flags.hasSum =
            Parser.flags.hasSum ||
            node.op === Parser.SUM;
          Parser.flags.hasIntegral =
            Parser.flags.hasIntegral ||
            node.op === Parser.INTEGRAL;
          Parser.flags.hasDeriv =
            Parser.flags.hasDeriv ||
            node.op === Parser.DERIV;
          Parser.flags.hasLim =
            Parser.flags.hasLim ||
            node.op === Parser.LIM;
          Parser.flags.hasTrig =
            Parser.flags.hasTrig ||
            node.op === Parser.SIN ||
            node.op === Parser.COS ||
            node.op === Parser.TAN ||
            node.op === Parser.SEC ||
            node.op === Parser.COT ||
            node.op === Parser.CSC ||
            node.op === Parser.ARCSIN ||
            node.op === Parser.ARCCOS ||
            node.op === Parser.ARCTAN ||
            node.op === Parser.ARCSEC ||
            node.op === Parser.ARCCSC ||
            node.op === Parser.ARCCOT;
          Parser.flags.hasHyperTrig =
            Parser.flags.hasHyperTrig ||
            node.op === Parser.SINH ||
            node.op === Parser.COSH ||
            node.op === Parser.TANH ||
            node.op === Parser.SECH ||
            node.op === Parser.COTH ||
            node.op === Parser.CSCH ||
            node.op === Parser.ARCSINH ||
            node.op === Parser.ARCCOSH ||
            node.op === Parser.ARCTANH ||
            node.op === Parser.ARCSECH ||
            node.op === Parser.ARCCSCH ||
            node.op === Parser.ARCCOTH;
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeSympy(options, n));
          });
          return Object.assign({}, node, newNode(node.op, args));
        },
        variable: function(node) {
          Parser.flags.hasComma =
            Parser.flags.hasComma ||
            node.args[0] === "\\emptyset";
          Parser.flags.hasPlusC =
            Parser.flags.hasPlusC ||
            node.args[0] === "C";
          Parser.flags.hasDegree =
            Parser.flags.hasDegree ||
            node.args[0] === "\\degree";
          return node;
        },
        exponential: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeSympy(options, n));
          });
          Parser.flags.hasLog =
            Parser.flags.hasLog ||
            node.op === Parser.LOG ||
            node.op === Parser.LN;
          Parser.flags.hasPower =
            Parser.flags.hasPower ||
            node.op === Parser.POW &&
            (node.args[1].op === Parser.VAR || variablePart(node.args[1]) !== null);
          Parser.flags.hasFrac =
            Parser.flags.hasFrac ||
            node.op === Parser.POW &&
            (variablePart(node.args[1]) === null && isNeg(options, mathValue(options, node.args[1], true)));
          return Object.assign({}, node, newNode(node.op, args));
        },
        comma: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            Parser.flags = {};
            args = args.concat(normalizeSympy(options, n));
          });
          if (node.op === Parser.MATRIX) {
            Parser.flags = {
              hasMatrix: true,
            };
          } else if (node.op === Parser.ANGLEBRACKET)  {
            Parser.flags = {
              hasVector: true,
            };
          } else {
            Parser.flags = {
              hasComma: true,
            };
          }
          return Object.assign({}, node, newNode(node.op, args));
        },
        equals: function(node) {
          Parser.flags.hasColon =
            Parser.flags.hasColon ||
            node.op === Parser.COLON;
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeSympy(options, n));
          });
          Parser.flags.hasRel = true;
          return Object.assign({}, node, newNode(node.op, args));
        }
      }), root.location);
      normalizeSympyLevel--;
      if (normalizeSympyLevel === 0) {
        tagNode(node);
      }
      return node;
    }

    //var normalizeCalculateLevel = 0;
    function normalizeCalculate(options, root) {
      assert(root && root.args, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.normalizeCalculateNid === nid) {
        return root;
      }
      const rootNid = nid;
      // if (normalizeCalculateLevel === 0) {
      //   console.log("normalizeCalculate() node: " + JSON.stringify(stripNids(root), null, 2));
      // }
      // normalizeCalculateLevel++;
      let node = Parser.create(options, visit(options, root, {
        name: "normalizeCalculate",
        numeric: function (node) {
          if (isNeg(options, node)) {
            // FIXME what's this doing?
            node = numberNode(options, node.args[0]);  // NormalizeCalculate negatives
          }
          return node;
        },
        additive: function (node) {
          if (node.op === Parser.SUB) {
            assert(node.args.length === 2, "2000: Internal error.");
            node = addNode([node.args[0], negate(node.args[1])], true /*flatten*/);
          } else if (node.op === Parser.PM) {
            assert(node.args.length === 2, "2000: Operator \pm can only be used on binary nodes");
            node = addNode([
              node.args[0],
              unaryNode(Parser.PM, [node.args[1]])
            ]);
          }
          const args = [];
          if (node.op === Parser.MATRIX) {
            // Don't flatten matrix nodes.
            return node;
          }
          node = flattenNestedNodes(node);
          return sort(node);
        },
        multiplicative: function(node) {
          assert(node && node.op !== Parser.DIV, "2000: Divsion should be eliminated during parsing");
          if (node.op === Parser.FRAC) {
            node = normalizeMul(node);
          }
          let args = [];
          // Flatten nested multiplication.
          // FIXME can't use flattenNestedNode because of slight differences
          let hasPM;
          node.args.forEach(function (n) {
            n = normalizeCalculate(options, n);
            if (ast.intern(n) === ast.intern(nodeOne)) {
              // If number node one, then erase it. Can't use mathValue here,
              // because it simplifies constant expressions.
              return;
            }
            if (args.length > 0) {
              if (isMinusOne(args[args.length - 1])) {
                if (isMinusOne(n)) {
                  // Double negative, so erase both.
                  args.pop();
                  return;
                }
                if (isPositiveInfinity(n)) {
                  // Collapse.
                  args.pop();
                  args.push(nodeNegativeInfinity);
                  return;
                }
                if (isNegativeInfinity(n)) {
                  // Collapse.
                  args.pop();
                  args.push(nodePositiveInfinity);
                  return;
                }
              }
            }
            if (n.op === Parser.MUL) {
              // Flatten
              args = args.concat(n.args);
            } else if (n.op === Parser.PM) {
              hasPM = true;
              args.push(n.args[0]);
            } else {
              args.push(n);
            }
          });
          if (args.length === 0) {
            node = nodeOne;
          } else if (args.length === 1) {
            node = args[0];
          } else {
            node = sort(binaryNode(node.op, args));
          }
          if (hasPM) {
            node = unaryNode(Parser.PM, [node]);
          }
          return node;
        },
        unary: function(node) {
          var args = [];
          node.args.forEach(function (n) {
            args = args.concat(normalizeCalculate(options, n));
          });
          node = newNode(node.op, args);
          switch (node.op) {
          case Parser.ADD:
            return args[0];
          case Parser.SUB:
            node = negate(args[0]);
            break;
          case Parser.PERCENT:
            if (args[0].op === Parser.NUM) {
              var mv = mathValue(options, args[0]);
              node = numberNode(options, divide(mv, 100));
            } else {
              node = multiplyNode([
                binaryNode(Parser.POW, [
                  numberNode(options, "100"),
                  nodeMinusOne
                ]), args[0]]);
            }
            break;
          case Parser.PM:
            if (isNeg(options, mathValue(options, args[0], true))) {
              var args = node.args.slice(0);
              node = newNode(node.op, [negate(args.shift())].concat(args));
            }
            break;
          case Parser.FACT:
            var mv = mathValue(options, args[0]);
            if (mv) {
              node = numberNode(options, factorial(mv));
            } else {
              node = unaryNode(node.op, [args[0]]);
            }
            break;
          default:
            // Do nothing.
            break;
          }
          return node;
        },
        variable: function(node) {
          if (node.args[0] === "i" && !option(options, "dontSimplifyImaginary")) {
            node = nodeImaginary;
          }
          if (node.args[0] === "\\infty") {
            node = nodePositiveInfinity;
          }
          return node;
        },
        exponential: function(node) {
          const args = [];
          switch(node.op) {
          case Parser.LOG:
            // log_e has special meaning so don't normalizeCalculate 'e' in that case.
            if (ast.intern(node.args[0]) === ast.intern(nodeE)) {
              args.push(nodeE);
            } else {
              args.push(normalizeCalculate(options, node.args[0]));
            }
            break;
          case Parser.POW:
            if (isMinusOne(node.args[0]) && toNumber(mathValue(options, node.args[1], true)) === 0.5) {
              return nodeImaginary;
            } else if (isOne(node.args[0])) {
              return nodeOne;
            } else if (isMinusOne(node.args[0]) && isMinusOne(node.args[1])) {
              return nodeMinusOne;
            } else if (node.args[0].op === Parser.VAR &&
                       node.args[1].op === Parser.VAR &&
                       node.args[1].indexOf("'") === 0) {
              // Merge previous var with current '.
              return variableNode(node.args[0].args[0] + node.args[1].args[0]);
            }
            // Fall through.
          default:
            args.push(normalizeCalculate(options, node.args[0]));
            break;
          }
          args.push(normalizeCalculate(options, node.args[1]));
          return binaryNode(node.op, args);
        },
        comma: function(node) {
          let vals = [];
          node.args.forEach(function (n) {
            vals = vals.concat(normalizeCalculate(options, n));
          });
          var node = newNode(node.op, vals);
          return sort(node);
        },
        equals: function(node) {
          assert(node.args.length === 2, message(2006));
          assert(isZero(node.args[1]), "2000: Internal error.");
          const coeffs = isPolynomial(node);
          assert(coeffs.length === 2, "2000: Internal error.");
          const c0 = coeffs[0] === undefined ? "1" : coeffs[0];
          const c1 = coeffs[1] === undefined ? "1" : coeffs[1];
          return fractionNode(negate(numberNode(options, c0)), numberNode(options, c1));
        }
      }), root.location);
      // normalizeCalculateLevel--;
      // If the node has changed, simplify again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        node = normalizeCalculate(options, node);
      }
      node.normalizeCalculateNid = nid;
      return node;
    }

    const sortedNodes = [];
    function sort(root) {
      try {
        Assert.checkTimeout();
      } catch (e) {
        return root;
      }
      assert(root && root.args, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.sortNid === nid) {
        return root;
      }
      let cachedNode;
      if ((cachedNode = sortedNodes[nid]) !== undefined) {
        return cachedNode;
      }
      const rootNid = nid;
      let node = visit(options, root, {
        name: "sort",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          // Sort by descending degree
          const args = [];
          node.args.forEach(function (n, i) {
            if (i > 0 && node.op === Parser.SUB) {
              n = negate(n);
            }
            args.push(sort(n));
          });
          const op = node.op === Parser.SUB ? Parser.ADD : node.op;
          const isMixedNumber = node.isMixedNumber;
          const isRepeatingFlag = node.isRepeating;
          node = binaryNode(op, args, true);
          node.isMixedNumber = isMixedNumber;
          node.isRepeating = isRepeatingFlag;
          if (node.op === Parser.PM ||
              node.op === Parser.BACKSLASH) {
            // Don't sort these kinds of nodes.
            return node;
          }
          let d0, d1;
          let n0, n1;
          let v0, v1;
          let c0, c1;
          let s0, s1;
          let cp0, cp1;
          for (let i = 0; i < node.args.length - 1; i++) {
            n0 = node.args[i];
            n1 = node.args[i + 1];
            d0 = degree(node.args[i]);
            d1 = degree(node.args[i + 1]);
            if (d0 < d1) {
              // Swap adjacent elements
              node.args[i] = n1;
              node.args[i + 1] = n0;
            } else if (d0 === d1) {
              v0 = variables(n0);
              v1 = variables(n1);
              if (v0.length !== v1.length) {
                if (v0.length < v1.length) {
                  // Swap
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                }
              } else if(v0.length > 0) {
                if ((s0 = v0.join(",")) !== (s1 = v1.join(","))) {
                  if (s0 < s1) {
                    // Swap adjacent elements
                    node.args[i] = n1;
                    node.args[i + 1] = n0;
                  }
                } else if ((c0 = isPolynomial(n0)) && (c1 = isPolynomial(n1)) &&
                           (s0 = c0.join(",")) !== (s1 = c1.join(","))) {
                  if (s0 < s1) {
                    node.args[i] = n1;
                    node.args[i + 1] = n0;
                  }
                } else if (isLessThan(constantPart(n0), constantPart(n1))) {
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                }
              } else if (d0 === 0) {
                if (exponent(n0) !== exponent(n1)) {
                  if (exponent(n0) < exponent(n1)) {
                    node.args[i] = n1;
                    node.args[i + 1] = n0;
                  }
                } else if (isLessThan((cp0 = mathValue(options, constantPart(n0)), true), (cp1 = mathValue(options, constantPart(n1)), true))) {
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                } else if (!cp0 && cp1) {
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                }
              }
            }
          }
          return node;
        },
        multiplicative: function (node) {
          // Sort by ascending degree.
          const args = [];
          let hasMinusOne = false;
          node.args.forEach(n => {
            if (isMinusOne(n)) {
              hasMinusOne = !hasMinusOne;
            } else {
              args.push(sort(n));
            }
          });
          if (args.length === 0) {
            return nodeOne;
          }
          if (node.op === Parser.FRAC ||
              node.op === Parser.COEFF) {
            // Don't sort numerators and denominator or coefficients.
            return hasMinusOne && negate(binaryNode(node.op, args, true)) || binaryNode(node.op, args, true);
          }
          let d0, d1;
          let n0, n1;
          let v0, v1;
          let c0, c1;
          for (let i = 0; i < args.length - 1; i++) {
            var s0, s1;
            n0 = args[i];
            n1 = args[i + 1];
            d0 = degree(n0);
            d1 = degree(n1);
            if (d0 !== d1) {
              if (d0 > d1) {
                // Swap adjacent elements
                args[i] = n1;
                args[i + 1] = n0;
              }
            } else if (Math.abs(d0) === Math.abs(d1)) {
              v0 = n0.op === Parser.POW && variables(n0.args[0]) || variables(n0);
              v1 = n1.op === Parser.POW && variables(n1.args[0]) || variables(n1);
              const e0 = exponent(n0);
              const e1 = exponent(n1);
              if (e0 !== e1 && !isNaN(e0) && !isNaN(e1)) {
                if (e0 < e1) {
                  args[i] = n1;
                  args[i + 1] = n0;
                }
              } else if (v0.length !== v1.length) {
                if (v0.length < v1.length) {
                  args[i] = n1;
                  args[i + 1] = n0;
                }
              } else if (n0.op === Parser.POW &&
                         n1.op === Parser.POW &&
                         v0.length === 0) {
                // We have exponential exprs with the same exponent and no
                // variables so compare constant operands.
                if (isLessThan(mathValue(options, n0.args[0], true), mathValue(options, n1.args[0], true))) {
                  args[i] = n1;
                  args[i + 1] = n0;
                }
              } else if (n0.op !== n1.op) {
                if (hashCode(n0.op) < hashCode(n1.op)) {
                  args[i] = n1;
                  args[i + 1] = n0;
                }
              } else if(v0.length > 0) {
                if ((s0 = v0.join(",")) !== (s1 = v1.join(","))) {
                  if (s0 < s1) {
                    // Swap adjacent elements
                    args[i] = n1;
                    args[i + 1] = n0;
                  }
                } else if ((c0 = isPolynomial(n0)) && (c1 = isPolynomial(n1)) &&
                           (s0 = c0.join(",")) !== (s1 = c1.join(","))) {
                  if (s0 < s1) {
                    args[i] = n1;
                    args[i + 1] = n0;
                  }
                } else if (isLessThan(constantPart(n0), constantPart(n1))) {
                  args[i] = n1;
                  args[i + 1] = n0;
                }
              } else if (isLessThan(leadingCoeff(n0), leadingCoeff(n1))) {
                // Keep last
                args[i] = n1;
                args[i + 1] = n0;
              }
            }
          }
          if (hasMinusOne) {
            if (args.length === 0) {
              args.unshift(nodeMinusOne);
            } else {
              args.unshift(negate(args.shift()));
            }
          }
          node = binaryNode(node.op, args, true);
          assert(!(node.op === Parser.MUL && isMinusOne(node.args[node.args.length - 1])), "node=" + JSON.stringify(node, null, 2));
          return node;
        },
        unary: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(sort(n));
          });
          return newNode(node.op, args);
        },
        exponential: function (node) {
          const args = [];
          node.args.forEach(function (n, i) {
            args.push(sort(n));
          });
          node = binaryNode(node.op, args);
          return node;
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(sort(n));
          });
          switch (node.op) {
          case Parser.COMMA:
            // If its a bare comma expression then sort.
            args.sort(function (a, b) {
              a = JSON.stringify(a);
              b = JSON.stringify(b);
              if (a < b) {
                return -1;
              }
              if (a > b) {
                return 1;
              }
              return 0;
            });
            break;
          default:
            break;
          }
          return newNode(node.op, args);
        },
        equals: function(node) {
          node.args.forEach(function (n, i) {
            node.args[i] = sort(n);
          });
          if (node.op === Parser.COLON ||
              node.op === Parser.RIGHTARROW ||
              node.op === Parser.GT ||
              node.op === Parser.GE ||
              node.op === Parser.LT ||
              node.op === Parser.LE ||
              node.op === Parser.NGTR ||
              node.op === Parser.NLESS ||
              node.args.length === 2 && isZero(node.args[1])) {
            // If already normalized or ratio or chem, then don't sort toplevel terms.
            return node;
          }
          // Sort by descending degree
          let d0, d1;
          let n0, n1;
          let v0, v1;
          for (let i = 0; i < node.args.length - 1; i++) {
            n0 = node.args[i];
            n1 = node.args[i + 1];
            if ((d0 = degree(node.args[i], true)) < (d1 = degree(node.args[i + 1], true))) {
              // Swap adjacent elements
              node.args[i] = n1;
              node.args[i + 1] = n0;
            } else if (d0 === d1) {
              v0 = variables(n0);
              v1 = variables(n1);
              if (v0.length !== v1.length) {
                if(v0.length < v1.length) {
                  // Swap adjacent elements
                  var t = node.args[i];
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                }
              } else if (v0.length > 0) {
                if (v0[0] < v1[0]) {
                  // Swap adjacent elements
                  var t = node.args[i];
                  node.args[i] = n1;
                  node.args[i + 1] = n0;
                }
              } else if (!isZero(n1) && isLessThan(mathValue(options, n0), mathValue(options, n1))) {
                // Unless the RHS is zero, swap adjacent elements
                var t = node.args[i];
                node.args[i] = n1;
                node.args[i + 1] = n0;
              }
            }
          }
          return node;
        }
      });
      // If the node has changed, sort again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        node = sort(node);
      }
      node.sortNid = nid;
      sortedNodes[rootNid] = node;
      return node;
    }

    const sortedLiteralNodes = [];
    function sortLiteral(root) {
      Assert.checkTimeout();
      assert(root && root.args, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.sortLiteralNid === nid) {
        return root;
      }
      let cachedNode;
      if ((cachedNode = sortedLiteralNodes[nid]) !== undefined) {
        return cachedNode;
      }
      const rootNid = nid;
      let node = visit(options, root, {
        name: "sortLiteral",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(sortLiteral(n));
          });
          node = binaryNode(node.op, args, true);
          if (node.op === Parser.PM ||
              node.op === Parser.BACKSLASH) {
            // Don't sort these kinds of nodes.
            return node;
          }
          let id0, id1;
          let n0, n1;
          for (let i = 0; i < node.args.length - 1; i++) {
            n0 = node.args[i];
            n1 = node.args[i + 1];
            id0 = ast.intern(n0);
            id1 = ast.intern(n1);
            if (id0 < id1) {
              // Swap adjacent elements
              node.args[i] = n1;
              node.args[i + 1] = n0;
            }
          }
          return node;
        },
        multiplicative: function (node) {
          let args = [];
          let negs = 0;
          node.args.forEach(function (n) {
            if (n.op === Parser.SUB && n.args[0].op !== Parser.SUB &&
                (node.op === Parser.MUL ||
                 node.op === Parser.COEFF ||
                 node.op === Parser.CDOT ||
                 node.op === Parser.TIMES)) {
              // Pull negative signs out of multiplication args
              negs += 1;
              args.push(sortLiteral(n.args[0]));
            } else {
              args.push(sortLiteral(n));
            }
          });
          node = binaryNode(node.op, args);
          if (node.op === Parser.FRAC ||
              node.op === Parser.DIV) {
            // Don't sort fraction or division nodes
            return node;
          }
          let id0, id1;
          let n0, n1;
          for (let i = 0; i < node.args.length - 1; i++) {
            n0 = node.args[i];
            n1 = node.args[i + 1];
            id0 = ast.intern(n0);
            id1 = ast.intern(n1);
            if (id0 < id1) {
              // Swap adjacent elements
              node.args[i] = n1;
              node.args[i + 1] = n0;
            }
          }
          args = [];
          for ( ; negs > 0; negs--) {
            // Put minus operators back to the leading args.
            args.push(unaryNode(Parser.SUB, [node.args.shift()]));
          }
          args = args.concat(node.args);  // Concatentate the remaining args as they are.
          node = binaryNode(node.op, args);
          return node;
        },
        unary: function(node) {
          const args = [];
          if (node.args[0].op === Parser.COMMA) {
            node.args[0].args.forEach(function (n) {
              args.push(sortLiteral(n));
            });
            node = unaryNode(node.op, [newNode(Parser.COMMA, args)]);
          } else {
            node.args.forEach(function (n) {
              args.push(sortLiteral(n));
            });
            node = unaryNode(node.op, args);
          }
          if (node.op === Parser.CAP || node.op === Parser.CUP) {
            let id0, id1;
            let n0, n1;
            for (let i = 0; i < node.args.length - 1; i++) {
              n0 = node.args[i];
              n1 = node.args[i + 1];
              id0 = ast.intern(n0);
              id1 = ast.intern(n1);
              if (id0 < id1) {
                // Swap adjacent elements
                node.args[i] = n1;
                node.args[i + 1] = n0;
              }
            }
          }
          return node;
        },
        exponential: function (node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(sortLiteral(n));
          });
          node = binaryNode(node.op, args);
          return node;
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          const args = [];
          if (node.op !== Parser.SET && node.args.length && node.args[0].op === Parser.COMMA) {
            node.args[0].args.forEach(function (n) {
              args.push(sortLiteral(n));
            });
            node = newNode(node.op, [newNode(Parser.COMMA, args)]);
          } else {
            node.args.forEach(function (n) {
              args.push(sortLiteral(n));
            });
          }
          switch (node.op) {
          case Parser.COMMA:
            // If its a bare comma expression then sort.
            args.sort(function (a, b) {
              a = JSON.stringify(a);
              b = JSON.stringify(b);
              if (a < b) {
                return -1;
              }
              if (a > b) {
                return 1;
              }
              return 0;
            });
            break;
          default:
            break;
          }
          return newNode(node.op, args);
        },
        equals: function(node) {
          node.args.forEach(function (n, i) {
            node.args[i] = sortLiteral(n);
          });
          if (node.op === Parser.COLON ||
              node.op === Parser.RIGHTARROW ||
              node.op === Parser.GT ||
              node.op === Parser.GE ||
              node.op === Parser.LT ||
              node.op === Parser.LE ||
              node.op === Parser.NGTR ||
              node.op === Parser.NLESS) {
            // If already normalized or ratio or chem, then don't sort toplevel terms.
            return node;
          }
          let id0, id1;
          let n0, n1;
          for (let i = 0; i < node.args.length - 1; i++) {
            n0 = node.args[i];
            n1 = node.args[i + 1];
            id0 = ast.intern(n0);
            id1 = ast.intern(n1);
            if (id0 < id1) {
              // Swap adjacent elements
              node.args[i] = n1;
              node.args[i + 1] = n0;
            }
          }
          return node;
        }
      });
      // If the node has changed, sort again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        node = sortLiteral(node);
      }
      node.sortLiteralNid = nid;
      sortedLiteralNodes[rootNid] = node;
      return node;
    }

    function isGrouping(options, node, level) {
      return (
        ((node.op === Parser.PAREN || node.op === Parser.BRACE || node.op === Parser.BRACKET) ||
         node.op === Parser.SET && option(options, "inSet")) &&
        node.args.length === 1 &&
        node.args[0].op !== Parser.COMMA &&
        (level > 1 || node.op === Parser.PAREN || node.op === Parser.BRACKET)
      );
    }

    let normalizeLiteralLevel = 0;
    function normalizeLiteral(options, root) {
      assert(root && root.args, "2000: Internal error.");
      const nid = ast.intern(root);
      if (root.normalizeLiteralNid === nid) {
        return root;
      }
      normalizeLiteralLevel++;
      const node = visit(options, root, {
        name: "normalizeLiteral",
        numeric: function (node) {
          if (!node.isRepeating) {
            let arg = new Decimal(node.args[0]);   // Normalize representation.
            arg = String(arg);
            node = newNode(Parser.NUM, [arg]);
          }
          return node;
        },
        additive: function (node) {
          const args = [];
          const compareGrouping = node.lbrk && Parser.option(options, "compareGrouping");
          node.args.forEach(function (n) {
            args.push(normalizeLiteral(options, n));
          });
          if (Parser.option(options, "ignoreOrder") && node.op === Parser.SUB) {
            assert(args.length === 2, "2000: Internal error.");
            node = addNode([args[0], normalizeLiteral(options, multiplyNode([nodeMinusOne, args[1]], true))]);
          } else if (node.op === Parser.PM) {
            assert(args.length === 2, "2000: Internal error.");
            node = addNode([args[0], newNode(Parser.PM, [args[1]])]);
          } else {
            node = binaryNode(node.op, args, true);  // Flatten in case there was redundant grouping.
          }
          if (compareGrouping) {
            // Reconstitute brackets
            node = newNode(Parser.PAREN, [node]);
          }
          return node;
        },
        multiplicative: function (node) {
          const compareGrouping = node.lbrk && Parser.option(options, "compareGrouping");
          const flatten = !compareGrouping;
          if ((node.op === Parser.CDOT || node.op === Parser.TIMES) &&
              (!isAggregate(node.args[0]) || !isAggregate(node.args[1]))) {
            // Convert explicit multiplication to MUL.
            node.op = Parser.MUL;
          }
          const args = [];
          const denoms = [];
          node.args.forEach(function (n) {
            n = normalizeLiteral(options, n);
            if (node.op === Parser.MUL) {
              if (n.op === Parser.FRAC) {
                args.push(n.args[0]);
                denoms.push(n.args[1]);
              } else if (!isOne(n)) {
                // Ignore factors of 1
                args.push(n);
              }
            } else {
              args.push(n);
            }
          });
          if (args.length === 0) {
            args.push(nodeOne);
          }
          if (denoms.length) {
            // Combine factors into a single fraction
            node = newNode(Parser.FRAC, [
              normalizeLiteral(options, multiplyNode(args)),
              normalizeLiteral(options, multiplyNode(denoms))
            ]);
          } else {
            node = binaryNode(node.op, args, flatten);
          }
          if (compareGrouping) {
            // Reconstitute brackets
            node = newNode(Parser.PAREN, [node]);
          }
          return node;
        },
        unary: function(node) {
          const compareGrouping = Parser.option(options, "compareGrouping");
          if (isGrouping(options, node, normalizeLiteralLevel)) {
            return normalizeLiteral(options, node.args[0]);
          }
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeLiteral(options, n));
          });
          node = newNode(node.op, args);
          switch (node.op) {
          case Parser.SUB:
            return normalizeLiteral(options, multiplyNode([nodeMinusOne, node.args[0]], true));
          case Parser.ADD:
            // Strip redundant +
            return node.args[0];
          }
          return node;
        },
        exponential: function (node) {
          if (node.args.length === 2 &&
              node.args[0].op === Parser.VAR &&
              node.args[1].op === Parser.VAR &&
              node.args[1].args[0].indexOf("'") === 0) {
            // Merge primes.
            node = variableNode(node.args[0].args[0] + node.args[1].args[0]);
          } else {
            const args = [];
            node.args.forEach(function (n) {
              args.push(normalizeLiteral(options, n));
            });
            node = newNode(node.op, args);
          }
          return node;
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeLiteral(options, n));
          });
          node = newNode(node.op, args);
          return node;
        },
        equals: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeLiteral(options, n));
          });
          if (option(options, "ignoreOrder") &&
              (node.op === Parser.GT ||
               node.op === Parser.GE ||
               node.op === Parser.NGTR)) {
            // Swap adjacent elements and reverse the operator.
            assert(args.length === 2, "2000: Comparisons have only two operands.");
            const t = args[0];
            args[0] = args[1];
            args[1] = t;
            node.op = node.op === Parser.GT ? Parser.LT : node.op === Parser.GE ? Parser.LE : Parser.NLESS;
            node = newNode(node.op, args);
          } else {
            node = newNode(node.op, args);
          }
          return node;
        }
      });
      normalizeLiteralLevel--;
      node.normalizeLiteralNid = ast.intern(node);
      return node;
    }

    function normalizeExpanded(root) {
      assert(root && root.args, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.normalizeExpandedNid === nid) {
        return root;
      }
      let node = visit(options, root, {
        name: "normalizeExpanded",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return groupLikes(node);
        },
        multiplicative: function (node) {
          const equivLiteralDivAndFrac = false;
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return flattenNestedNodes(groupLikes(node));
        },
        unary: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return node;
        },
        exponential: function (node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return node;
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return node;
        },
        equals: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(normalizeExpanded(n));
          });
          node = newNode(node.op, args);
          return node;
        }
      });
      // If the node has changed, normalizeExpanded again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        node = normalizeExpanded(node);
      }
      node.normalizeExpandedNid = nid;
      return node;
    }

    function isRepeating(node) {
      assert(node && (node.op === Parser.NUM || isAdditive(node)), "2000: Internal error.");
      return node.isRepeating;
    }

    function findRepeatingPattern(s, p, x) {
      if (!p) {
        assert((typeof s === "string") && s.length > 0, "2000: Internal error.");
        p = s.charAt(0);
        s = s.substring(1);
        x = "";
      }
      if (s.length === 0) {
        return p;
      }
      if (s.indexOf(p) === 0) {
        // p is a prefix of s, so continue checking
        x += p;
        s = s.substring(p.length);
        return findRepeatingPattern(s, p, x);
      } else {
        // p is not a prefix of s, so extend p by skipped digits
        p += x + s.charAt(0);
        x = "";
        s = s.substring(1);
        return findRepeatingPattern(s, p, x);
      }
    }

    function repeatingDecimalToFraction(options, node) {
      // (add (decimalPart) (overline (repeatingPart)))
      assert(isRepeating(node), "2000: Internal error.");
      assert(node && node.op === Parser.ADD && node.args[0].op === Parser.NUM, "2000: Internal error.");
      const decimalPart = node.args[0].args[0];
      let repeatingPart = node.args[1].args[0];
      const decimalPos = decimalPart.indexOf(".");
      repeatingPart = findRepeatingPattern(repeatingPart);
      const decimalPlaces = decimalPart.length - decimalPos - 1; // Don't count '.'.
      const repeatingPlaces = repeatingPart.length;
      // 0.\overline{3} --> 3/9
      // 0.\overline{12} --> 12/99 --> 4/33
      // 0.0\overline{6} --> 1/15
      // 0.\overline{06} --> 2/33
      const numer = numberNode(options, repeatingPart);
      const denom = addNode([
        binaryNode(Parser.POW, [numberNode(options, "10"), numberNode(options, repeatingPlaces)]),
        nodeMinusOne
      ]);
      const scaleNode = newNode(Parser.POW, [numberNode(options, "10"), negate(numberNode(options, decimalPlaces))]);
      node = multiplyNode([scaleNode, fractionNode(numer, denom)]);
      node = addNode([numberNode(options, decimalPart), node]);
      return node;
    }

    function isLessThan(n1, n2) {
      if (n1 && n1.op !== undefined) {
        n1 = mathValue(options, n1, true);
      }
      if (n2 && n2.op !== undefined) {
        n2 = mathValue(options, n2, true);
      }
      if (n1 === null || !(n1 instanceof Decimal) ||
          n2 === null || !(n1 instanceof Decimal)) {
        return false;
      }
      return n1.cmp(n2) < 0;
    }

    function isPos(bd) {
      return bd.cmp(bigZero) > 0;
    }
    function pow(b, e) {
      let val;
      if (isNaN(b) || isNaN(e) || b === null || e === null) {
        return null;
      }
      const bmv = toDecimal(b);
      const emv = toDecimal(e);
      if (bmv && emv) {
        val = bmv.pow(emv);
      } else {
        assert(false, "Should not get here");
        val = toDecimal(Math.pow(toNumber(b), toNumber(e)));
      }
      return val;
    }
    function divide(n, d) {
      if (n === null || d === null) {
        return null;
      }
      if (!(n instanceof Decimal)) {
        n = toDecimal(n);
      }
      if (!(d instanceof Decimal)) {
        d = toDecimal(d);
      }
      if (isZero(d)) {
        return null;
      }
      return n.dividedBy(d);
    }

    function sqrt(n) {
      if (n instanceof Decimal) {  // Assume d is too.
        if (n === null) {
          return null;
        }
        n = toNumber(n);
      }
      if (isNaN(n)) {
        return null;
      }
      return toDecimal(Math.sqrt(n)).toDecimalPlaces(option(options, "decimalPlaces"), Decimal.ROUND_HALF_UP);
    }

    function trig(n, op) {
      if (n === null) {
        return null;
      } else if (n instanceof Decimal) {  // Assume d is too.
        n = toNumber(n);
      } else {
        if (isNaN(n)) {
          return null;
        }
      }
      let f;
      switch (op) {
      case Parser.SIN:
        f = Math.sin;
        break;
      case Parser.COS:
        f = Math.cos;
        break;
      case Parser.TAN:
        f = Math.tan;
        break;
      case Parser.ARCSIN:
        f = Math.asin;
        break;
      case Parser.ARCCOS:
        f = Math.acos;
        break;
      case Parser.ARCTAN:
        f = Math.atan;
        break;
      case Parser.SINH:
        f = Math.sinh;
        break;
      case Parser.COSH:
        f = Math.cosh;
        break;
      case Parser.TANH:
        f = Math.tanh;
        break;
      case Parser.ARCSINH:
        f = Math.asinh;
        break;
      case Parser.ARCCOSH:
        f = Math.acosh;
        break;
      case Parser.ARCTANH:
        f = Math.atanh;
        break;
      default:
        assert(false, "2000: Internal error.");
        break;
      }
      return toDecimal(f(n));
    }

    function normalizeLogIdent(base, expo) {
      const args = [];
      let node;
      if (isMultiplicative(expo)) {
        // If log and multiplicative, then add log of each term.
        const aa = [];
        expo.args.forEach(function (e) {
          if (e.op === Parser.POW) {
            aa.push(multiplyNode([
              e.args[1],
              newNode(Parser.LOG, [base, e.args[0]])
            ]));
          } else {
            aa.push(newNode(Parser.LOG, [base, e]));
          }
        });
        args.push(addNode(aa));
        node = binaryNode(Parser.LOG, args);
      } else if (expo.op === Parser.POW) {
        // log x^y -> y log x
        args.push(multiplyNode([
          expo.args[1],
          newNode(Parser.LOG, [base, expo.args[0]])
        ]));
        // x^2, x^y
        assert(args.length > 0, "2000: Internal error");
        if (args.length > 1) {
          node = multiplyNode(args);
        } else if (args.length === 1) {
          node = args[0];
        }
      } else {
        node = newNode(Parser.LOG, [base, expo]);
      }
      return node;
    }
    function normalizeTrigIdent(node) {
      const op = node.op;
      const args = node.args;
      const neg = sign(args[0]) < 0;
      const tt = terms(args[0]);
      let mv = bigZero;
      const cp = [], vp = [];
      tt.forEach(function (t, i) {
        let mv0;
        if (variablePart(t) === null && (mv0 = mathValue(options, t, true, true)) !== null) {
          mv = mv.plus(mv0);  // normalizeUnits=true
          cp.push(t);
        } else {
          vp.push(t);
        }
      });
      // mv is the math value of the angle in radians.
      // cp is the array of constant terms.
      // vp is the array of variable terms.
      // pi/2, pi, 3pi.
      const cycles = Math.floor(toNumber(mv) / (2 * Math.PI));
      // shift is the angle minus the number of cycles times 2pi.
      // phase is shift modulo PI. Many identities depend on the phase.
      let shiftNode;
      if (cycles) {
        shiftNode = addNode(cp.concat(
          negate(multiplyNode([numberNode(options, cycles), nodeTwo, nodePI]))
        ));
      } else {
        shiftNode = addNode(cp);
      }
      const phase = toNumber(mv) % (2 * Math.PI) / Math.PI;
      var node;
      var arg;
      if (vp.length > 0) {
        if (phase) {
          arg = addNode(vp.concat(shiftNode));
        } else {
          arg = addNode(vp);
        }
      } else {
        // Make sure there is something in the vp array.
        vp.push(nodeZero);
        arg = args[0];
      }
      switch (op) {
      case Parser.SIN:
        if (neg) {
          // Normalize negative arg.
          arg = negate(arg);
          node = unaryNode(Parser.SIN, [arg]);
          node = neg ? negate(node) : node;
        } else {
          // Phase shift identities.
          switch(phase) {
          case 1:
          case -1:
            arg = addNode(vp);
            node = unaryNode(Parser.SIN, [arg]);
            node = negate(node);
            break;
          case 1 / 2:
            node = unaryNode(Parser.COS, [addNode(vp)]);
            break;
          case -1 / 2:
            node = negate(unaryNode(Parser.COS, [addNode(vp)]));
            break;
          case 0:
            if (vp.length === 1) {
              node = unaryNode(Parser.SIN, [arg]);
            } else {
              var arg1 = vp[0];
              var arg2 = addNode(vp.slice(1).concat(cp));
              node = addNode([
                multiplyNode([
                  unaryNode(Parser.SIN, [arg1]),
                  unaryNode(Parser.COS, [arg2]),
                ]),
                multiplyNode([
                  unaryNode(Parser.COS, [arg1]),
                  unaryNode(Parser.SIN, [arg2]),
                ])
              ]);
            }
            break;
          default:
            if (!isZero(vp[0])) {
              // sin(x) => cos(pi/2-x)
              node = unaryNode(Parser.COS, [
                addNode([
                  fractionNode(nodePI, nodeTwo),
                  negate(addNode(args)),
                ])
              ]);
            } else {
              node = unaryNode(Parser.SIN, args);
            }
            break;
          }
        }
        break;
      case Parser.COS:
        if (neg) {
          // Normalize negative arg.
          arg = negate(arg);
          node = unaryNode(Parser.COS, [arg]);
        } else {
          switch(phase) {
          case 1:
          case -1:
            arg = addNode(vp);
            node = unaryNode(Parser.COS, [arg]);
            node = negate(node);
            break;
          case 1 / 2:
            arg = addNode(vp);
            node = negate(unaryNode(Parser.SIN, [arg]));
            break;
          case -1 / 2:
            arg = addNode(vp);
            node = unaryNode(Parser.SIN, [arg]);
            break;
          case 0:
            if (vp.length === 1) {
              node = unaryNode(Parser.COS, [arg]);
            } else {
              var arg1 = vp[0];
              var arg2 = addNode(vp.slice(1).concat(cp));
              node = addNode([
                multiplyNode([
                  unaryNode(Parser.COS, [arg1]),
                  unaryNode(Parser.COS, [arg2]),
                ]),
                negate(multiplyNode([
                  unaryNode(Parser.SIN, [arg1]),
                  unaryNode(Parser.SIN, [arg2]),
                ]))
              ]);
            }
            break;
          default:
            node = unaryNode(Parser.COS, args);
            break;
          }
        }
        break;
      case Parser.SINH:
      case Parser.COSH:
        break;
      case Parser.ARCSINH:
        var arg = args[0];
        var doNegate;
        if (isNeg(options, arg)) {
          arg = negate(arg);
          doNegate = true;
        }
        node = newNode(Parser.LOG, [
          nodeE,
          addNode([
            arg,
            sqrtNode(addNode([
              binaryNode(Parser.POW, [arg, nodeTwo]),
              nodeOne
            ]))
          ])
        ]);
        if (doNegate) {
          node = negate(node);
        }
        break;
      case Parser.ARCCOSH:
        var arg = args[0];
        var doNegate;
        if (isNeg(options, arg)) {
          arg = negate(arg);
        }
        node = newNode(Parser.LOG, [
          nodeE,
          addNode([
            arg,
            sqrtNode(addNode([
              binaryNode(Parser.POW, [arg, nodeTwo]),
              nodeMinusOne
            ]))
          ])
        ]);
        break;
      default:
        assert(false, "2000: Internal error.");
        break;
      }
      return node;
    }

    function normalizeAbs(node) {
      assert(node && node.op === Parser.ABS, "2000: Internal error");
      switch (node.args[0].op) {
      case Parser.ADD:
        if (node.args[0].args.every(function (n) {
          return !isNeg(options, n);
        })) {
          // Every term is positive so we can rewrite as abs terms.
          const args = [];
          node.args[0].args.forEach(function (n) {
            args.push(unaryNode(Parser.ABS, [n]));
          });
          node = addNode(args);
        }
        break;
      }
      return node;
    }

    function integralNode(start, stop, expr) {
      if (start) {
        return newNode(Parser.INTEGRAL, [start, stop, expr]);
      } else {
        return newNode(Parser.INTEGRAL, [expr]);
      }
    }
    function normalizeIntegralAddition(node) {
      const terms = {};
      const args = [];
      node.args.forEach(function (n) {
        if (n.op === Parser.INTEGRAL && n.args.length === 3) {
          const nid = ast.intern(n.args[2]);
          if (!terms[nid]) {
            terms[nid] = [];
          }
          terms[nid].push(n);
        } else {
          // Not a candidate for folding, so just keep it as is.
          args.push(n);
        }
      });
      const kk = Object.keys(terms);
      kk.forEach(function (k) {
        // \int_a^b e + \int_b^c e
        const tt = terms[k];
        const expr = tt[0].args[2];
        const starts = [], stops = [];
        tt.forEach(function (t) {
          const start = t.args[0];
          const stop = t.args[1];
          starts.push(ast.intern(start));
          stops.push(ast.intern(stop));
        });
        starts.forEach(function (start, stopIndex) {
          const startIndex = stops.indexOf(start);
          if (startIndex >= 0) {
            // We have a start and stop that align, so fold them. The new start
            // is the start at the index of the matched stop.
            args.push(integralNode(ast.node(starts[startIndex]), ast.node(stops[stopIndex]), expr));
            delete starts[startIndex];
            delete stops[startIndex];
            delete starts[stopIndex];
            delete stops[stopIndex];
          }
        });
        starts.forEach(function (start, i) {
          // Now add unfolded definite integral terms.
          const stop = stops[i];
          args.push(integralNode(ast.node(start), ast.node(stop), expr));
        });
      });
      return binaryNode(node.op, args);
    }
    function normalizeIntegral(node) {
      let start, stop, expr;
      if (node.args.length === 3) {
        start = node.args[0];
        stop = node.args[1];
        expr = node.args[2];
      } else {
        expr = node.args[0];
      }
      let cp, vp;
      if (start && ast.intern(start) === ast.intern(stop)) {
        node = nodeZero;
      } else if (isAdditive(expr)) {
        const args = [];
        expr.args.forEach(function (e) {
          args.push(integralNode(start, stop, e));
        });
        node = binaryNode(expr.op, args);
      } else if ((cp = constantPart(expr))) {
        vp = variablePart(expr);
        if (vp) {
          if (start && isNeg(options, cp)) {
            // If definite integral with negative constant, swap limits.
            cp = negate(cp);
            const t = start;
            start = stop;
            stop = t;
          }
          if (isOne(cp)) {
            node = integralNode(start, stop, vp);
          } else {
            node = multiplyNode([cp, integralNode(start, stop, vp)]);
          }
        } else if (start) {
          // \int_a^b 5dx => 5(b-a)
          node = multiplyNode([cp, addNode([stop, negate(start)])]);
        }
      }
      return node;
    }

    function flattenNestedNodes(node, doSimplify) {
      let args = [];
      if (node.op === Parser.NUM || node.op === Parser.VAR) {
        return node;
      }
      node.args.forEach(function (n) {
        if (doSimplify) {
          n = simplify(options, n);
        }
        // Normalize to get the correct shape node.
        n = normalize(options, n);
        if (n.op === node.op) {
          args = args.concat(n.args);
        } else {
          args.push(n);
        }
      });
      const isMixedNumber = node.isMixedNumber;
      node = binaryNode(node.op, args);
      node.isMixedNumber = isMixedNumber;
      return node;
    }

    // Map like factors to the same key.
    function factorGroupingKey(root) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "factorGroupingKey",
        exponential: function (node) {
          return factorGroupingKey(node.args[1]) + Parser.POW +  factorGroupingKey(node.args[0]);
        },
        multiplicative: function (node) {
          let key = "";
          key += variables(node).join("");
          if (!key) {
            key = factorGroupingKey(node.args[0]);
          }
          return key;
        },
        additive: function (node) {
          let key = "";
          node.args.forEach(function (n) {
            key += "+" + factorGroupingKey(n);
          });
          return key;
        },
        unary: function(node) {
          return factorGroupingKey(node.args[0]);
        },
        numeric: function(node) {
          return Parser.NUM;
        },
        variable: function(node) {
          return node.args[0];
        },
        comma: function(node) {
          return Parser.COMMA;
        },
        equals: function(node) {
          return Parser.EQL;
        }
      });
    }

    // Group like factors and terms into nodes that will simplify nicely.
    // We don't use the visitor mechanism because this is not recursive.
    const groupedNodes = [];
    function groupLikes(node) {
      const hash = {};
      let vp, keyid;
      if (node.op !== Parser.MUL && node.op !== Parser.ADD) {
        // We only care about factors and terms.
        return node;
      }
      assert(node.args.length > 1, "2000: Internal error.");
      const nid = ast.intern(node);
      let cachedNode;
      if ((cachedNode = groupedNodes[nid]) !== undefined) {
        return cachedNode;
      }
      const rootNid = nid;
      node = flattenNestedNodes(node);
      node.args.forEach(function (n, i) {
        let key;
        if (node.op === Parser.MUL) {
          // If factors, then likes have same variables.
          key = factorGroupingKey(n);
        } else if (node.op === Parser.ADD) {
          // If terms, likes have the same variable parts.
          key = variablePart(n);
        }
        if (!key) {
          let mv;
          // No variable key, so get a constant based key
          if ((mv = mathValue(options, n, true)) !== null) {
            // Group nodes that have computable math values.
            if (n.op === Parser.POW) {
              mv = abs(mathValue(options, n.args[0], true));
              if (mv !== null) {
                key = "number";
              } else {
                key = "none";
              }
            } else {
              mv = abs(mv);
              if (mv !== null) {
                key = "number";
              } else {
                key = "none";
              }
            }
          } else {
            key = n;
          }
        }
        assert(key, "2000: Internal error.");
        if (typeof key === "string") {
          key = variableNode(key);
        }
        keyid = ast.intern(key);
        const list = hash[keyid] ? hash[keyid] : (hash[keyid] = []);
        list.push(n);
      });
      let args = [];
      const numberArgs = [];
      const isMixedNumber = node.isMixedNumber;
      Object.keys(hash).forEach(function (k) {
        // Group elements that hashed together. Keep a set of singleton numbers
        // to group together later.
        const exprs = hash[k];
        assert(exprs, "2000: Internal error.");
        const cp = [];
        const vp = [];
        // Separate the constant part from the variable part.
        exprs.forEach(function (n) {
          const c = constantPart(n);
          if (c) {
            cp.push(c);
          }
        });
        exprs.forEach(function (n) {
          const c = variablePart(n);
          if (c) {
            vp.push(c);
          }
        });
        if (cp.indexOf(null) >= 0) {
          // We've got some strange equation, so just return it as is.
          return node;
        }
        if (node.op === Parser.ADD) {
          var nd;
          if (cp.length > 0) {
            // Combine all the constants.
            nd = binaryNode(node.op, cp);
            nd.isMixedNumber = node.isMixedNumber;
            var mv = mathValue(options, nd);
            var tempArgs = [];
            if (mv !== null) {
              nd = numberNode(options, mv);
            } else {
              nd = simplify(options, nd, {dontGroup: true});
            }
          } else {
            nd = nodeOne;
          }
          if (vp.length > 0) {
            const v = vp[0];  // Each element is the same.
            if (isZero(nd)) {
              args.push(nodeZero);
            } else if (isOne(nd)) {
              args.push(v);
            } else {
              args.push(simplify(options, multiplyNode([nd, v], true), {dontGroup: true}));
            }
          } else if (nd) {
            if (nd.op === Parser.NUM) {
              // At this point any node that has a math value will be a number node.
              numberArgs.push(nd);
            } else {
              args.push(nd);
            }
          }
        } else if (node.op === Parser.MUL) {
          var nd;
          if (cp.length > 0) {
            // Combine all the constants.
            nd = binaryNode(node.op, cp);
            var mv = mathValue(options, nd);
            var tempArgs = [];
            if (mv !== null) {
              if (isOne(mv)) {
              } else {
                numberArgs.push(numberNode(options, mv.toString()));
              }
              nd = null;  // Factor out coefficient
            } else {
              nd = simplify(options, nd, {dontGroup: true});
            }
          } else {
            nd = null;
          }
          if (vp.length > 0) {
            if (nd === null || isOne(nd)) {
              args.push(simplify(options, multiplyNode(vp), {dontGroup: true}));
            } else if (isZero(nd)) {
              args.push(nodeZero);
            } else {
              args.push(simplify(options, multiplyNode([nd].concat(vp)), {dontGroup: true}));
            }
          } else if (nd) {
            if (isNumeric(nd)) {
              numberArgs.push(nd);
            } else {
              args.push(nd);
            }
          }
          args = sortFactors(args);
        } else {
          args.push(binaryNode(node.op, exprs));
        }
      });
      if (numberArgs.length > 0) {
        const nd = binaryNode(node.op, numberArgs);
        const mv = mathValue(options, nd);
        if (mv === null) {
          args.push(nd);
        } else {
          args.push(numberNode(options, mv));
        }
      }
      if (args.length === 0) {
        node = nodeOne;
      } else if (args.length === 1) {
        node = args[0];
      } else {
        node = binaryNode(node.op, args);
      }
      node = sort(node);
      groupedNodes[rootNid] = node;
      node.isMixedNumber = isMixedNumber;
      return node;
    }

    // Special case. Check for like factors to avoid isExpanded|Factorised "x*x"
    // to evaluate to true.
    function hasLikeFactors(node) {
      if (!isMultiplicative(node)) {
        return false;
      }
      const hash = {};
      let vp, vpnid, list;
      const result = node.args.some(function (n) {
        // Return true if there is a dup.
        // (x+3)(x+3) (xy^2)
        if (n.op === Parser.MUL &&
           hasLikeFactors(n)) {
          return true;
        }
        vpnid =
          isMinusOne(n) && ast.intern(n) ||           // -1 is special.
          n.op === Parser.NUM && (isNumeric(n) && "0" || ast.intern(n)) || // Treat numbers as likes.
          n.op === Parser.POW && (
            mathValue(options, n.args[1]) && !!variablePart(n.args[0]) && ast.intern(variablePart(n.args[0])) ||
              !!constantPart(n.args[0]) && mathValue(options, n.args[1])) ||
              !!variablePart(n) && ast.intern(variablePart(n));
        if (hash[vpnid]) {
          return true;
        }
        hash[vpnid] = true;
        return false;
      });
      return result;
    }

    function hasLikeFactorsOrTerms(node) {
      if (!isMultiplicative(node) &&
          !isAdditive(node) ||
          node.isRepeating ||
          node.isMixedNumber) {
        return false;
      }
      const hash = {};
      let vp, vpnid, list;
      const result = node.args.some(function (n) {
        // Return true if there is a dup.
        // (x+3)(x+3) (xy^2)
        if (n.op === Parser.MUL && isNeg(options, n)) {
          n = negate(n);  // This erases synthetic -1 factor.
        }
        if ((n.op === Parser.ADD || n.op === Parser.MUL) &&
            hasLikeFactorsOrTerms(n)) {
          return true;
        }
        vpnid =
          isMinusOne(n) && ast.intern(n) ||           // -1 is special.
          n.op === Parser.NUM && isNumeric(n) && "0" || // Treat numbers as likes.
          !!variablePart(n) && ast.intern(variablePart(n)) ||
          ast.intern(n);
        if (hash[vpnid]) {
          return true;
        }
        hash[vpnid] = true;
        return false;
      });
      return result;
    }

    function listNodeIDs(node) {
      const aa = [];
      if (node.op === Parser.COMMA) {
        node.args.forEach(function(n) {
          aa.push(ast.intern(n));
        });
      } else {
        aa.push(ast.intern(node));
      }
      return aa;
    }

    function diffSets(n1, n2) {
      if (n1.op === Parser.MUL) {
        assert(n1.args.length === 2, "2000: Internal error.");
        assert(n1.args[1].op === Parser.COMMA, message(2002));
        // Swap operands to undo sorting.
        const t = n2;
        n2 = n1.args[1];
        n1 = t;
      }
      const a1 = listNodeIDs(n1);
      const a2 = listNodeIDs(n2);
      const nids = a1.filter(function(i) {
        return a2.indexOf(i) < 0;
      });
      const args = [];
      nids.forEach(function (nid) {
        args.push(ast.node(nid));
      });
      if (args.length === 1) {
        return args[0];
      } else {
        return newNode(Parser.COMMA, args);
      }
    }

    function isPolynomialDenominatorWithNegativeTerm(node) {
      return node.op === Parser.POW &&
        isMinusOne(node.args[1]) &&
        node.args[0].op === Parser.ADD &&
        variables(node.args[0]).length > 0 &&
        node.args[0].args.some(function (n) {
          // Limit the complexity allowed.
          return isNeg(options, constantPart(n));
        });
    }

    function commonDenom(node) {
      if (node.op !== Parser.ADD) {
        // Not additive so create and add node so we can have the following code
        // collect denom factors into a single node.
        node = newNode(Parser.ADD, [node]);
      }
      // 1/2+2/3
      // ((1/2)(2*3)+(2/3)(2*3))/6
      // (3+4)/6
      // 7/6
      assert(node && node.op === Parser.ADD);
      let n0 = node.args;
      if (!isChemCore()) {
        // Make common denominator.
        // Get denominators.
        let denoms = [];
        let deg = 0;
        n0.forEach(function (n1) {
          // Add current node's denominator to the list.
          denoms = denom(n1, denoms);
          denoms.forEach(function (n) {
            // This is a kind of adhoc complexity check. If one of the
            // denominator is of higher degree than 2 then don't find
            // common denominator.
            const d = degree(n);
            deg = d > deg && d || deg;
          });
        });
        if (denoms.length > 1 && deg < 3 ||
            (denoms.length === 1 && !isMinusOne(denoms[0]) && !isOne(denoms[0]))) {
          // We have a non-trivial common denominator.
          let hasMinusOne = false;
          const denomsNew = [];
          denoms.forEach(denom => {
            if (isMinusOne(denom)) {
              hasMinusOne = !hasMinusOne;
            } else if (!isOne(denom)) {
              denomsNew.push(denom);
            }
          });
          const denominator = binaryNode(Parser.POW, [multiplyNode(denomsNew, true), nodeMinusOne]);
          let numers = [];
          // For each term get the numerator based on the common denominator.
          n0.forEach(function (n1) {
            let d, n;
            // 2/x+3/y -> (2y+3x)/(xy)
            // .5x+.2y -> (2x+5y)/10
            d = denom(n1, []);
            n = numer(n1, d[0], denoms);
            numers = numers.concat(n);
          });
          const numersNew = [];
          numers.forEach(numer => {
            if (isMinusOne(numer)) {
              hasMinusOne = !hasMinusOne;
            } else if (!isOne(numer)) {
              numersNew.push(numer);
            }
          });
          // Now add the numerator and multiply it by the denominator.
          if (numers.length > 0) {
            n0 = binaryNode(node.op, numers);
            let mv;
            if ((mv = mathValue(options, n0))) {
              n0 = numberNode(options, mv);
            }
            node = multiplyNode([n0, denominator]);
          } else {
            node = denominator;
          }
          if (hasMinusOne) {
            node = negate(node);
          }
        } else {
          // Just return the original node.
        }
      }
      return node;
    }
    function numer(n, d, denoms) {
      // Denominators are in positive power form.
      // n = node to get numerator of.
      // d = denominator of current node.
      // denoms = all common denominators.
      // n/d/denoms
      denoms = denoms.slice(0); // Copy
      const ff = factors(options, n, {}, true, true);
      const hasNumer = false;
      let n0, nn = [];
      let hasMinusOne = false;
      ff.forEach(function (n) {
        if (isMinusOne(n)) {
          hasMinusOne = !hasMinusOne;
        } else if (n.op !== Parser.POW || !isNeg(options, mathValue(options, n.args[1], true))) {
          // Is a numerator.
          nn.push(n);
        }
      });
      if (hasMinusOne) {
        if (nn.length === 0) {
          nn.unshift(nodeMinusOne);
        } else {
          nn.unshift(negate(nn.shift()));
        }
      }
      if (nn.length === 0 || nn.length === 1 && isOne(nn[0])) {
        // If no numerator or numerator of one, then use an empty array
        // that gets concat'd away. This happens when there are no factors
        // with a non-negative exponent.
        n0 = [];
      } else {
        n0 = [multiplyNode(nn)];
      }
      // See if the common denominator has an expression that matches
      // the current terms denominator. If so remove it from the list.
      const nid0 = d ? ast.intern(d) : 0; // If no denom then use 0 as nid.
      let index = -1;
      denoms.some(function (n, i) {
        const nid1 = ast.intern(n);
        if (nid0 === nid1) {
          index = i;
          return true;
        }
        return false;
      });
      if (index > -1) {
        // Remove element that is in the numerator's denominator.
        denoms.splice(index, 1);
      }
      // Multiply top common denominator. Simplify to cancel factors.
      if (n0.length !== 0 || denoms.length !== 0) {
        const args = sortFactors(n0.concat(denoms));
        return multiplyNode(args, true);
      }
      return nodeOne; // Otherwise everthing degenerates to 1.
    }
    function denom(n, denoms) {
      // If the current node has a different denominator as those in denoms,
      // then add it. Denominators are in positive power form.
      const ff = factors(options, n, {}, true, true);
      const hasDenom = false;
      let d0, dd = [];
      ff.forEach(function (n) {
        d0 = n.args[0];
        if (n.op === Parser.POW && !isOne(n.args[0])) {
          // If denominator is 1 then skip it.
          if (isMinusOne(n.args[1])) {
            if (dd.length === 0) {
              dd.unshift(nodeMinusOne);
            } else {
              dd.unshift(negate(dd.shift(dd)));
            }
          } else if (isNeg(options, mathValue(options, n.args[1], true))) {
            dd.push(binaryNode(Parser.POW, [d0, simplify(options, negate(n.args[1]), env)]));
          }
        }
      });
      if (dd.length === 0) {
        // If no new denominators, then return original set.
        return denoms;
      } else {
        d0 = multiplyNode(dd);
      }
      // Add to denoms if not already there.
      if (denoms.every(function (d) {
        return ast.intern(d) !== ast.intern(d0);
      })) {
        denoms.push(d0);
      }
      return denoms;
    }
    const simplifiedNodes = [];
    // var simplifyLevel = 0;
    function simplify(options, root, env, resume) {
      assert(root && root.args, "2000: Internal error.");
      assert(root.op !== Parser.MUL || root.args.length > 1, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.simplifyNid === nid) {
        return root;
      }
      // if (simplifyLevel === 0) {
      //   console.log("simplify() nid=" + nid + " node: " + JSON.stringify(root, null, 2));
      // }
      // simplifyLevel++;
      let node = Parser.create(options, visit(options, root, {
        name: "simplify",
        numeric: function (node) {
          return node;
        },
        additive: function (node) {
          assert(node && node.op !== Parser.SUB,
                 "2000: simplify(options, ) additive node not normalized: " + JSON.stringify(node));
          if (node.op === Parser.PM) {
            return node;
          }
          const isMixedNumber = node.isMixedNumber;
          node = cancelTerms(node);
          if (!env || !env.dontGroup) {
            node = groupLikes(node);
          }
          if (!isAdditive(node)) {
            // Have a new kind of node so start over.
            return node;
          }
          // Simplify kids.
          var args = [];
          node.args.forEach(function (n, i) {
            args = args.concat(simplify(options, n, env));
          });
          node = binaryNode(node.op, args);
          node.isMixedNumber = isMixedNumber;
          if (node.op === Parser.PM) {
            return node;
          } else if (node.op === Parser.BACKSLASH ||
                     node.op === Parser.ADD &&
                     node.args.length === 2 &&
                     node.args[0].op === Parser.MUL &&
                     node.args[0].args.length === 2 &&
                     node.args[0].args[0].op === Parser.NUM &&
                     node.args[0].args[0].args[0] === "-1" &&
                     node.args[0].args[1].op === Parser.COMMA &&
                     node.args[1].op === Parser.COMMA) {
            return diffSets(node.args[0], node.args[1]);
          }
          // Make denominators common.
          if (!option(options, "dontFactorDenominators") || !isMixedNumber && isNumeric(node)) {
            // It's a numeric expression so simplify it anyway.
            node = commonDenom(node);
          }
          if (!isAdditive(node)) {
            // Have a new kind of node so start over.
            return node;
          }
          // Now fold other terms
          var args = node.args.slice(0);  // Make a copy.
          let n0 = [simplify(options, args.shift(), env)];
          // For each next value, pop last value and fold it with next value.
          args.forEach(function (n1, i) {
            n1 = simplify(options, n1, env);
            n0 = n0.concat(fold(n0.pop(), n1));
          });
          if (n0.length < 2) {
            node = n0[0];
          } else {
            node = binaryNode(node.op, n0);
          }
          node.isMixedNumber = isMixedNumber;
          assert(node.args.length > 0, "2000: Internal error.");
          return node;
          function fold(lnode, rnode) {
            const ldegr = degree(lnode);
            const rdegr = degree(rnode);
            const lcoeff = constantPart(lnode);
            const rcoeff = constantPart(rnode);
            if (isZero(lcoeff)) {
              return rnode;
            }
            if (isZero(rcoeff)) {
              return lnode;
            }
            if (ldegr === rdegr) {
              // Have two terms of the same degree.
              const lvpart = variablePart(lnode);
              const rvpart = variablePart(rnode);
              // Combine terms with like factors.
              if (lvpart !== null && rvpart !== null &&
                  ast.intern(lvpart) === ast.intern(rvpart)) {
                const c = addNode([lcoeff, rcoeff]);
                const cmv = mathValue(options, c);
                if (isZero(cmv)) {
                  return nodeZero;
                } else if (isOne(cmv)) {
                  return lvpart;
                }
                return multiplyNode([c, lvpart]);
              } else if (lnode.op === Parser.LOG && rnode.op === Parser.LOG &&
                         (ast.intern(lnode.args[0]) === ast.intern(rnode.args[0]))) {
                return simplify(options, newNode(Parser.LOG, [lnode.args[0], multiplyNode([lnode.args[1], rnode.args[1]])]), env);
              } else if (ldegr === 0 && rdegr === 0) {
                // Have two constants.
                const mv1 = mathValue(options, lnode, true);
                const mv2 = mathValue(options, rnode, true);
                if (isInteger(mv1) && isInteger(mv2)) {
                  return numberNode(options, mv1.plus(mv2));
                } else if (ast.intern(lnode) === ast.intern(rnode)) {
                  return multiplyNode([nodeTwo, lnode]);
                } else if ((!env || !env.dontGroup) && !option(options, "dontFactorTerms") && commonFactors(options, lnode, rnode).length > 0) {
                  return [factorTerms(lnode, rnode)];
                } else {
                  return [lnode, rnode];
                }
              } else if (ldegr === 2 && rdegr === 2 &&
                         isOne(lcoeff) && isOne(rcoeff) &&
                         (lnode.args[0].op === Parser.SIN &&
                          rnode.args[0].op === Parser.COS ||
                          lnode.args[0].op === Parser.COS &&
                          rnode.args[0].op === Parser.SIN) &&
                         ast.intern(lnode.args[0].args[0]) === ast.intern(rnode.args[0].args[0])) {
                // Special case: sin^2(x)+cos^2(x)
                return nodeOne;
              } else if (ldegr === 2 && rdegr === 2 &&
                         isOne(lcoeff) && isOne(rcoeff) &&
                         (lnode.args[0].op === Parser.SIN &&
                          rnode.args[0].op === Parser.COS ||
                          lnode.args[0].op === Parser.COS &&
                          rnode.args[0].op === Parser.SIN) &&
                         ast.intern(lnode.args[0].args[0]) === ast.intern(rnode.args[0].args[0])) {
                // Special case: sin^2(x)+cos^2(x)
                return nodeOne;
              }
            }
            if (ast.intern(lnode) === ast.intern(rnode)) {
              return multiplyNode([nodeTwo, lnode]);
            } else if (isZero(mathValue(options, lcoeff))) {
              return rnode;
            } else if (isZero(mathValue(options, rcoeff))) {
              return lnode;
            } else if (!option(options, "dontFactorTerms") && !isOne(mathValue(options, lcoeff)) && !isOne(mathValue(options, rcoeff))) {
              if (commonFactors(options, lnode, rnode).length > 0) {
                const node = [factorTerms(lnode, rnode)];
                return node;
              }
            }
            return [lnode, rnode];
          }
        },
        multiplicative: function (node) {
          assert(node && node.op === Parser.MUL, "2000: simplify() multiplicative node not normalized: " + JSON.stringify(node));
          node = cancelFactors(options, node);
          if (!env || !env.dontGroup) {
            node = groupLikes(node);
          }
          if (!isMultiplicative(node)) {
            // Have a new kind of node start over.
            return node;
          }
          const nid = ast.intern(node);
          const args = node.args.slice(0);
          let n0 = [simplify(options, args.shift(), env)];
          if (n0[0].op === Parser.MUL) {
            // Flatten.
            n0 = n0[0].args.slice(0);
          }
          // For each next value, pop last value and fold it with next value.
          args.forEach(function (n1, i) {
            n1 = simplify(options, n1, env);
            n0 = n0.concat(fold(n0.pop(), n1));
          });
          if (n0.length < 2) {
            assert(n0.length, "2000: Internal error.");
            node = n0[0];
          } else {
            node = sort(multiplyNode(n0, true));
          }
          return node;
          function fold(lnode, rnode) {
            const ldegr = degree(lnode);
            const rdegr = degree(rnode);
            const lvars = variables(lnode);
            const rvars = variables(rnode);
            const lvpart = variablePart(lnode);
            const rvpart = variablePart(rnode);
            const lcoeff = constantPart(lnode);
            const rcoeff = constantPart(rnode);
            const lcoeffmv = mathValue(options, lcoeff, true);
            const rcoeffmv = mathValue(options, rcoeff, true);
            let lmv, rmv;
            if (ldegr === 0 && isZero(lcoeffmv) && !isUndefined(rnode) ||
                rdegr === 0 && isZero(rcoeffmv) && !isUndefined(lnode)) {
              if (units(lnode).length || units(rnode).length) {
                // Don't erase units.
                return [lnode, rnode];
              } else {
                return nodeZero;
              }
            } if (isInteger(lmv = mathValue(options, lnode)) && isInteger(rmv = mathValue(options, rnode))) {
              return numberNode(options, lmv.times(rmv));
            } else if (ldegr === 0 && isOne(lcoeffmv)) {
              return rnode;
            } else if (rdegr === 0 && isOne(rcoeffmv)) {
              return lnode;
            } else  if (isInfinity(lnode)) {
              if (isNeg(options, rnode)) {
                return negate(lnode);
              } else {
                return lnode;
              }
            } else if (isInfinity(rnode)) {
              if (isNeg(options, lnode)) {
                return negate(rnode);
              } else {
                return rnode;
              }
            } else if (ldegr === 0 && rdegr === 0) {
              if (isOne(rcoeffmv) && isOne(lcoeffmv)) {
                // Have two constants that have the math value of one.
                return nodeOne;
              } else if (isImaginary(lnode) && isImaginary(rnode)) {
                return nodeMinusOne;
              }
              var lexpo = exponent(lnode);
              var rexpo = exponent(rnode);
              var lbase = base(lnode);
              var rbase = base(rnode);
              if (lbase !== null && rbase !== null &&
                  Math.abs(lexpo) === 1 && Math.abs(rexpo) === 1) {
                if (lexpo === rexpo) {
                  // 2^3*3^3, combine bases
                  if (isMinusOne(lbase) || isMinusOne(rbase)) {
                    node = [lnode, rnode];
                  } else {
                    node = multiplyNode([numberNode(options, lbase), numberNode(options, rbase)], true);  // Flatten because numberNode creates mul nodes for negatives.
                    if ((mv = mathValue(options, node))) {
                      node = numberNode(options, mv);
                    }
                    if (lexpo === -1) {
                      node = binaryNode(Parser.POW, [node, nodeMinusOne]);
                    }
                  }
                } else {
                  // We've got a fraction to simplify.
                  var mv;
                  if (isZero(lnode)) {
                    node = nodeZero;
                  } else if ((mv = mathValue(options, multiplyNode([lnode, rnode])))) {
                    node = numberNode(options, mv);
                  } else {
                    const lbaseN = toNumber(lbase);
                    const rbaseN = toNumber(rbase);
                    var d = gcd(lbaseN, rbaseN);
                    if (d === (d | 0)) {
                      // Have integer GCD.
                      lbase = divide(lbase, toDecimal(d));
                      rbase = divide(rbase, toDecimal(d));
                    }
                    if (lexpo < 0 && isOne(lbase)) {
                      node = numberNode(options, rbase);
                    } else if (rexpo < 0 && isOne(rbase)) {
                      node = numberNode(options, lbase);
                    } else {
                      let n = lexpo === 1 ? lbase : rbase;
                      var d = lexpo === 1 ? rbase : lbase;
                      if (isOne(n)) {
                        // If the numerator is 1, erase it.
                        node = binaryNode(Parser.POW, [numberNode(options, d), nodeMinusOne]);
                      } else {
                        const q = divide(n, d);
                        if (isInteger(q)) {
                          // Got an integer, use it.
                          node = numberNode(options, q);
                        } else {
                          // Otherwise, make a new simplified fraction.
                          if (isNeg(options, n) && isNeg(options, d)) {
                            n = n.times(toDecimal("-1"));
                            d = d.times(toDecimal("-1"));
                          }
                          node = [
                            numberNode(options, n),
                            binaryNode(Parser.POW, [numberNode(options, d), nodeMinusOne])
                          ];
                        }
                      }
                    }
                  }
                }
              } else if (lnode.op === Parser.POW && rnode.op === Parser.POW &&
                         ast.intern(lnode.args[1]) === ast.intern(rnode.args[1])) {
                // x^z*y^z -> (x*y)^z
                var lbase = lnode.args[0];
                var rbase = rnode.args[0];
                var lexpo = exponent(lnode);
                var rexpo = exponent(rnode);
                if (lexpo === 0.5 &&
                    ast.intern(lbase) === ast.intern(rbase)) {
                  // Found square of square roots, so simplify.
                  node = lbase;
                } else if (lexpo !== -1 && !isMinusOne(lbase) && !isMinusOne(rbase)) {
                  // FIXME simplifying "1/cos{1.03}" causes infinite recursion. So avoid for now.
                  node = binaryNode(Parser.POW, [simplify(options, multiplyNode([lbase, rbase])), lnode.args[1]]);
                } else {
                  node = [lnode, rnode];
                }
              } else {
                node = [lnode, rnode];
              }
            } else if (lvpart && rvpart && ast.intern(lvpart) === ast.intern(rvpart)) {
              // One or both nodes contain var.
              var lnode =
                  isOne(lcoeff) && rcoeff ||
                  isOne(rcoeff) && lcoeff ||
                  multiplyNode([lcoeff, rcoeff]);
              if (lvpart.op === Parser.POW) {
                // FIXME if lvpart (and therefore rvpart) base is additive and
                // expos are the same, then multiply out bases
                assert(lvpart.args.length === 2 && rvpart.args.length === 2, "2000: Exponents of exponents not handled here.");
                var lexpo = lvpart.args[1];
                var rexpo = rvpart.args[1];
                var rnode = binaryNode(Parser.POW, [
                  lvpart.args[0],
                  addNode([lexpo, rexpo])
                ]);
              } else {
                var rnode = binaryNode(Parser.POW, [lvpart, nodeTwo]);
              }
              if (isZero(mathValue(options, lnode))) {
                node = [];
              } else if (isOne(mathValue(options, lnode))) {
                node = rnode;
              } else {
                node = [lnode, rnode];
              }
            } else if (ast.intern(lnode.op === Parser.POW ? lnode.args[0] : lnode) ===
                       ast.intern(rnode.op === Parser.POW ? rnode.args[0] : rnode)) {
              // Same base, different exponents.
              let b, el, er;
              if (lnode.op === Parser.POW) {
                b = lnode.args[0];
              } else {
                b = lnode;
              }
              if (lnode.op === Parser.POW) {
                el = lnode.args[1];
              } else {
                el = nodeOne;
              }
              if (rnode.op === Parser.POW) {
                er = rnode.args[1];
              } else {
                er = nodeOne;
              }
              const e = simplify(options, addNode([el, er]), env);
              if (isZero(e)) {
                // x^0 = 1
                node = nodeOne;
              } else if (isOne(e)) {
                // x^1 = x
                node = b;
              } else {
                node = binaryNode(Parser.POW, [b, e]);
              }
            } else if (ldegr === 0 && isOne(lcoeffmv)) {
              return rnode;
            } else if (rdegr === 0 && isOne(rcoeffmv)) {
              return lnode;
            } else if (ldegr === 0) {
              if (sign(lnode) < 0 && isPolynomialDenominatorWithNegativeTerm(rnode)) {
                // If lnode is negative and rnode is a polynomial denominator, then invert.
                return [negate(lnode), expand(options, negate(rnode))];
              }
              var v = mathValue(options, lnode);
              if (v !== null) {
                node = [numberNode(options, v), rnode];
              } else {
                node = [lnode, rnode];
              }
            } else if (rdegr === 0) {
              var v = mathValue(options, rnode);
              if (v !== null) {
                node = [numberNode(options, v), lnode];  // Coeffs first.
              } else {
                node = [lnode, rnode];
              }
            } else if (option(options, "dontExpandPowers") &&
                       lnode.op === Parser.POW && rnode.op === Parser.POW &&
                       ast.intern(lnode.args[1]) === ast.intern(rnode.args[1])) {
              // x^z*y^z -> (xy)^z
              var lbase = lnode.args[0];
              var rbase = rnode.args[0];
              let args = [];
              if (lbase.op === Parser.MUL) {
                // Flatten nested multiplication.
                args = args.concat(lbase.args);
              } else {
                args.push(lbase);
              }
              if (rbase.op === Parser.MUL) {
                // Flatten nested multiplication.
                args = args.concat(rbase.args);
              } else {
                args.push(rbase);
              }
              node = binaryNode(Parser.POW, [simplify(options, multiplyNode(args)), lnode.args[1]]);
            } else {
              node = [lnode, rnode];
            }
            if (lnode.op === Parser.PM || rnode.op === Parser.PM) {
              if (node instanceof Array) {
                node = binaryNode(Parser.PM, node);
              } else {
                node = unaryNode(Parser.PM, [node]);
              }
            }
            return node;
          }
        },
        unary: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(simplify(options, n, env));
          });
          node = newNode(node.op, args);
          switch (node.op) {
          case Parser.SUB:
            // Remove unary SUBs
            node = negate(node.args[0]);
            break;
          case Parser.ABS:
            var arg = simplify(options, node.args[0]);
            var cp = constantPart(arg);
            var vp = variablePart(arg);
            var ep;
            if (vp && vp.op === Parser.POW && vp.args.length === 2) {
              ep = vp.args[1];
              vp = vp.args[0];
            }
            if (vp && sign(vp) < 0) {
              // If the variable part has a negative sign, then invert it.
              // Make sure we simplify before continuing to avoid thrashing.
              vp = unaryNode(Parser.ABS, [simplify(options, expand(options, negate(vp)))]);
            } else {
              vp = vp ? unaryNode(Parser.ABS, [vp]) : nodeOne;
            }
            if (ep) {
              vp = binaryNode(Parser.POW, [vp, ep]);
            }

            if (isOne(cp) || isMinusOne(cp)) {
              node = vp;
            } else if (isNeg(options, cp)) {
              // If the expression is negative, move inverse of constant part
              // outside of the \abs.
              node = multiplyNode([
                // Make sure we simplify before continuing to avoid thrashing.
                simplify(options, expand(options, negate(cp))),
                vp,
              ]);
            } else {
              // If positive, move constant part outside of the \abs.
              node = multiplyNode([
                cp,
                vp,
              ]);
            }
            // Otherwise already positive.
            break;
          case Parser.M:
            var mv = mathValue(options, node);
            if (mv !== null) {
              node = numberNode(options, mv);
            }
            // Otherwise, don't simplify.
            break;
          case Parser.PM:
          default:
            node = unaryNode(node.op, args);
          }
          return node;
        },
        exponential: function (node) {
          const base = node.args[0];
          // Make a copy of and reverse args to work from right to left.
          const nid = ast.intern(node);
          const args = node.args.slice(0).reverse();
          let n0 = [simplify(options, args.shift(), env)];
          // For each next value, pop last value and fold it with next value.
          args.forEach(function (n1, i) {
            n1 = simplify(options, n1, env);
            n0 = n0.concat(fold(node.op, n0.pop(), n1));
          });
          if (n0.length === 1) {
            const n = n0[0];
            if (n.op !== Parser.NUM || isInteger(n) ||
               isInfinity(n) ||
               isUndefined(n)) {
              // If the result is not a number or is a whole number, then return it.
              node = n;
            } // Otherwise return the orginal expression.
          } else {
            if (isInfinity(n0[1]) && isNeg(options, n0[0])) {
              return nodeZero;
            }
            node = binaryNode(node.op, n0.reverse());
          }
          return node;
          function fold(op, expo, base) {
            var mv, node;
            const bmv = mathValue(options, base);
            const emv = mathValue(options, expo, {}, true);
            if (op === Parser.POW) {
              if (isZero(bmv)) {
                // 0^x
                if (isNeg(options, emv)) {
                  return [undefinedNode(newNode(op, [base, expo]))];
                } else {
                  return [nodeZero];
                }
              } else if (isZero(emv)) {
                // x^0
                return [nodeOne];
              } else if (isOne(bmv)) {
                // 1^x
                return [nodeOne];
              } else if (isOne(emv)) {
                // x^1
                return [base];
              } else if (isImaginary(base) && emv !== null) {
                if (emv.modulo(bigFour).cmp(bigZero) === 0) {
                  return [nodeOne];
                } else if (emv.modulo(bigTwo).cmp(bigZero) === 0) {
                  return [nodeMinusOne];
                } else if (emv.modulo(bigThree).cmp(bigZero) === 0) {
                  return [negate(nodeImaginary)];
                } else if (emv.modulo(bigFive).cmp(bigZero) === 0) {
                  return [nodeImaginary];
                }
                return [expo, base];
              } else if (base.op === Parser.POW) {
                // Flatten nested exponents.
                return binaryNode(Parser.POW, [base.args[0], multiplyNode(sortFactors([base.args[1], expo]))]);
              } else if (isMinusOne(base) && isOddFraction(expo)) {
                // Move the minus outside of the power unless its {-1}^{-1} which is a
                // synthetic idiom for negative coefficients.
                // Odd integers qualify as odd fractions. Key is that numerator
                // and denominator are both odd.
                if (isMinusOne(expo)) {
                  return nodeMinusOne;
                } else {
                  return multiplyNode([nodeMinusOne, binaryNode(Parser.POW, sortFactors([negate(base), expo]))]);
                }
              } else if (!option(options, "dontExpandPowers") && base.op === Parser.MUL) {
                // Expand factors.
                const args = [];
                let hasMinusOne = false;
                base.args.forEach(function (n) {
                  if (n.op === Parser.POW) {
                    // Flatten.
                    args.push(binaryNode(Parser.POW, [n.args[0], multiplyNode(sortFactors([n.args[1], expo]))]));
                  } else if (isMinusOne(n) && isMinusOne(expo)) {
                    hasMinusOne = !hasMinusOne;
                  } else {
                    args.push(binaryNode(Parser.POW, [n, expo]));
                  }
                });
                if (hasMinusOne) {
                  if (args.length === 0) {
                    args.push(nodeMinusOne);
                  } else {
                    args.unshift(negate(args.shift()));
                  }
                }
                return multiplyNode(args, true);
              } else if (bmv !== null && emv !== null && !isNeg(options, bmv)) {
                // 2^3, 16^(-1*1^-2)
                var b = pow(bmv, emv);
                base = numberNode(options, b);
                return base;
              } else if (expo.op === Parser.LOG &&
                         ast.intern(base) === ast.intern(expo.args[0])) {
                return expo.args[1];
              } else if (base.op === Parser.SINH && ast.intern(expo) === ast.intern(nodeTwo)) {
                // sinh^2 = cosh^2 - 1
                return addNode([binaryNode(Parser.POW, [newNode(Parser.COSH, base.args), nodeTwo]), nodeMinusOne]);
              } else {
                var b = pow(bmv, emv);
                if (b !== null) {
                  return numberNode(options, b);
                }
              }
            } else if (op === Parser.LOG) {
              if (emv !== null && isE(base)) {
                var mv = toDecimal(Math.log(toNumber(emv)));
                if (isInteger(mv)) {
                  return numberNode(options, mv);
                }
              } else if (ast.intern(base) === ast.intern(expo)) {
                return nodeOne;
              } else if (!option(options, "dontExpandPowers") && !isE(base)) {
                // If LOG and not base e, then normalize to base e.
                // var base = node.args[0];
                // var expo = node.args[1];
                return multiplyNode([
                  binaryNode(Parser.LOG, [nodeE, expo]),
                  binaryNode(Parser.POW, [
                    binaryNode(Parser.LOG, [nodeE, base]),
                    nodeMinusOne
                  ])
                ]);
              }
            }
            // x^2, x^y
            return [expo, base];
          }
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(simplify(options, n, env));
          });
          return newNode(node.op, args);
        },
        equals: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(simplify(options, n, env));
          });
          assert(args.length === 2, "2000: Internal error.");
          if (isZero(args[1])) {
            const mv = mathValue(options, args[0], true);
            if (mv !== null) {
              // If its a number, then we're done.
              return newNode(node.op, args);
            }
            const ff = factors(options, args[0], {}, true, true, true);
            let erasedMinus = false;
            if (isMinusOne(ff[0])) {
              // Drop the leading negative one.
              ff.shift();
              erasedMinus = true;
            }
            let args0 = [];
            let foundZero = false;
            ff.forEach(function (n) {
              const mv = mathValue(options, n, true);
              if (erasedMinus && isInequality(node.op) ||
                  mv !== null && !isZero(mv) && ff.length > 1 ||
                  n.op === Parser.VAR && units(n).length > 0 && ff.length > 1 ||  // $, cm, s^2
                  n.op === Parser.POW && units(n.args[0]).length > 0 && mathValue(options, n.args[0]) !== null && ff.length > 1 ||  // $, cm, s^2
                  n.op === Parser.POW && isNeg(options, n.args[1])) {
                if (node.op !== Parser.EQL && node.op !== Parser.APPROX /*&& isNeg(options, n)*/) {
                  // We are erasing a negative so multiply by -1 to preserve inequality.
                  if (args0.length > 0) {
                    args0.push(expand(options, negate(args0.pop())));
                  } else if (ff.length === 1) {
                    args0.push(expand(options, negate(n)));
                  }
                }
                // Ignore constant factors including units, unless they are alone.
              } else if (isZero(mv)) {
                // Result is zero.
                args0 = [nodeZero];
                foundZero = true;
              } else {
                args0 = args0.concat(n);
              }
            });
            if (args0.length > 0) {
              // Multiply the remaining numerator terms.
              args[0] = multiplyNode(args0);
            } else {
              // LHS has no more terms, so is zero.
              args[0] = nodeZero;
            }
          }
          return newNode(node.op, args);
        }
      }), root.location);
      // simplifyLevel--;
      // If the node has changed, simplify again
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        // console.log("simplify() nid=" + nid);
        // if (nid === 175 || nid === 178) {
        //   console.log("simplify() node=" + JSON.stringify(node, null, 2));
        // }
        node = simplify(options, node, env);
      }
      node.simplifyNid = nid;
      // simplifiedNodes[rootNid] = node;
      return node;
    }

    function sign(node) {
      let s = 0;
      const tt = terms(node);
      tt.forEach(function (n) {
        const mv = mathValue(options, n);
        if (isNeg(options, leadingCoeff(n))) {
          s -= 1;
        } else {
          s += 1;
        }
      });
      if (s === 0) {
        if (isNeg(options, (leadingCoeff(tt[0])))) {
          s = -1;
        } else {
          s = 1;
        }
      }
      return s;
    }

    function base(node) {
      // Return the base if it is a number.
      const op = node.op;
      const base = op === Parser.POW
        ? mathValue(options, node.args[0])
        : mathValue(options, node);
      return base;
    }

    function exponent(node) {
      return node.op === Parser.POW ? toNumber(mathValue(options, node.args[1], {}, true)) : 1;
    }

    function log(b, x) {
      return Math.log(x) / Math.log(b);
    }

    // Return the math value of an expression, or null if the expression does
    // not have a math value.

    let mathValueLevel = 0;
    function mathValue(options, root, env, allowDecimal, normalizeUnits) {
      if (!root || !root.args) {
        return null;
      }
//      assert(root && root.args, "2000: Internal error.");
      if (env === undefined) {
        env = Parser.env;
      } else if (typeof env === "boolean") {
        normalizeUnits = allowDecimal;
        allowDecimal = env;
        env = Parser.env;
      }
      mathValueLevel++;
      const node = visit(options, root, {
        name: "mathValue",
        numeric: function (node) {
          if (isUndefined(node)) {
            return null;
          }
          return toDecimal(node);
        },
        additive: function (node) {
          if (node.op === Parser.PM || isRepeating(node)) {
            return null;
          }
          // Simplify each side.
          let val = bigZero;
          node.args.forEach(function (n) {
            const mv = mathValue(options, n, env, true, normalizeUnits);
            if (mv && val) {
              if (node.op === Parser.SUB) {
                val = val.minus(mv);
              } else {
                val = val.plus(mv);
              }
            } else {
              val = null;
            }
          });
          if (allowDecimal || isInteger(val)) {
            return val;
          } else {
            return null;
          }
        },
        multiplicative: function (node) {
          // Allow decimal if the option 'allowDecimal' is set to true or
          // if at least one of the operands is a decimal.
          // (1+1/10)^3 --> 11^3*10^{-3} --> (11/10)^3
          let val = bigOne;
          let hasDecimal = false;
          node.args.forEach(function (n) {
            hasDecimal = hasDecimal || isDecimal(n);
            const mv = mathValue(options, n, env, true, normalizeUnits);
            if (val !== null && mv != null) {
              val = val.times(mv);
            } else {
              val = null;
            }
          });
          if (allowDecimal || isInteger(val) ||
              hasDecimal && option(options, "doingSimplified")) {
            // The last alternative is a secret handshake that says we are in
            // isSimplified so mutliply decimals.
            return val;
          }
          return null;
        },
        unary: function(node) {
          if (isGrouping(options, node, mathValueLevel)) {
            return mathValue(options, node.args[0], env, allowDecimal, normalizeUnits);
          }
          switch (node.op) {
          case Parser.SUB:
            var val = mathValue(options, node.args[0], env, allowDecimal, normalizeUnits);
            if (val === null) {
              return null;
            }
            return val.times(bigMinusOne);
          case Parser.FACT:
            var n = mathValue(options, node.args[0], env, allowDecimal, normalizeUnits);
            if (n) {
              return toDecimal(factorial(n));
            } else {
              return null;
            }
          case Parser.M:
            var args = [];
            // M.args[0] -> ADD.args
            if (node.args[0].op === Parser.MUL) {
              node.args[0].args.forEach(function (n) {
                assert(n.op === Parser.VAR, "2000: Invalid arguments to the \M tag");
                const sym = Parser.env[n.args[0]];
                assert(sym && sym.mass, "2000: Missing chemical symbol");
                const count = n.args[1] ? toNumber(mathValue(options, n.args[1], env, allowDecimal, normalizeUnits)) : 1;
                args.push(numberNode(options, sym.mass * count));
              });
            } else {
              // Just have one VAR node.
              var n = node.args[0];
              assert(n.op === Parser.VAR, "2000: Invalid arguments to the \M tag");
              const sym = Parser.env[n.args[0]];
              assert(sym && sym.mass, "2000: Missing chemical symbol");
              const count = n.args[1] ? toNumber(mathValue(options, n.args[1], env, allowDecimal, normalizeUnits)) : 1;
              args.push(numberNode(options, sym.mass * count));
            }
            return mathValue(options, makeTerm(args), env, allowDecimal, normalizeUnits);
          case Parser.ABS:
            return abs(mathValue(options, node.args[0], env, allowDecimal, normalizeUnits));
          case Parser.SIN:
          case Parser.COS:
          case Parser.TAN:
          case Parser.ARCSIN:
          case Parser.ARCCOS:
          case Parser.ARCTAN:
          case Parser.SINH:
          case Parser.COSH:
          case Parser.TANH:
          case Parser.ARCSINH:
          case Parser.ARCCOSH:
          case Parser.ARCTANH:
            if (allowDecimal) {
              var val;
              if (isPositiveInfinity(node.args[0])) {
                val = Number.POSITIVE_INFINITY;
              } else if (isNegativeInfinity(node.args[0])) {
                val = Number.NEGATIVE_INFINITY;
              } else {
                val = mathValue(options, toRadians(node.args[0]), env, allowDecimal, normalizeUnits);
              }
              return trig(val, node.op);
            }
            return null;
          case Parser.ADD:
            return mathValue(options, node.args[0], env, allowDecimal, normalizeUnits);
          case Parser.DEGREE:
            return mathValue(options, toRadians(node.args[0]), env, allowDecimal, normalizeUnits);
          default:
            return null;
          }
        },
        exponential: function (node) {
          // Allow decimal if the option 'allowDecimal' is set to true or
          // if at least one of the operands is a decimal.
          const args = node.args.slice(0).reverse();
          let val = mathValue(options, args.shift(), env, allowDecimal, normalizeUnits);
          const op = node.op;
          if (op === Parser.POW) {
            args.forEach(function (n) {
              const mv = mathValue(options, n, env, true, normalizeUnits);
              if (val !== null && mv != null) {
                val = pow(mv, val);
              } else {
                val = null;
              }
            });
          } else if (op === Parser.LOG) {
            assert(args.length === 1, "2000: Internal error.");
            let mv;
            const emv = val;
            const base = args[0];
            const bmv = mathValue(options, base, true, normalizeUnits);
            if (emv !== null) {
              if (bmv !== null) {
                val = logBase(bmv, emv);
              } else if (base.op === Parser.VAR && base.args[0] === "e") {
                val = toDecimal(Math.log(toNumber(emv)));
              }
            }
          }
          if (allowDecimal || isInteger(val)) {
            return val;
          }
          return null;
        },
        variable: function(node) {
          let val, n;
          if ((val = env[node.args[0]]) &&
              (val.type === "const" || val.type === "unit" && normalizeUnits)) {
            n = val.value;
          }
          if (n && (allowDecimal || isInteger(n))) {
            return toDecimal(n);
          }
          return null;
        },
        comma: function(node) {
          return null;
        },
        equals: function(node) {
          return null;
        }
      });
      mathValueLevel--;
      return node;
      function exponent(node) {
        // FIXME this is brittle. need way to handle general exponents
        return node.op === Parser.POW ? +node.args[1].args[0] : 1;
      }
    }
    function getUnique(list) {
      const u = {}, a = [];
      for(let i = 0, l = list.length; i < l; ++i){
        if(u.hasOwnProperty(list[i])) {
          continue;
        }
        a.push(list[i]);
        u[list[i]] = 1;
      }
      return a;
    }
    // Get the list of units used in an expression.
    function units(root, env) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "units",
        exponential: function (node) {
          const uu = units(node.args[0], env);
          if (uu.length > 0) {
            return [node];
          }
          return [];
        },
        multiplicative: function (node) {
          let uu = [];
          node.args.forEach(function (n) {
            uu = uu.concat(units(n, env));
          });
          return uu;
        },
        additive: function (node) {
          let uu = [];
          node.args.forEach(function (n) {
            uu = uu.concat(units(n, env));
          });
          return uu;
        },
        unary: function(node) {
          return [];
        },
        numeric: function(node) {
          return [];
        },
        variable: function(node) {
          let val, env = Parser.env;
          if (env && (val = env[node.args[0]])) {
            if (val.type === "unit") {
              return [node];
            }
          }
          return [];
        },
        comma: function(node) {
          let uu = [];
          node.args.forEach(function (n) {
            uu = uu.concat(units(n, env));
          });
          return uu;
        },
        equals: function(node) {
          let uu = [];
          node.args.forEach(function (n) {
            uu = uu.concat(units(n, env));
          });
          return uu;
        }
      });
    }

    function multiplyMatrix(lnode, rnode) {
      let snode, mnode;
      // Scalar * Matrix
      if (lnode.op !== Parser.MATRIX) {
        return multiplyScalarAndMatrix(lnode, rnode);
      } else if (rnode.op !== Parser.MATRIX) {
        return multiplyScalarAndMatrix(rnode, lnode);
      }
      // Matrix * Matrix
      const rowArgs = [];
      const rows = lnode.args[0].args;
      rows.forEach(function (row) {
        const colArgs = [];
        const cols = rnode.args[0].args[0].args;  // Use cols in first row as reference.
        assert(rows.length === cols.length, message(2013));
        cols.forEach(function (col, n) {
          col = getMatrixCol(rnode, n);  // Get actual column.
          colArgs.push(multiplyVectors(row.args, col));
        });
        rowArgs.push(newNode(Parser.COL, colArgs));
      });
      return newNode(Parser.MATRIX, [newNode(Parser.ROW, rowArgs)]);
    }

    function addMatrix(lnode, rnode) {
      let snode, mnode;
      // Scalar + Matrix
      if (lnode.op !== Parser.MATRIX) {
        return addScalarAndMatrix(lnode, rnode);
      } else if (rnode.op !== Parser.MATRIX) {
        return addScalarAndMatrix(rnode, lnode);
      }
      // Matrix + Matrix
      const rowArgs = [];
      const lrows = lnode.args[0].args;
      lrows.forEach(function (lrow, i) {
        let colArgs = [];
        const rrows = rnode.args[0].args;  // Use cols in first row as reference.
        assert(lrows.length === rrows.length, message(2013));
        const rrow = rrows[i];
        colArgs = addVectors(lrow.args, rrow.args);
        rowArgs.push(newNode(Parser.COL, colArgs));
      });
      return newNode(Parser.MATRIX, [newNode(Parser.ROW, rowArgs)]);
    }

    function getMatrixCol(mnode, n) {
      const vec = [];
      const rows = mnode.args[0].args;
      rows.forEach(function (row) {
        const cols = row.args;
        vec.push(cols[n]);
      });
      return vec;
    }

    function addVectors(v1, v2) {
      // v1, v2 : Array of nodes
      assert(v1.length === v2.length, message(2013));
      const args = [];
      v1.forEach(function (n1, i) {
        const n2 = v2[i];
        args.push(addNode([n1, n2]));
      });
      return args;
    }

    function multiplyVectors(v1, v2) {
      // v1, v2 : Array of nodes
      const args = [];
      v1.forEach(function (n1, i) {
        const n2 = v2[i];
        args.push(multiplyNode([n1, n2]));
      });
      return addNode(args);
    }

    function multiplyScalarAndMatrix(snode, mnode) {
      // For each row, for each column.
      const rowArgs = [];
      const rows = mnode.args[0].args;
      rows.forEach(function (row) {
        const colArgs = [];
        const cols = row.args;
        cols.forEach(function (col) {
          colArgs.push(multiplyNode([snode, col]));
        });
        rowArgs.push(newNode(Parser.COL, colArgs));
      });
      return newNode(Parser.MATRIX, [newNode(Parser.ROW, rowArgs)]);
    }

    function addScalarAndMatrix(snode, mnode) {
      // For each row, for each column.
      const rowArgs = [];
      const rows = mnode.args[0].args;
      rows.forEach(function (row) {
        const colArgs = [];
        const cols = row.args;
        cols.forEach(function (col) {
          colArgs.push(addNode([snode, col]));
        });
        rowArgs.push(newNode(Parser.COL, colArgs));
      });
      return newNode(Parser.MATRIX, [newNode(Parser.ROW, rowArgs)]);
    }

    function sortFactors(args) {
      const argsNew = [];
      let hasMinusOne = false;
      args.forEach(arg => {
        if (isMinusOne(arg)) {
          hasMinusOne = !hasMinusOne;
        } else if (!isOne(arg)) {  // Erase one.
          argsNew.push(arg);
        }
      });
      if (argsNew.length > 1) {
        // If we have multiple args, then sort them.
        const node = sort(multiplyNode(argsNew, true));
        args = node.args;
      } else {
        args = argsNew;
      }
      if (hasMinusOne) {
        args = negateFactors(args);
      }
      return args;
    }

    function multiplyTerms(lterms, rterms, expo) {
      const args = [];
      lterms.forEach(function (n0) {
        rterms.forEach(function (n1) {
          // Multiply the terms.
          let args1 = [];
          if (n0.op === Parser.MUL) {
            args1 = args1.concat(n0.args);
          } else {
            args1.push(n0);
          }
          if (n1.op === Parser.MUL) {
            args1 = args1.concat(n1.args);
          } else {
            args1.push(n1);
          }
          args1 = sortFactors(args1);
          args.push(multiplyNode(args1, true));
        });
      });
      let node = sort(addNode(args));
      if (expo !== undefined) {
        // Reapply the power.
        node = binaryNode(Parser.POW, [node, numberNode(options, expo.toString())]);
      }
      return [node];
    }

    const expandedNodes = [];
    // let expandLevel = 0;
    function expand(options, root) {
      assert(root && root.args, "2000: Internal error.");
      let nid = ast.intern(root);
      if (root.expandNid === nid) {
        return root;
      }
      let cachedNode;
      if ((cachedNode = expandedNodes[nid]) !== undefined) {
        return cachedNode;
      }
      const rootNid = nid;
      // if (expandLevel === 0) {
      //   console.log("expand() node: " + JSON.stringify(stripNids(root), null, 2));
      // }
      // expandLevel++;
      let node = Parser.create(options, visit(options, root, {
        name: "expand",
        numeric: function (node) {
          assert(typeof node.args[0] === "string", "2000: Internal error.");
          return node;
        },
        additive: function (node) {
          const isMixedNumber = node.isMixedNumber;
          const args = node.args.slice(0);  // Make copy.
          let n0 = [expand(options, args.shift())];
          args.forEach(function (n1) {
            n1 = expand(options, n1);
            n0 = n0.concat(unfold(n0.pop(), n1));
          });
          if (n0.length < 2) {
            node = n0[0];
          } else {
            node = binaryNode(node.op, n0);
          }
          node = cancelTerms(node, "expand");
          node.isMixedNumber = isMixedNumber;
          return node;
          function unfold(lnode, rnode) {
            if (lnode.op === Parser.MATRIX || rnode.op === Parser.MATRIX) {
              return addMatrix(lnode, rnode);
            }
            return [lnode, rnode];
          }
        },
        multiplicative: function (node) {
          let args = node.args.slice(0);  // Make copy.
          let n0 = [expand(options, args.shift())];
          // For each next value, pop last value and fold it with next value.
          args.forEach(function (n1) {
            n1 = expand(options, n1);
            n0 = n0.concat(unfold(n0.pop(), n1));
          });
          args = n0;
          let isNeg = false;
          n0 = [];
          args.forEach(function (n) {
            if (isOne(n)) {
              // Erase.
            } else if (isMinusOne(n)) {
              isNeg = !isNeg;
            } else {
              n0.push(n);
            }
          });
          if (isNeg) {
            // Put back one minus one.
            if (n0.length === 0) {
              n0.unshift(nodeMinusOne);
            } else {
              n0.unshift(negate(n0.shift()));
            }
          }
          if (n0.length === 0) {
            node = nodeOne;
          } else if (n0.length === 1) {
            node = n0[0];
          } else {
            node = multiplyNode(n0, true);
          }
          return node;
          function unfold(lnode, rnode) {
            // FIXME if the bases are additive and the expo are the same power,
            // then expand the base and reapply the power.
            let expo, lterms, rterms;
            if (lnode.op === Parser.MATRIX || rnode.op === Parser.MATRIX) {
              return multiplyMatrix(lnode, rnode);
            }
            if (lnode.op === Parser.POW && rnode.op === Parser.POW &&
                exponent(lnode) === exponent(rnode)) {
              lterms = terms(lnode.args[0]);
              rterms = terms(rnode.args[0]);
              expo = exponent(lnode);
            } else {
              lterms = terms(lnode);
              rterms = terms(rnode);
            }
            if (lterms && rterms &&
                (!isAggregate(lnode) && lterms.length > 1 ||
                 !isAggregate(rnode) && rterms.length > 1) &&
                lterms.length * rterms.length < 64) {
              // (x + 2)(x - 3)
              // Limit the number of terms to avoid runaway expansion.
              return multiplyTerms(lterms, rterms, expo);
            }
            let result = [];
            if (lnode.op === Parser.MUL) {
              result = result.concat(lnode.args);
            } else {
              result.push(lnode);
            }
            if (rnode.op === Parser.MUL) {
              result = result.concat(rnode.args);
            } else {
              result.push(rnode);
            }
            return result;
          }
        },
        unary: function(node) {
          // assert(node && node.op !== Parser.SQRT, "2000: SQRT removed during parsing");
          switch (node.op) {
          case Parser.ABS:
            var arg0 = expand(options, node.args[0]);
            if (arg0.op === Parser.MUL) {
              var args = [];
              arg0.args.forEach(function (n) {
                args.push(unaryNode(Parser.ABS, [n]));
              });
              node = multiplyNode(args);
            } else {
              node = unaryNode(Parser.ABS, [arg0]);
            }
            break;
          case Parser.SUB:
            node = multiplyNode([expand(options, node.args[0]), nodeMinusOne]);
            node.args[0] = expand(options, node.args[0]);
            break;
          default:
            var args = [];
            node.args.forEach(function (n) {
              args.push(expand(options, n));
            });
            node = unaryNode(node.op, args);
            break;
          }
          return node;
        },
        exponential: function (node) {
          // (xy)^z -> x^zy^z
          // Make a copy of and reverse args to work from right to left.
          const args = node.args.slice(0).reverse();
          let n0 = [expand(options, args.shift())];
          // For each next value, pop last value and fold it with next value.
          args.forEach(function (n1) {
            n1 = expand(options, n1);
            n0 = n0.concat(unfold(node.op, n0.pop(), n1));
          });
          let node2;
          if (n0.length < 2) {
            const n = n0[0];
            // If the result is not a number or is a whole number, then return it.
            node2 = n;
          } else {
            node2 = binaryNode(node.op, n0.reverse());
          }
          return node2;
          function unfold(op, expo, base) {
            const dontExpandPowers = option(options, "dontExpandPowers");
            const emv = mathValue(options, expo);
            if (op === Parser.POW) {
              if (dontExpandPowers && (base.op === Parser.VAR || base.op === Parser.NUM)) {
                return [expo, base];
              }
              if (base.op === Parser.POW && !(isNeg(options, base.args[1]) || isNeg(options, expo))) {
                // Flatten exponents unless base is a denom.
                expo = multiplyNode(base.args.slice(1).concat(expo));
                base = base.args[0];
                return [expo, base];
              }
              const ff = factors(options, base, null, false, true);
              if (ff.length === 0) {
                // No factors means we have a node with math value '1', so just
                // return it.
                return nodeOne;
              }
              var args = [];
              // Raise each factor to the expo power and then multiply them together.
              let hasMinusOne = false;
              ff.forEach(function (n) {
                if (expo.op === Parser.ADD) {
                  // If additive, then multiply base raised to each term.
                  // x^(y+z) -> x^y*x^z
                  expo.args.forEach(function (e) {
                    args.push(newNode(op, [n, e]));
                  });
                } else if (isInteger(emv)) {
                  // x^2 -> x*x
                  const ea = Math.abs(toNumber(emv));
                  let bmv;
                  if (isZero(emv)) {
                    args.push(nodeOne);
                  } else if (isNeg(options, (bmv = mathValue(options, n))) && !isNeg(options, emv)) {
                    // We have a factor that has an integer math value, so just do the math.
                    const mv = pow(bmv, emv);
                    args.push(numberNode(options, mv));
                  } else if ((ea < 5 || ea < 10 && !isPolynomial(n)) && !dontExpandPowers) {
                    // Expand if the base is additive, or exponent is an integer and
                    // dontExpandPowers is false. We limit the power of the expansion
                    // to avoid long running computations.
                    const invert = isNeg(options, emv);
                    for (let i = 0; i < ea; i++) {
                      if (invert) {
                        if (n.op === Parser.POW && isMinusOne(n.args[1])) {
                          // x^{-1}^{-1} -> x
                          args.push(n.args[0]);
                        } else if (isOne(n) && isMinusOne(emv)) {
                          // 1^{-1} -> 1
                          args.push(n);
                        } else if (isMinusOne(n) && isMinusOne(emv)) {
                          hasMinusOne = !hasMinusOne;
                        } else {
                          if (hasMinusOne) {
                            n = negate(n);
                            hasMinusOne = false;
                          }
                          args.push(binaryNode(Parser.POW, [n, nodeMinusOne]));
                        }
                      } else {
                        args.push(n);
                      }
                    }
                  } else if (isMinusOne(n) && isMinusOne(emv)) {
                    hasMinusOne = !hasMinusOne;
                  } else {
                    args.push(newNode(op, [n, expo]));
                  }
                } else {
                  args.push(newNode(op, [n, expo]));
                }
              });
              if (hasMinusOne) {
                if (args.length === 0) {
                  args.unshift(nodeMinusOne);
                } else {
                  args.unshift(negate(args.shift()));
                }
                hasMinusOne = false;
              }
            } else if (op === Parser.LOG) {
              var args = [];
              if (isMultiplicative(expo)) {
                // If log and multiplicative, then add log of each term.
                const aa = [];
                expo.args.forEach(function (e) {
                  if (e.op === Parser.POW) {
                    aa.push(multiplyNode([
                      e.args[1],
                      newNode(Parser.LOG, [base, e.args[0]])
                    ]));
                  } else {
                    aa.push(newNode(op, [base, e]));
                  }
                });
                args.push(addNode(aa));
              } else if (expo.op === Parser.POW) {
                // log x^y -> y log x
                args.push(multiplyNode([
                  expo.args[1],
                  newNode(Parser.LOG, [base, expo.args[0]])
                ]));
              } // Otherwise, do nothing.
            }
            // x^2, x^y
            if (args.length > 1) {
              return [multiplyNode(args)];
            } else if (args.length === 1) {
              return [args[0]];
            }
            return [expo, base];
          }
        },
        variable: function(node) {
          return node;
        },
        comma: function(node) {
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(expand(options, n));
          });
          return newNode(node.op, args);
        },
        equals: function(node) {
          // x/10+5=0 -> x+50=0
          // x/(y+1)+10=0 -> x+10(y+1) -> x+10y+10
          // x/y+2/z=0 -> xz+2y=0
          let args = [];
          node.args.forEach(function (n) {
            args = args.concat(expand(options, n));
          });
          // For each term, for each factor, if denom.
          return newNode(node.op, args);
        }
      }), root.location);
      // expandLevel--;
      // If the node has changed, simplify again.
      while (nid !== ast.intern(node)) {
        nid = ast.intern(node);
        // console.log("expand() nid=" + nid);
        node = expand(options, node);
      }
      node.expandNid = nid;
      expandedNodes[rootNid] = node;
      return node;
    }

    function factors(options, root, env, ignorePrimeFactors, preserveNeg, factorAdditive) {
      assert(root && root.args, "2000: Internal error.");
      return visit(options, root, {
        name: "factors",
        numeric: function (node) {
          if (ignorePrimeFactors || isInfinity(node)) {
            return [node];
          }
          const ff = [];
          let hasNeg = false;
          if (preserveNeg && isNeg(options, node)) {
            hasNeg = !hasNeg;
          }
          const absv = Math.abs(+node.args[0]);
          const pff = primeFactors(absv);
          if (pff.length === 0 && !isOne(absv)) {
            ff.push(numberNode(options, absv)); // e.g. 0.4
          } else {
            primeFactors(+node.args[0]).forEach(function (n) {
              ff.push(numberNode(options, n));
            });
          }
          if (hasNeg) {
            ff.unshift(nodeMinusOne);
          }
          return ff;
        },
        additive: function (node) {
          if (!factorAdditive) {
            // Actually, we have a repeating decimal. So no factors here.
            return [node];
          }
          node = factorQuadratic(node);
          if (node.op === Parser.MUL) {
            return [node];
          }
          const args = node.args.slice(0);  // Make a copy.
          let n0 = [multiplyNode(factors(options, args.shift(), {}, true, true))];
          // For each next value, pop last value and look for common factors with the next value.
          args.forEach(function (n1) {
            n1 = multiplyNode(factors(options, n1, {}, true, true));
            let n;
            if (commonFactors(options, (n = n0.pop()), n1).length > 0) {
              n0 = n0.concat(factorTerms(n, n1));
            } else {
              n0 = n0.concat([n, n1]);
            }
          });
          if (n0.length === 1 && n0[0].op === Parser.MUL) {
            return n0[0].args;
          }
          return [node];
        },
        multiplicative: function (node) {
          switch (node.op) {
          case Parser.MUL:
          case Parser.COEFF:
          case Parser.TIMES:
            var ff = [];
            node.args.forEach(function (n) {
              ff = ff.concat(factors(options, n, env, ignorePrimeFactors, preserveNeg));
            });
            return ff;
          default:
            assert(false, "2000: Node not normalized");
            break;
          }
          return [node];
        },
        unary: function(node) {
          return [node];
        },
        exponential: function (node) {
          if (option(options, "dontExpandPowers")) {
            return [node];
          }
          if (node.op === Parser.POW) {
            let isDenom;
            if (isNeg(options, mathValue(options, binaryNode(Parser.POW, node.args.slice(1)), true))) {
              // isNeg(options, ) doesn't handle powers so use mathValue(options, ) to help.
              isDenom = true;
            }
            const ff = [];
            const e = mathValue(options, node.args[1]);
            const ea = Math.abs(toNumber(e));
            if (ea < 5 || ea < 10 && !isPolynomial(node.args[0])) {
              // Limit complexity of polynomial expansion.
              const args = factors(options, node.args[0], {}, false, true, true);
              for (let j = 0; j < args.length; j++) {
                var f;
                if (isMinusOne(args[j])) {
                  f = nodeMinusOne;
                } else {
                  f = isDenom ? newNode(Parser.POW, [args[j], nodeMinusOne]) : args[j];
                }
                for (let i = ea; i > 0; i--) {
                  ff.push(f);
                }
              }
              return ff;
            } else {
              return [node];
            }
          } else if (node.op === Parser.LOG) {
            return [node];
          }
        },
        variable: function(node) {
          return [node];
        },
        comma: function(node) {
          return [node];
        },
        equals: function(node) {
          return [node];
        }
      });
    }

    function commonFactors(options, lnode, rnode) {
      const t1 = [lnode, rnode];
      let t;
      const t2 = [];
      // Factorise each term and intern its factors (giving each unqiue
      // sub-expression an id.
      t1.forEach(function (n) {
        t = factors(options, n, null, false, true);
        const ff = [];
        t.forEach(function (n) {
          ff.push(ast.intern(n));
        });
        t2.push(ff);
      });
      // Check to see if there are any common factors (ids).
      let intersect = t2.shift();
      t2.forEach(function (a) {
        intersect = intersect.filter(function (n) {
          const i = a.indexOf(n);
          if (i !== -1) {
            delete a[i];   // Erase matches.
            return true;
          }
          return false;
        });
      });
      return intersect;
    }

    function factorTerms(lnode, rnode) {
      // Eliminate the common factors from each term and sum the unique parts.
      const cfacts = commonFactors(options, lnode, rnode);
      const lfacts = factors(options, lnode, null, false, true);
      const rfacts = factors(options, rnode, null, false, true);
      const lfacts2 = [], rfacts2 = [];
      var cf = cfacts.slice(0);
      let i;
      lfacts.forEach(function (f) {
        if ((i = cf.indexOf(ast.intern(f))) === -1) {
          lfacts2.push(f);
        } else {
          delete cf[i];  // Erase the matched factor.
        }
      });
      var cf = cfacts.slice(0);
      rfacts.forEach(function (f) {
        if ((i = cf.indexOf(ast.intern(f))) === -1) {
          rfacts2.push(f);
        } else {
          delete cf[i];  // Erase the matched factor.
        }
      });
      let aa = [];
      aa = aa.concat(makeFactor(lfacts2));
      aa = aa.concat(makeFactor(rfacts2));
      const args = [];
      if (aa.length > 0) {
        args.push(makeTerm(aa));
      }
      cfacts.forEach(function (i) {
        args.push(ast.node(i));
      });
      const node = makeFactor(args);
      return node[0];
    }

    function makeFactor(args) {
      if (args.length === 0) {
        return [nodeOne];  // No factors, means times one.
      } else if (args.length === 1) {
        return args;
      }
      args = sortFactors(args);
      return [multiplyNode(args, true)];
    }

    function makeTerm(args) {
      assert(args.length > 0, "2000: Too few arguments in makeTerm()");
      if (args.length === 1) {
        return args[0];
      }
      return addNode(args);
    }

    function isHyperbolicTangent(node) {
      return node.op === Parser.MUL &&
        node.args.length > 1 &&
        node.args[0].op === Parser.SINH &&
        node.args[1].op === Parser.POW &&
        node.args[1].args[0].op === Parser.COSH &&
        isMinusOne(node.args[1].args[1]);
    }
    function isHyperbolicCotangent(node) {
      return node.op === Parser.MUL &&
        node.args.length > 1 &&
        node.args[0].op === Parser.COSH &&
        node.args[1].op === Parser.POW &&
        node.args[1].args[0].op === Parser.SINH &&
        isMinusOne(node.args[1].args[1]);
    }
    function isHyperbolicSecant(node) {
      return node.op === Parser.POW &&
        node.args.length > 1 &&
        node.args[0].op === Parser.COSH &&
        isMinusOne(node.args[1]);
    }
    function isHyperbolicCosecant(node) {
      return node.op === Parser.POW &&
        node.args.length > 1 &&
        node.args[0].op === Parser.SINH &&
        isMinusOne(node.args[1]);
    }

    // Scale the numbers in an expression.
    function scale(options, root) {
      assert(root && root.args, "2000: Internal error.");
      const node = Parser.create(options, visit(options, root, {
        name: "scale",
        exponential: function (node) {
          let mv, nd;
          if ((mv = mathValue(options, node, true)) &&
              (nd = numberNode(options, String(mv), true))) {
            return nd;
          }
          if (isHyperbolicSecant(node)) {
            // sech(x) = 1/cosh(x) = 2/(e^x+e^-x)
            var arg = node.args[0].args[0];
            var epx = binaryNode(Parser.POW, [nodeE, arg]);
            var emx = binaryNode(Parser.POW, [nodeE, negate(arg)]);
            var numer = nodeTwo;
            var denom = addNode([epx, emx]);
            node = fractionNode(numer, denom);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
          } else if (isHyperbolicCosecant(node)) {
            // csch(x) = 1/sinh(x) = 2/(e^x-e^-x)
            var arg = node.args[0].args[0];
            var epx = binaryNode(Parser.POW, [nodeE, arg]);
            var emx = binaryNode(Parser.POW, [nodeE, negate(arg)]);
            var numer = nodeTwo;
            var denom = addNode([epx, negate(emx)]);
            node = fractionNode(numer, denom);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
          }
          const args = [];
          node.args.forEach(function (n) {
            args.push(scale(options, n));
          });
          return newNode(node.op, args);
        },
        multiplicative: function (node) {
          let mv, nd;
          if ((mv = mathValue(options, node, true)) &&
              (nd = numberNode(options, String(mv), true))) {
            return nd;
          }
          if (isHyperbolicTangent(node)) {
            // tanh(x) = (e^x-e^-x)/(e^x+e^-x)
            var arg = node.args[0].args[0];
            var epx = binaryNode(Parser.POW, [nodeE, arg]);
            var emx = binaryNode(Parser.POW, [nodeE, negate(arg)]);
            var numer = addNode([epx, negate(emx)]);
            var denom = addNode([epx, emx]);
            node = fractionNode(numer, denom);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
            return node;
          } else if (isHyperbolicCotangent(node)) {
            // coth(x) = (e^x+e^-x)/(e^x-e^-x)
            var arg = node.args[0].args[0];
            var epx = binaryNode(Parser.POW, [nodeE, arg]);
            var emx = binaryNode(Parser.POW, [nodeE, negate(arg)]);
            var numer = addNode([epx, emx]);
            var denom = addNode([epx, negate(emx)]);
            node = fractionNode(numer, denom);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
            return node;
          }
          const args = [];
          let mv2;
          node.args.forEach(function (n) {
            if ((mv = mathValue(options, n, true))) {
              if (mv2 === undefined) {
                mv2 = mv;
              } else {
                mv2 = mv2.times(mv);
              }
            } else if (isSyntheticEmptyNode(n)) {
              // Erase.
            } else {
              args.push(scale(options, n));
            }
          });
          let n;
          if (!isOne((n = numberNode(options, mv2, true)))) {
            args.unshift(n);
          }
          node = multiplyNode(args);
          if ((mv = mathValue(options, node, true)) &&
              (nd = numberNode(options, String(mv), true))) {
            return nd;
          }
          return node;
        },
        additive: function (node) {
          let mv, nd;
          if ((mv = mathValue(options, node, true)) &&
              (nd = numberNode(options, String(mv), true))) {
            return nd;
          }
          const args = [];
          let mv2 = bigZero;
          node.args.forEach(function (n) {
            if ((mv = mathValue(options, addNode([numberNode(options, mv2), n]), true))) {
              // Accumulate a constant term.
              mv2 = mv;
            } else {
              args.push(scale(options, n));
            }
          });
          if (!isZero(mv2)) {
            args.unshift(numberNode(options, mv2, true));
          }
          if (args.length === 1) {
            node = args[0];
          } else {
            node = addNode(args);
          }
          if ((mv = mathValue(options, node, true)) &&
              (nd = numberNode(options, String(mv), true))) {
            return nd;
          }
          return node;
        },
        unary: function(node) {
          let mv;
          if ((mv = mathValue(options, node, true))) {
            return numberNode(options, mv, true);
          }
          const args = [];
          node.args.forEach(function (n) {
            args.push(scale(options, n));
          });
          switch (node.op) {
          case Parser.SINH:
            var arg = args[0];
            node = addNode([
              fractionNode(binaryNode(Parser.POW, [
                nodeE,
                arg]), nodeTwo),
              fractionNode(negate(binaryNode(Parser.POW, [
                nodeE,
                negate(arg)])), nodeTwo)
            ]);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
            break;
          case Parser.COSH:
            var arg = args[0];
            node = addNode([
                fractionNode(binaryNode(Parser.POW, [
                  nodeE,
                  arg]), nodeTwo),
                fractionNode(binaryNode(Parser.POW, [
                  nodeE,
                  negate(arg)]), nodeTwo),
              ]);
            node = scale(options, expand(options, normalize(options, simplify(options, expand(options, normalize(options, node))))));
            break;
          default:
            node = newNode(node.op, args);
            break;
          }
          return node;
        },
        numeric: function(node) {
          if (isUndefined(node)) {
            return node;
          }
          return numberNode(options, node.args[0], true);
        },
        variable: function(node) {
          let val;
          if ((val = Parser.env[node.args[0]])) {
            if (val.type === "unit") {
              if (val.base === "\\radian") {
                // Strip radian units.
                node = numberNode(options, val.value);
              } else if (val.value !== 1) {
                // If value is not one, then convert to base units.
                node = multiplyNode([numberNode(options, val.value, true), variableNode(val.base)]);
              }
            } else if (val.type === "const") {
              node = numberNode(options, val.value, true);
            }
          }
          return node;  // Nothing to do here.
        },
        comma: function(node) {
          const args = [];
          node.args.forEach(function (n) {
            args.push(scale(options, n));
          });
          return newNode(node.op, args);
        },
        equals: function(node) {
          var args = [];
          // If equality and LHS leading coefficient is negative, then multiply by -1
          let cc;
          if ((node.op === Parser.EQL || node.op === Parser.APPROX) &&
              ((cc = isPolynomial(node.args[0])) && cc[cc.length - 1] < 0 ||
               !cc && sign(node.args[0]) < 0)) {
            node.args[0] = simplify(options, expand(options, negate(node.args[0])));
          }
          if (isComparison(node.op)) {
            var lc, args = [];
            const lnode = node.args[0];
            if (isPolynomial(lnode) && isAdditive(lnode) && !isOne(abs(leadingCoeff(lnode)))) {
              // Normalize leading coefficient to one. Skip if already 1 or -1.
              lnode.args.forEach(function (n, i) {
                if (i === 0) {
                  lc = constantPart(n);
                  const vp = variablePart(n);
                  if (vp) {
                    args.push(vp);
                  }
                } else {
                  assert(lc, "2000: Internal error.");
                  args.push(fractionNode(n, lc));
                }
              });
              // This is a bit of a hack, making a unary additive node to continue
              // in this block.
              node.args[0] = newNode(Parser.ADD, [multiplyNode([lc, addNode(args)])]);
            }
          }
          args = [];
          node.args.forEach(function (n) {
            args.push(scale(options, n));
          });
          return newNode(node.op, args);
        }
      }), root.location);
      return node;
    }

    const primes = [
      2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67,
      71, 73, 79, 83, 89, 97
    ];

    // Table of values and their primality.
    const primesCache = {};
    primes.forEach(function (v) {
      primesCache[v] = true;
    });

    function solveQuadratic(options, a, b, c) {
      a = toNumber(a);  // FIXME do math in BD
      b = toNumber(b);
      c = toNumber(c);
      const x0 = (-b + Math.sqrt(b * b - 4 * a * c)) / (2 * a);
      const x1 = (-b - Math.sqrt(b * b - 4 * a * c)) / (2 * a);
      const opt = option(options, "field");
      const hasSolution =
        opt === "integer" && ((x0 === (x0 | 0)) && (x1 === (x1 | 0))) ||
        opt === "real" && (b * b - 4 * a * c) >= 0 ||
        opt === "complex"; // Redundant, but okay.
      if (hasSolution) {
        return [x0, x1]; //[new Decimal(x0.toString()), new Decimal(x1.toString())];
      }
      return null;
    }
    function primeFactors(n) {  // n : Number
      const absN = Math.abs(n);
      if (absN <= 1 || isNaN(n) || isInfinity(n) || isImaginary(n)) {
        return [];
      } else if (isPrime(absN)) {
        return [absN];
      }
      const maxf = Math.sqrt(absN);
      for (let f = 2; f <= maxf; f++) {
        if (n % f === 0) {
          return primeFactors(f).concat(primeFactors(absN / f));
        }
      }
    }
    function isPrime(n) {
      if (primesCache[n] !== void 0) {
        return primesCache[n];
      }
      if (n <= 1) {
        primesCache[n] = false;
        return false;
      } else {
        if (n <= 1 || n > 2 && n % 2 === 0) {
          return primesCache[n] = false;
        } else {
          for (let i = 3, sqrt = Math.sqrt(n); i <= sqrt; i += 2) {
            if (n % i === 0) {
              return primesCache[n] = false;
            }
          }
        }
        return primesCache[n] = true;
      }
    }

    function gcd(a, b) {
      if (arguments.length > 2) {
        const rest = [].slice.call(arguments, 1);
        return gcd(a, gcd.apply(rest));
      } else {
        let mod;
        a = Math.abs(a);
        b = Math.abs(b);
        while (b) {
          mod = a % b;
          a = b;
          b = mod;
        }
        return a;
      }
    }

    // Visitor exports
    this.normalize = normalize;
    this.normalizeSympy = normalizeSympy;
    this.normalizeExpanded = normalizeExpanded;
    this.normalizeLiteral = normalizeLiteral;
    this.normalizeSyntax = normalizeSyntax;
    this.normalizeCalculate = normalizeCalculate;
    this.degree = degree;
    this.constantPart = constantPart;
    this.variables = variables;
    this.variablePart = variablePart;
    this.sort = sort;
    this.sortLiteral = sortLiteral;
    this.simplify = simplify;
    this.formatMath = formatMath;
    this.expand = expand;
    this.terms = terms;
    this.subexprs = subexprs;
    this.factors = factors;
    this.mathValue = mathValue;
    this.units = units;
    this.scale = scale;
    this.hasLikeFactors = hasLikeFactors;
    this.hasLikeFactorsOrTerms = hasLikeFactorsOrTerms;
    this.factorGroupingKey = factorGroupingKey;
    this.hint = hint;
    this.crossMultiply = crossMultiply;
    this.isNumeric = isNumeric;
  }

  function degree(options, node, notAbsolute) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    return visitor.degree(node, notAbsolute);
  }

  function constantPart(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    return visitor.constantPart(node);
  }

  function variables(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    return visitor.variables(node);
  }

  function hint(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    return visitor.hint(node);
  }

  function variablePart(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    return visitor.variablePart(node);
  }

  function sortLiteral(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.sortLiteral(node);
    Assert.setLocation(prevLocation);
    return result;
  }

  function normalize(options, node) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.normalize(options, node);
    Assert.setLocation(prevLocation);
    return result;
  }
  function normalizeSympy(options, node) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    Parser.flags = {};
    node = visitor.normalizeSympy(options, node);
    Assert.setLocation(prevLocation);
    return node;
  }

  function normalizeLiteral(options, node) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.normalizeLiteral(options, node);
    Assert.setLocation(prevLocation);
    return result;
  }

  function normalizeSyntax(options, node, ref) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.normalizeSyntax(options, node, ref);
    Assert.setLocation(prevLocation);
    return result;
  }

  function normalizeExpanded(options, node) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.normalizeExpanded(node);
    Assert.setLocation(prevLocation);
    return result;
  }

  function normalizeCalculate(options, node) {
    const visitor = new Visitor(options.ast || ast);
    const result = visitor.normalizeCalculate(options, node);
    return result;
  }

  function mathValue(options, node, env, allowDecimal, normalizeUnits) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.mathValue(options, node, env, allowDecimal, normalizeUnits);
    Assert.setLocation(prevLocation);
    return result;
  }

  function units(options, node, env) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.units(node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function formatMath(options, n1, n2, env) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (n2.location) {
      Assert.setLocation(n2.location);
    }
    const result = visitor.formatMath(options, n1, n2, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function simplify(options, node, env) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.simplify(options, node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function hasLikeFactors(options, node, env) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.hasLikeFactors(node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function hasLikeFactorsOrTerms(options, node, env) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.hasLikeFactorsOrTerms(node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function expand(options, node, env) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.expand(options, node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function terms(options, node, env) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.terms(node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function subexprs(options, node, env) {
    assert(node && node.op);
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.subexprs(node, env);
    Assert.setLocation(prevLocation);
    return result;
  }

  function factors(options, node, env, ignorePrimeFactors, preserveNeg, factorAdditive) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.factors(options, node, env, ignorePrimeFactors, preserveNeg, factorAdditive);
    Assert.setLocation(prevLocation);
    return result;
  }

  function scale(options, node) {
    const visitor = new Visitor(options.ast || ast);
    const prevLocation = Assert.location;
    if (node.location) {
      Assert.setLocation(node.location);
    }
    const result = visitor.scale(options, node);
    Assert.setLocation(prevLocation);
    return result;
  }

  function crossMultiply(options, n1, n2) {
    const visitor = new Visitor(options.ast || ast);
    return visitor.crossMultiply(options, n1, n2);
  }

  function isNumeric(n1) {
    const visitor = new Visitor(options.ast || ast);
    return visitor.isNumeric(n1);
  }

  var env = Parser.env;

  function stripTrailingZeros(n) {
    if (n.op !== Parser.NUM) {
      const mv = mathValue(options, n, true);
      if (!mv) {
        return n;
      }
      n = newNode(Parser.NUM, [String(mv)]);
    }
    let decimalPoint;
    let s = n.args[0];
    for (var i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i);
      if (c === 46) {
        decimalPoint = i;
      } else if ((c < 48 || c > 57) && c !== 45) {
        return n;
      }
    }
    if (decimalPoint !== undefined) {
      for (var i = s.length - 1; i > decimalPoint; i--) {
        if (s.charCodeAt(i) === 48) {
          s = s.substring(0, i);
        } else {
          break;
        }
      }
      if (s.charCodeAt(s.length - 1) === 46) {
        s = s.substring(0, s.length - 1);
      }
    }
    return s;
  }

  // Check if two equations have the same math value. Two equations have the
  // same math value if and only if have the same numeric value factoring in
  // units, if any.
  // Need to convert units.

  function distributeUnits(n1, n2) {
    const n1units = units(options, n1);
    const n2units = units(options, n2);
    assert(n1units.length < 2, message(2004));
    assert(n2units.length < 2, message(2004));
    const n1unit = n1units[0];
    const n2unit = n2units[0];
    // Distribute unit. Maybe undefined.
    let n1new, n2new;
    if (n1unit === undefined && n2unit !== undefined) {
      n1new = multiplyNode([n1, variableNode(n2unit.args[0])]);
      n2new = n2;
    } else if (n2unit === undefined && n1unit !== undefined) {
      n1new = n1;
      n2new = multiplyNode([n2, variableNode(n1unit.args[0])]);
    } else {
      n1new = n1;
      n2new = n2;
    }
    return [n1new, n2new];
  }

  Parser.fn.equivSyntax = function (n1, n2, options) {
    assert(options);
    options = options || {};
    reset();
    const inverseResult = option(options, "inverseResult");
    let result = false;
    if (!(n1 instanceof Array)) {
      n1 = [n1];
    }
    result = n1.some(function (n) {
      var n1n = normalizeSyntax(options, n, n);
      const n2n = normalizeSyntax(options, n2, n);
      return ast.intern(n1n) === ast.intern(n2n);
    });
    return inverseResult ? !result : result;
  };

  // Check if two equations are literally equivalent. Two equations are
  // literally equivalent if and only if they have the same AST. ASTs with the
  // same structure intern to the same pool index.
  Parser.fn.equivLiteral = function equivLiteral(n1, n2, options) {
    // delete n1.env;
    // console.log("[1] equivLiteral() n1=" + JSON.stringify(n1, null, 2));
    // console.log("[1] equivLiteral() n2=" + JSON.stringify(n2, null, 2));
    Parser.option(options, "ignoreOrder", true);
    const inverseResult = option(options, "inverseResult");
    if (!option(options, "strict")) {
      n1 = normalizeLiteral(options, n1);
      n2 = normalizeLiteral(options, n2);
      // console.log("[2] equivLiteral() n1=" + JSON.stringify(n1, null, 2));
      // console.log("[2] equivLiteral() n2=" + JSON.stringify(n2, null, 2));
      if (option(options, "ignoreOrder")) {
        n1 = sortLiteral(options, n1);
        n2 = sortLiteral(options, n2);
      }
    }
    const nid1 = ast.intern(n1);
    const nid2 = ast.intern(n2);
    // console.log("[3] equivLiteral() nid1=" + nid1 + " n1=" + JSON.stringify(n1, null, 2));
    // console.log("[3] equivLiteral() nid2=" + nid2 + " n2=" + JSON.stringify(n2, null, 2));
    const result = inverseResult ? !(nid1 === nid2) : nid1 === nid2;
    // console.log("[4] equivLiteral() inverseResult=" + inverseResult + " result=" + result);
    return result;
  };

  Parser.fn.evalSympy = function (n1, options, resume) {
    delete n1.env;
    n1 = normalizeSympy(options, n1);
    n1 = markSympy(options, n1);
    return evalSympy(n1, options, resume);
  };

  // Check if two equations are mathematically equivalent. Two equations are
  // mathematically equivalent if they are literally equal after simplification
  // and normalization.
  Parser.fn.equivSymbolic = function equivSymbolic(n1, n2, options, resume) {
    // console.log("[1] equivSymbolic() n1=" + JSON.stringify(n1, null, 2));
    // console.log("[1] equivSymbolic() n2=" + JSON.stringify(n2, null, 2));
    assert(options);
    const n1o = n1;
    let n2o = n2;
    n1 = JSON.parse(JSON.stringify(n1));  // Poor man's copy.
    n2 = JSON.parse(JSON.stringify(n2));
    const inverseResult = option(options, "inverseResult");
    const antiderivative = option(options, "antiderivative");
    const result = Parser.fn.equivLiteral(n1, n2, options);
    if (result && !inverseResult) {
      // Got a match with equivLiteral. We're done.
      resume([], true);
      return;
    }
    n1 = normalizeSympy(options, n1o);
    n2 = normalizeSympy(options, n2o);
    option(options, "allowThousandsSeparator", undefined);  // Clear parsing related settings to avoid syntax errors after SymPy.
    option(options, "setThousandsSeparator", undefined);
    option(options, "setDecimalSeparator", undefined);
    let hasAbs;
    if (n1.flags.hasAbs || n2.flags.hasAbs) {
      hasAbs = true;
    }
    if (antiderivative) {
      option(options, "absoluteValue", !n1.flags.hasAbs || n2.flags.hasAbs);
      option(options, "integrationConstant", n2.flags.hasPlusC);
      // integrand, variable
      n1 = newNode(Parser.COMMA, [n1, newNode(Parser.VAR, [antiderivative])]);
      n2 = newNode(Parser.COMMA, [n2, newNode(Parser.VAR, [antiderivative])]);
      n1.flags = {"isAntideriv": true};
      n2.flags = {"isAntideriv": true};
    } else if ((n1.flags.isAlgebraic && (n2.flags.isAlgebraic || n2.flags.isNumeric)) ||
               (n2.flags.isAlgebraic && (n1.flags.isAlgebraic || n1.flags.isNumeric))) {
      // Cross multiply.
      const nn = crossMultiply(options, n1, n2);
      n1 = nn[0];
      n2 = nn[1];
    }
    let node;
    if (n1.flags.hasUnit || n2.flags.hasUnit) {
      node = newNode(Parser.OPERATORNAME, [variableNode("UNIT"), newNode(Parser.COMMA, [n1, n2])]);
    } else {
      n1 = markSympy(options, n1);
      n2 = markSympy(options, n2);
      node = newNode(Parser.PAREN, [newNode(Parser.COMMA, [n1, n2])]);
    }
    if (hasAbs) {
      node.hasAbs = true;
    }
    node.lbrk = 40;
    node.rbrk = 41;
    evalSympy(node, options, function (err, val) {
      if (err && err.length) {
        resume(err);
      } else {
        const n = val;
        let result;
        assert(n && n.op && n.args && n.args.length);
        if (n.op === Parser.PAREN && n.args[0].op === Parser.COMMA ||
            n.op === Parser.INTERVALOPEN && n.args[0].op === Parser.COMMA) {
          let n1 = n.args[0].args[0];
          let n2 = n.args[0].args[1];
          // remove the [..] wrapping \operatorname{COMMA} nodes
          n1 = (n1.op === Parser.BRACKET || n1.op === Parser.INTERVAL) && n1.args[0] || n1;
          n2 = (n2.op === Parser.BRACKET || n2.op === Parser.INTERVAL) && n2.args[0] || n2;
          n2 = tolerance(options, n1, n2);
          // console.log("[2] equivSymbolic() n1=" + JSON.stringify(n1, null, 2));
          // console.log("[2] equivSymbolic() n2=" + JSON.stringify(n2, null, 2));
          result = Parser.fn.equivLiteral(n1, n2, options);
          if (antiderivative) {
            const absoluteValue = option(options, "absoluteValue");
            const integrationConstant = option(options, "integrationConstant");
            if (inverseResult) {
              result = result || !absoluteValue || !integrationConstant;
            } else {
              result = result && absoluteValue && integrationConstant;
            }
          }
        } else {
          n2o = tolerance(options, n1o, n2o);
          result = Parser.fn.equivLiteral(n1o, n2o, options);
        }
        resume(err, result);
      }
    });
    function tolerance(options, n1, n2) {
      if (n1.op === Parser.INTERVALOPEN && n2.op === Parser.INTERVALOPEN) {
        // Apply tolerance to the magnitude when node is (magnitude, units)
        return newNode(n2.op, [
          newNode(Parser.COMMA, [
            tolerance(options, n1.args[0].args[0], n2.args[0].args[0]),
            n2.args[0].args[1]
          ])
        ]);
      } else if (isNumeric(n1) && isNumeric(n2) && !isInfinity(n2)) {
        const toleranceAbsolute = option(options, "toleranceAbsolute");
        const tolerancePercent = option(options, "tolerancePercent");
        const toleranceRange = option(options, "toleranceRange");
        if (toleranceAbsolute || tolerancePercent) {
          assert(!isInfinity(n1), message(2018));
          let error = abs(toDecimal(n1).minus(toDecimal(n2)));
          let margin;
          if (toleranceAbsolute) {
            margin = typeof(toleranceAbsolute) === "string" ?
                     toDecimal(Parser.create(options, toleranceAbsolute)) :
                     toDecimal(toleranceAbsolute);
          } else {
            error = error.div(abs(toDecimal(n1)));
            margin = toDecimal(tolerancePercent).mul(0.01);
          }
          if (error.lte(margin)) {
            return n1;
          }
        } else if (toleranceRange) {
          const lowerLimit =
                typeof toleranceRange[0] === "string" ?
                toDecimal(Parser.create(options, toleranceRange[0])) :
                toleranceRange[0];
          const upperLimit =
                typeof toleranceRange[1] === "string" ?
                toDecimal(Parser.create(options, toleranceRange[1])) :
                toleranceRange[1];
          assert(+lowerLimit < +upperLimit, message(2019));
          assert(!isInfinity(n1) &&
                 toDecimal(n1).gte(lowerLimit) &&
                 toDecimal(n1).lte(upperLimit), message(2020, [n1.args[0]]));
          if (toDecimal(n2).gte(lowerLimit) && toDecimal(n2).lte(upperLimit)) {
            return n1;
          }
        }
      }
      return n2;
    }
  };
  function markSympy(options, node) {
    if (node.flags.isAntideriv) {
      node = newNode(Parser.OPERATORNAME, [variableNode("ANTIDERIV"), node]);
    } else if (node.flags.hasCalculus) {
      node = newNode(Parser.OPERATORNAME, [variableNode("CALC"), node]);
    } else if (node.flags.hasColon) {
      node = newNode(Parser.OPERATORNAME, [variableNode("RATIO"), node]);
    } else if (node.flags.hasRel) {
      node = newNode(Parser.OPERATORNAME, [variableNode("REL"), node]);
    } else if (node.flags.hasVector) {
      node = newNode(Parser.OPERATORNAME, [variableNode("VECTOR"), node]);
    } else if (node.flags.hasMatrix) {
      node = newNode(Parser.OPERATORNAME, [variableNode("MATRIX"), node]);
    } else if (node.flags.hasComma) {
      node = newNode(Parser.OPERATORNAME, [variableNode("COMMA"), node]);
    } else if (node.flags.hasPlusMinus) {
      node = newNode(Parser.OPERATORNAME, [variableNode("PLUSMINUS"), node]);
    } else if (node.flags.isNumeric) {
      node = newNode(Parser.OPERATORNAME, [variableNode("NUM"), node]);
    } else if (node.flags.hasTrig) {
      node = newNode(Parser.OPERATORNAME, [variableNode("TRIG"), node]);
    } else if (node.flags.hasHyperTrig) {
      node = newNode(Parser.OPERATORNAME, [variableNode("HYPER"), node]);
    } else if (node.flags.hasPower) {
      node = newNode(Parser.OPERATORNAME, [variableNode("POWER"), node]);
    } else if (node.flags.hasLog) {
      node = newNode(Parser.OPERATORNAME, [variableNode("LOG"), node]);
    } else if (node.flags.isAlgebraic) {
      node = newNode(Parser.OPERATORNAME, [variableNode("DEFAULT"), node]);
    }
    return node;
  }
  const config =
        typeof process !== 'undefined' &&
        typeof fs !== 'undefined' &&
        typeof fs.readFileSync === 'function' &&
        JSON.parse(fs.readFileSync(process.env.ARTCOMPILER_CONFIG || 'config.json', 'utf8')) ||
        {};
  function getSympy(data, resume) {
    const encodedData = JSON.stringify(data);
    const options = {
      method: "GET",
      host: (
        config.useLocalSymPy && "localhost" ||
          config.sympyHost ||
          "e2r3izczp3.execute-api.us-east-2.amazonaws.com"
      ),
      port: (
        config.useLocalSymPy && "8000" ||
          config.sympyPort ||
          "443"
      ),
      path: (
        config.sympyPath ||
          "/sympy-service"
      ),
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': encodedData.length
      },
    };
    const protocol = config.sympyProtocol === "http" && http || https;
    const req = protocol.request(options, function(res) {
      let data = "";
      res.on('data', function (chunk) {
        data += chunk;
      }).on('end', function () {
        try {
          let val;
          try {
            val = JSON.parse(data);
          } catch (x) {
            val = "";
          }
          const error = val.error || "Bad sympy: " + encodedData;
          if (res.statusCode === 200) {
            resume(null, {
              data: val
            });
          } else {
            resume([{
              statusCode: res.statusCode,
              error: error,
            }]);
          }
        } catch (x) {
          console.trace(x);
          resume(x.message);
        }
      }).on("error", function () {
        console.log("getSympy() ERROR statusCode=" + res.statusCode + " data=" + data);
        resume([{
          error: data,
        }]);
      });
    });
    req.write(encodedData);
    req.end();
    req.on('error', function(e) {
      console.log("ERROR getSympy(): " + e);
      resume([{
        error: e,
      }], []);
    });
  }
  function evalSympy(expr, options, resume) {
    let errs = [];
    let syms = variables(options, expr);
    const symNode = Parser.create(options, String(syms));
    let assumption;
    if (expr.hasAbs || config.langID === 122) {
      assumption = "real";
    } else {
      assumption = "positive";
    }
    texToSympy(options, symNode, function (err, val) {
      syms = val && val.split(",") || [];
      if (syms.includes("I")) {
        syms.push("i");
      }
      let index;
      const excludes = ["E", "pi", "I", "EmptySet", "degree"];
      excludes.forEach(function (sym) {
        if ((index = syms.indexOf(sym)) >= 0) {
          syms = (function(syms) {
            const rest = syms.slice(index + 1);
            syms.length = index;
            return syms.concat(rest);
          })(syms);
        }
      });
      let params = "";
      let symbols = "";
      if (syms && syms.length) {
        // Construct a list of parameters and symbols.
        syms.forEach(function (s) {
          if (symbols) {
            params += ",";
            symbols += ",";
          }
          params += s;
          if (s === "_dollar") {
            s = "\\$";
          }
          symbols += "symbols('" + s + "'," + assumption + "=True)";
        });
        params = " " + params;
      }
      let opts = "";
      Object.keys(options).forEach(function (k) {
        switch (k) {
        case "variable":
        case "precision":
          opts += "," + options[k];
          break;
        case "domain":
          opts += "," + k + "=" + options[k];
          break;
        default:
          break;
        }
      });
      // console.log("evalSympy() expr=" + JSON.stringify(expr, null, 2));
      texToSympy(options, expr, function (err, v) {
        // TRIG sin ( TRIG cos (x) + 2)
        if (err && err.length) {
          console.log("[1] ERROR evalSympy() err=" + JSON.stringify(err));
          errs = errs.concat(err);
          resume(errs, null);
        } else {
          let args, obj;
          if (+config.langID === 122) {
            args = v + opts; // where v is of the form '(alternates); seed'
            const args1 = args.split(';'); // where v is of the form '(alternates); seed'
            obj = {
              func: "eval",
              // compute the alternates using the result from evaluating the seed
              expr: "(lambda val:" + args1[0] + ")" +
                "((lambda" + params + ":" + args1[1] + ")(" + symbols + "))",
              timeout: config.sympyTimeout || 30,
            };
          } else if (+config.langID === 107) {
            args = v + opts;
            obj = {
              func: "eval",
              expr: "(lambda" + params + ":" + " " + args + ")(" + symbols + ")",
              timeout: config.sympyTimeout || 30,
            };
          } else {
            resume(`Invalid config value for 'langID': ${config.langID}`);
            return;
          }
          // console.log("evalSympy() obj.expr=" + obj.expr);
          getSympy(obj, function (err, data) {
            // console.log("evalSympy() err=" + JSON.stringify(err) + " data=" + JSON.stringify(data));
            if (err && err.length) {
              console.log("[2] ERROR evalSympy() err=" + JSON.stringify(err));
              resume(err);
            } else {
              if (+config.langID === 122) {
                const type =
                    expr.op === Parser.OPERATORNAME &&
                    expr.args[0].op === Parser.VAR &&
                    expr.args[0].args[0];
                resume([], {
                  src: args,
                  out: data,
                  type: type,
                });
              } else if (+config.langID === 107) {
                const node = Parser.create(options, data.data);
                resume(errs, node);
              }
            }
          });
        }
      });
    });
  }

  function isAggregate(node) {
    if (node.op === Parser.COMMA ||
        node.op === Parser.LIST ||
        node.op === Parser.MATRIX ||
        node.op === Parser.VEC ||
        node.op === Parser.ANGLEBRACKET ||
        node.op === Parser.INTERVAL ||
        node.op === Parser.INTERVALOPEN ||
        node.op === Parser.INTERVALLEFTOPEN ||
        node.op === Parser.INTERVALRIGHTOPEN) {
      return true;
    } else if (node.op === Parser.NUM ||
               node.op === Parser.VAR) {
      return false;
    }
    return node.args.some(function (n) {
      return isAggregate(n);
    });
  }

  function isComparison(op) {
    return op === Parser.LT ||
      op === Parser.LE ||
      op === Parser.GT ||
      op === Parser.GE ||
      op === Parser.NE ||
      op === Parser.NGTR ||
      op === Parser.NLESS ||
      op === Parser.APPROX ||
      op === Parser.EQL;
  }

  function isInequality(op) {
    return op === Parser.LT ||
      op === Parser.LE ||
      op === Parser.GT ||
      op === Parser.GE ||
      op === Parser.NE ||
      op === Parser.NGTR ||
      op === Parser.NLESS;
  }

  Parser.fn.format = function (n1, n2, options) {
    const node = formatMath(options, n2, n1);
    return ast.toLaTeX(node);
  };

  Parser.fn.calculate = function (n1, options) {
    const prevLocation = Assert.location;
    if (n1.location) {
      Assert.setLocation(n1.location);
    }
    n1 = normalize(options, n1);
    let node;
    if (mathValue(options, n1, true, true)) {
      node = scale(options, n1);
    } else {
      const decimalPlaces = Parser.option(options, "decimalPlaces", 20);
      node = normalizeCalculate(options, scale(options, expand(options, normalize(options, simplify(options, expand(options, n1))))));
      Parser.option(options, "decimalPlaces", decimalPlaces);
      node = scale(options, node);
    }
    const result = stripTrailingZeros(scale(options, numberNode(options, mathValue(options, node, Parser.env, true, true))));
    Assert.setLocation(prevLocation);
    return result;
  };

  Parser.fn.simplify = function (n1, options) {
    const prevLocation = Assert.location;
    if (n1.location) {
      Assert.setLocation(n1.location);
    }
    let result = ast.toLaTeX(simplify(options, expand(options, normalize(options, n1))));
    result = typeof result === "string" ? result : "ERROR";
    Assert.setLocation(prevLocation);
    return result;
  };

  Parser.fn.expand = function (n1, options) {
    const prevLocation = Assert.location;
    if (n1.location) {
      Assert.setLocation(n1.location);
    }
    let result = ast.toLaTeX(normalizeExpanded(normalize(options, expand(options, normalize(options, n1)))));
    result = typeof result === "string" ? result : "ERROR";
    Assert.setLocation(prevLocation);
    return result;
  };

  Parser.fn.isExpanded = function isExpanded(node, options) {
    let inverseResult = option(options, "inverseResult");
    let n1, n2, nid1, nid2, result;
    let doingSimplified = option(options, "doingSimplified", true);
    if (node.op === Parser.COMMA) {
      result = node.args.every(function (n) {
        return isExpanded(n, options);
      });
    } else if (isComparison(node.op)) {
      inverseResult = option(options, "inverseResult", false);
      result = isExpanded(node.args[0], options) && isExpanded(node.args[1], options);
      option(options, "inverseResult", inverseResult);
    } else if (isAdditive(node)) {
      node = flattenNestedNodes(normalize(options, node));
      inverseResult = option(options, "inverseResult", false);
      result = node.args.every(function (n) {
        return isExpanded(n, options);
      }) && !hasLikeFactorsOrTerms(options, normalize(options, node));
    } else {
      const dontExpandPowers = option(options, "dontExpandPowers", false);
      const dontFactorDenominators = option(options, "dontFactorDenominators", true);
      const dontFactorTerms = option(options, "dontFactorTerms", true);
      doingSimplified = option(options, "doingSimplified", true);
      const dontSimplifyImaginary = option(options, "dontSimplifyImaginary", true);
      node = flattenNestedNodes(normalize(options, node));
      n1 = node;
      n2 = normalizeExpanded(options, normalize(options, expand(options, normalize(options, node))));
      nid1 = ast.intern(n1);
      nid2 = ast.intern(n2);
      option(options, "dontExpandPowers", dontExpandPowers);
      option(options, "dontFactorDenominators", dontFactorDenominators);
      option(options, "dontFactorTerms", dontFactorTerms);
      option(options, "doingSimplified", doingSimplified);
      option(options, "dontSimplifyImaginary", dontSimplifyImaginary);
      if (nid1 === nid2 &&
          !(hasLikeFactorsOrTerms(options, n1) ||
            node.op === Parser.POW &&
            isAdditive(node.args[0]) &&
            isPolynomial(node))) {
        // isExpanded because it doesn't have like factors or terms and it
        // isn't an unexpanded polynomial.
        result = true;
      } else {
        result = false;
      }
    }
    option(options, "doingSimplified", doingSimplified);
    return inverseResult ? !result : result;
  };

  function hasDenominator(node) {
    // Node has a denominator.
    const tt = terms(options, node);
    const result = tt.some(function (t) {
      // Some term of node has a denominator.
      if (variablePart(options, t)) {
        const ff = factors(options, t);
        return ff.some(function (f) {
          // Has factor of some term of node has a denominator.
          return f.op === Parser.POW && isNeg(options, f.args[1]);
        });
      } else {
        // No variable part then its a coefficient, so don't check.
        return false;
      }
    });
    return result;
  }

  function equivLiteralIgnoreOrder(options, n1, n2) {
    const ignoreOrder = Parser.option(options, "ignoreOrder", true);
    const result = Parser.fn.equivLiteral(n1, n2, options);
    Parser.option(options, "ignoreOrder", ignoreOrder);
    return result;
  }

  Parser.fn.isSimplified = function isSimplified(node, options) {
    let n1, n2, nid1, nid2, result;
    const dontFactorDenominators = option(options, "dontFactorDenominators", true);
    const dontFactorTerms = option(options, "dontFactorTerms", true);
    const doingSimplified = option(options, "doingSimplified", true);
    const dontSimplifyImaginary = option(options, "dontSimplifyImaginary", true);
    let inverseResult = option(options, "inverseResult");
    if (node.op === Parser.COMMA) {
      result = node.args.every(function (n) {
        return isSimplified(n, options);
      });
    } else if (isComparison(node.op) && !isZero(node.args[0]) && !isZero(node.args[1])) {
      n1 = normalize(options, addNode([node.args[0], node.args[1]]));
      result = true;
      inverseResult = option(options, "inverseResult", false);
      if (!isSimplified(n1, options)) {
        // Check for like terms on both sides.
        result = false;
      }
      option(options, "inverseResult", inverseResult);
      if (result && hasDenominator(n1)) {
        // Check for division or fraction.
        result = false;
      }
      if (result && !isFactorised(options, n1)) {
        result = false;
      }
    } else {
      node = normalize(options, node);
      let vp;
      if (isNeg(options, node) &&
          (!(vp = variablePart(options, node)) || vp.op !== Parser.ADD)) {
        // If is negative and is a simple expression, then erase negative.
        const isMixedNumber = node.isMixedNumber;
        node = negate(node);
        node.isMixedNumber = isMixedNumber;
      }
      n1 = node;
      n2 = normalize(options, simplify(options, expand(options, node)));
      nid1 = ast.intern(n1);
      nid2 = ast.intern(n2);
      option(options, "inverseResult", false);  // Clear in case we call isSimplified() recursively.
      option(options, "ignoreOrder", true);
      result = nid1 === nid2 ||
        !(subexprs(options, n2).length < subexprs(options, n1).length) &&
        ((!isNumeric(node) && (isAdditive(node) || isMultiplicative(node)) &&
          (!hasLikeFactors(options, node) && isFactorised(options, node) ||
           !hasLikeFactorsOrTerms(options, node) && isExpanded(options, node))) ||
         node.op === Parser.POW &&
         ast.intern(squareRoot(options, constantPart(options, node.args[0]), node.args[1])) === ast.intern(newNode(Parser.POW, [constantPart(options, node.args[0]), node.args[1]]))) ||
        equivLiteralIgnoreOrder(options, n1, n2);
    }
    option(options, "dontFactorDenominators", dontFactorDenominators);
    option(options, "dontFactorTerms", dontFactorTerms);
    option(options, "doingSimplified", doingSimplified);
    option(options, "dontSimplifyImaginary", dontSimplifyImaginary);
    option(options, "inverseResult", inverseResult);
    if (result && (n1 && hasLikeFactorsOrTerms(options, n1))) {
      // Has like subexprs so not simplfied.
      return inverseResult ? true : false;
    }
    return inverseResult ? !result : result;
  };

  Parser.fn.isFactorised = function (n1, options) {
    const inverseResult = option(options, "inverseResult");
    const doingSimplified = option(options, "doingSimplified", true);
    const result = isFactorised(options, normalize(options, n1));
    option(options, "doingSimplified", doingSimplified);
    return inverseResult ? !result : result;
  };

  Parser.fn.isUnit = function (n1, n2, options) {
    const inverseResult = option(options, "inverseResult");
    const u1 = units(options, normalize(options, n1), env);
    let u2 = units(options, normalize(options, n2), env);
    if (!(u2 instanceof Array)) {
      u2 = [u2];
    }
    let result = false;
    if (u1.length ===  0 && u2.length === 0 && n2.op !== Parser.NONE) {
      result = true;  // Make degenerate case true (e.g. isUnit "10" "20").
    } else if (u2.length > 0) {
      result = u2.every(function (v1) {
        return u1.some(function (v2) {
          return ast.intern(v1) === ast.intern(v2);
        });
      });
    }
    return inverseResult ? !result : result;
  };

  function getRE(re) {
    if (typeof re === "string") {
      if (re === "latex") {
        re = /^[\\]/;
      } else if (re === "not latex") {
        re = /^[^\\]/;
      } else {
        assert(false, "2000: Expecting 'latex' or 'not latex'");
      }
    }
    return re;
  }

  Parser.fn.variables = function (n1, options, pattern) {
    const names = variables(options, n1);
    const filtered = [];
    const re = getRE(pattern);
    names.forEach(function (n) {
      if (!re || re.test(n)) {
        filtered.push(n);
      }
    });
    return filtered;
  };

  Parser.fn.known = function (n1, options, pattern) {
    const env = n1.env ? n1.env : [];
    const names = variables(options, n1);
    const re = getRE(pattern);
    const filtered = [];
    names.forEach(function (n) {
      if (env[n] && (!re || re.test(n))) {
        filtered.push(n);
      }
    });
    return filtered;
  };

  Parser.fn.unknown = function (n1, options, pattern) {
    const env = n1.env ? n1.env : [];
    const names = variables(options, n1);
    const re = getRE(pattern);
    const filtered = [];
    names.forEach(function (n) {
      if (!env[n] && (!re || re.test(n))) {
        filtered.push(n);
      }
    });
    return filtered;
  };

  Parser.fn.hint = function (n1, options) {
    return hint(options, n1);
  };

  const option = Parser.option = function option(options, p, v) {
    assert(options);
    options = options || {};
    // console.log("option() options=" + JSON.stringify(options));
    // if (+options.decimalPlaces !== 0) {
    //   console.trace();
    // }
    // Get previous value and return it.
    let val = options && options[p];
    if (arguments.length > 2) {
      // Set the option value.
      if (v === undefined) {
        // Explicitly set to undefined so make the option go away.
        delete options[p];
      } else {
        options[p] = v;
      }
    }
    if (val === undefined) {
      switch (p) {
      case "field":
        val = "integer";
        break;
      case "decimalPlaces":
        val = 10;
        break;
      case "toleranceAbsolute":
      case "tolerancePercent":
      case "toleranceRange":
      case "setThousandsSeparator":
      case "setDecimalSeparator":
      case "dontExpandPowers":
      case "dontFactorDenominators":
      case "dontFactorTerms":
      case "doingSimplified":
      case "strict":
      case "antiderivative":
      case "compatibility":
      case "allowEulersNumber":
      case "treatLettersAsVariables":
      case "ignoreUnits":
        val = undefined;
        break;
      default:
        val = false;
        break;
      }
    }
    // Return the original or default option.
    return val;
  };
  Parser.config = function (p, v) {
    let config = Parser.configEnv;
    // Get previous value and return it.
    let val = config && config[p];
    if (arguments.length > 1) {
      // Set the option value.
      Parser.configEnv = config = config || {};
      if (v === undefined) {
        // Explicitly set to undefined so make the config go away.
        delete config[p];
      } else {
        config[p] = v;
      }
    }
    if (val === undefined) {
      // Define default config value here.
      switch (p) {
      default:
        val = false;
        break;
      }
    }
    // Return the original or default option.
    return val;
  };
  return Parser;
};
