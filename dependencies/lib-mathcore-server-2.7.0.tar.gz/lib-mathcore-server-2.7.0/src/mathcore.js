/*
 * Copyright 2013 Learnosity Ltd. All Rights Reserved.
 *
 */

import {Assert, assert, message} from "./assert.js";
//import {Ast, Parser} from "../../../parselatex/index.js";
import {Ast, Parser} from "@artcompiler/parselatex";
import Decimal from "decimal.js";
import {init as initMathModel} from "./mathmodel.js";
initMathModel();
export const MathCore = (function MathCore () {
  Assert.reserveCodeRange(3000, 3999, "mathcore");
  const messages = Assert.messages;
  const message = Assert.message;
  const assert = Assert.assert;
  messages[3001] = "No Math Core spec provided.";
  messages[3002] = "No Math Core solution provided.";
  messages[3003] = "No Math Core spec value provided.";
  messages[3004] = "Invalid Math Core spec method '%1'.";
  messages[3005] = "Operation taking more than %1 milliseconds.";
  messages[3006] = "Invalid option name '%1'.";
  messages[3007] = "Invalid option value '%2' for option '%1'.";
  messages[3008] = "Internal error: %1";

  const u = 1;
  const k = 1000;
  const c = new Decimal("1E-2");
  const m = new Decimal("1E-3");
  const mu = new Decimal("1E-6");
  const n = new Decimal("1E-9");
  const env = {
    "matrix": {},
    "pmatrix": {},
    "bmatrix": {},
    "Bmatrix": {},
    "vmatrix": {},
    "Vmatrix": {},
    "array": {},
    "\\alpha": { type: "var" },
    "\\beta": { type: "var" },
    "\\gamma": { type: "var" },
    "\\delta": { type: "var" },
    "\\epsilon": { type: "var" },
    "\\zeta": { type: "var" },
    "\\eta": { type: "var" },
    "\\theta": { type: "var" },
    "\\iota": { type: "var" },
    "\\kappa": { type: "var" },
    "\\lambda": { type: "var" },
    "\\mu": { type: "const", value: mu },
    "\\nu": { type: "var" },
    "\\xi": { type: "var" },
    "\\pi": { type: "const", value: Math.PI },
    "e": { type: "const", value: Math.E },
    "\\rho": { type: "var" },
    "\\sigma": { type: "var" },
    "\\tau": { type: "var" },
    "\\upsilon": { type: "var" },
    "\\phi": { type: "var" },
    "\\chi": { type: "var" },
    "\\psi": { type: "var" },
    "\\omega": { type: "var" }
  };
  function evaluate(spec, solution, resume) {
    try {
      assert(spec, message(3001, [spec]));
      assert(solution != undefined, message(3002, [solution]));
      Assert.setTimeout(timeoutDuration, message(3005, [timeoutDuration]));
      const evaluator = makeEvaluator(spec);
      evaluator.evaluate(solution, function (err, val) {
        if (err && err.length) {
          resume(err);
        } else {
          resume([], val);
        }
      });
    } catch (e) {
      console.log(e + "\n" + e.stack);
      resume(e.stack);
    }
  }
  function evaluateVerbose(spec, solution, resume) {
    let model, result;
    try {
      assert(spec, message(3001, [spec]));
      Assert.setTimeout(timeoutDuration, message(3005, [timeoutDuration]));
      const evaluator = makeEvaluator(spec);
      var errorCode = 0, msg = "Normal completion", stack, location;
      evaluator.evaluate(solution, function (err, val) {
        model = evaluator.model;
        resume(err, {
          result: val,
          errorCode: errorCode,
          message: msg,
          stack: stack,
          location: location,
          toString: function () {
            return this.errorCode + ": (" + location + ") " + msg + "\n" + this.stack;
          }
        });
      });
    } catch (e) {
      console.log("ERROR evaluateVerbose e=" + e.stack);
      if (!e.message) {
        try {
          // Internal error.
          assert(false, message(3008, [e]));
        } catch (x) {
          e = x;
        }
      }
      var errorCode = parseErrorCode(e.message);
      var msg = parseMessage(e.message);
      var stack = e.stack;
      var location = e.location;
      console.log("ERROR evaluateVerbose errorCode=" + errorCode + " stack=" + stack);
      if (errorCode % 1000 !== 0) {  // If not an internal error.
        resume([], {
          result: false,
          errorCode: errorCode,
          message: msg,
          stack: stack,
          location: location,
          toString: function () {
            return this.errorCode + ": (" + location + ") " + msg + "\n" + this.stack;
          }
        });
      } else {
        resume([{
          error: e.message,
        }], {
          errorCode: errorCode,
          msg: msg,
        });
      }
    }
    function parseErrorCode(e) {
      const code = +e.slice(0, e.indexOf(":"));
      if (!isNaN(code)) {
        return code;
      }
      return 0;
    }
    function parseMessage(e) {
      const code = parseErrorCode(e);
      if (code) {
        return e.slice(e.indexOf(":") + 2);
      }
      return e;
    }
  }

  var timeoutDuration = 15000; // 30 sec

  function setTimeoutDuration(duration) {
    timeoutDuration = duration;
  }

  function validateOption(options, p, v) {
    switch (p) {
    case "toleranceAbsolute":
      if (v === undefined || +v >= 0 ||
          typeof v === "string") {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "tolerancePercent":
      if (v === undefined || +v >= 0) {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "toleranceRange":
      if (v === undefined ||
          v instanceof Array && v.length === 2) {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "antiderivative":
      if (typeof v === "undefined" ||
          typeof v === "string") {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "allowDecimal":
    case "allowInterval":
    case "dontExpandPowers":
    case "dontFactorDenominators":
    case "dontFactorTerms":
    case "doingSimplified":
    case "dontSimplifyImaginary":
    case "ignoreOrder":
    case "inverseResult":
    case "requireThousandsSeparator":
    case "ignoreTrailingZeros":
    case "allowThousandsSeparator":
    case "ignoreCoefficientOne":
    case "strict":
    case "allowEulersNumber":
    case "treatLettersAsVariables":
    case "ignoreUnits":
    case "convertRepeatingDecimalToFraction":
    case "integrationConstant":
    case "absoluteValue":
    case "parsingIntegralExpr":
      if (typeof v === "undefined" || typeof v === "boolean") {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "setThousandsSeparator":
      if (typeof v === "undefined" ||
          typeof v === "string" ||
          v instanceof Array) {
        break;
      }
      assert(false, message(3007, [p, v]));
      break;
    case "setDecimalSeparator":
      if (typeof v === "undefined" ||
          typeof v === "string" && v.length === 1 ||
          v instanceof Array && v.length > 0 && v[0].length === 1) {
        break;
      }
      assert(false, message(3007, [p, JSON.stringify(v)]));
      break;
    case "env":
    case "ast":
    case "sympyRules":
      if (typeof v === "undefined" ||
          typeof v === "object") {
        break;
      }
      assert(false, message(3007, [p, JSON.stringify(v)]));
      break;
    default:
      assert(false, message(3006, [p]));
      break;
    }
    // If we get this far, all is well.
    return;
  }
  function validateOptions(options) {
    if (options) {
      Object.keys(options).forEach(function (option) {
        validateOption(options, option, options[option]);
      });
    }
  }
  function makeEvaluator(spec) {
    let exception;
    try {
      var method = spec.method;
      var value = spec.value;
      var options = Parser.options = Object.assign({}, spec.options);
      options.ast = new Ast;
      Parser.configEnv = spec.config;
      Assert.setLocation("spec");
      validateOptions(options);
      Parser.pushEnv(env);
      if (options.env) {
        Parser.pushEnv(options.env);
      }
      var valueNode = value != undefined ? Parser.create(options, value, "spec") : undefined;
      if (valueNode) {
        valueNode.env = env;   // Save environment for later analysis.
      }
      if (options.env) {
        Parser.popEnv(options.env);
      }
      Parser.popEnv();
    } catch (x) {
      exception = x;
    }
    const evaluate = function evaluate(solution, resume) {
      try {
        if (exception) {
          throw exception;
        }
        Assert.setLocation("user");
        assert(solution != undefined, message(3002));
        Parser.pushEnv(env);
        if (options.env) {
          Parser.pushEnv(options.env);
        }
        const solutionNode = Parser.create(options, solution, "user");
        if (!outerResult.model) {
          // Patch the closed value if it isn't already set.
          solutionNode.env = env;
          outerResult.model = solutionNode;
        }
        Assert.setLocation("spec");
        let result;
        switch (method) {
        case "evalSympy":
          solutionNode.evalSympy(options, resume);
          return;
        case "equivLiteral":
          assert(value != undefined, message(3003));
          result = valueNode.equivLiteral(solutionNode, options);
          break;
        case "equivSyntax":
          assert(value != undefined, message(3003));
          if (!(valueNode instanceof Array)) {
            valueNode = [valueNode];
          }
          result = valueNode.some(function (n) {
            return n.equivSyntax(solutionNode, options);
          });
          break;
        case "equivSymbolic":
          assert(value != undefined, message(3003));
          options.sympyRules = spec.sympyRules;
          result = valueNode.equivSymbolic(solutionNode, options, function (err, val) {
            resume(err, val);
          });
          return;
          break;
        case "format":
          result = valueNode.format(solutionNode, options);
          break;
        case "validSyntax":
          // If we got this far, then value parsed.
          result = true;
          break;
        case "format":
          result = valueNode.format(solutionNode, options);
          break;
        default:
          assert(false, message(3004, [method]));
          break;
        }
        if (options.env) {
          Parser.popEnv(options.env);
        }
        Parser.popEnv();
        resume([], result);
      } catch (x) {
        console.log("evaluateVerbose() evaluate() " + x.stack);
        resume([].concat(x.message), Parser.option(options, 'inverseResult') && true || false);
      }
    };
    var outerResult = {
      evaluate: evaluate,
      model: valueNode
    };
    return outerResult;
  }
  return {
    evaluate: evaluate,
    evaluateVerbose: evaluateVerbose,
    makeEvaluator: makeEvaluator,
    setTimeoutDuration: setTimeoutDuration,
    Model: Parser,
    Ast: Ast,
  };
})();
