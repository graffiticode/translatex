import * as mathcore from './src/mathcore.js';
export const MathCore = mathcore.MathCore;
