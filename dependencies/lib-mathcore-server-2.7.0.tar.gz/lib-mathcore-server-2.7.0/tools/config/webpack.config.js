const path = require('path');
module.exports = {
  target: 'node',
  mode: 'development',
  devtool: 'source-map',
  entry: './src/mathcore.js',
  output: {
    filename: 'mathcore.js',
    path: path.resolve(__dirname, '../../dist'),
    library: 'MathCore',
    globalObject: 'this',
    libraryTarget: 'umd',
  },
};
