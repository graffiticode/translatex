module.exports = {
  "env": {
    "node": true,
    "es2021": true
  },
  "extends": [
//    "eslint:recommended",
  ],
  "ignorePatterns": [
    "src/sympyRules.js",
    "src/translatex.js",
  ],
  "parserOptions": {
    "ecmaFeatures": {
      "jsx": true
    },
    "ecmaVersion": 12,
    "sourceType": "module"
  },
  "plugins": [
  ],
  "rules": {
    // "semi": 2,
    // "no-var": 2,
    // "prefer-const": 2,
    // "space-infix-ops": 2,
    "no-unused-vars": 2,
  },
};
