
// mathcore commit {{sha}}
// Copyright 2020 Artcompiler Inc. All Rights Reserved.
// Copyright 2020 Learnosity Ltd. All Rights Reserved.
