import {Model} from './src/model.js';
import * as ast from './src/ast.js';
export const Ast = ast.Ast;
export const Parser = Model;
